﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assesment_Tool.Models
{
    public class AssessmentModel
    {
        public int ID { get; set; }

        public string Seat_No { get; set; }

        public string Paper_ID { get; set; }
        public int Q1 { get; set; }
        public int Q7 { get; set; }
        public int Q8 { get; set; }
        public int Total { get; set; }
        public float Q1Ans1 { get; set; }
        public float Q1Ans2 { get; set; }
        public float Q1Ans3 { get; set; }
        public float Q1Ans4 { get; set; }
        public float Q1Ans5 { get; set; }
        public float Q1Ans6 { get; set; }
        public float Q1Ans7 { get; set; }
        public float Q1Ans8 { get; set; }
        public float Q1Ans9 { get; set; }
        public float Q1Ans10 { get; set; }
        public float Q7Ans1 { get; set; }
        public float Q7Ans2 { get; set; }
        public float Q7Ans3 { get; set; }
        public float Q7Ans4 { get; set; }
        public float Q7Ans5 { get; set; }
        public float Q7Ans6 { get; set; }
        public float Q7Ans7 { get; set; }
        public float Q7Ans8 { get; set; }
        public float Q8Ans1 { get; set; }
        public float Q8Ans2 { get; set; }
        public float Q8Ans3 { get; set; }
        public float Q8Ans4 { get; set; }
    }
}
