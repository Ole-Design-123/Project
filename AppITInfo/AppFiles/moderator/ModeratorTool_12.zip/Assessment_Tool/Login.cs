﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Assessment_Tool
{
    public partial class Login : Form
    {
        DataAccessLayer dc = new DataAccessLayer();
        public Login()
        {
            InitializeComponent();
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            var tid = txtTID.Text;
            var pwd = txtPwd.Text;
            DataTable dt = dc.ReturnDataTable("select * from Tbl_Moderator where IndexNo='"+tid+"' and  Password='"+pwd+"'");
            if (dt.Rows.Count > 0)
            {
                string dist_code = tid.Substring(0, 2);
                DataTable Div = dc.ReturnDataTable("select distinct DIVISION_CODE from Tbl_Code_Master where DISTRICT_CODE = '" + dist_code + "'");
                string DivCode = Div.Rows[0]["DIVISION_CODE"].ToString();
                //DataTable TotalData = dc.ReturnDataTable(@" select +isnull([Complete],0)+isnull([Incomplete],0)+isnull([Skip],0)
                //                FROM(select distinct(PStatus) PStatus, TID, count(TID) TCONT 
                //                from Tbl_AllAns where TID is not null and TID = '" + tid + "' group by TID, PStatus) Z PIVOT(SUM(TCONT) for [PStatus] in ([Complete],[Incomplete],[Skip])) AS X");
                DataTable TotalData = dc.ReturnDataTable(@"select ID, Paper_ID, Q1, Q7, Q8, Total from Tbl_Marks");
                if(TotalData.Rows.Count == 0)
                {
                    MessageBox.Show("No paper available for you !");
                }
                else 
                {
                    //QueAnswer178 queAnswer178 = new QueAnswer178(tid);
                    //queAnswer178.Show();
                    ModeratorDashBoard d = new ModeratorDashBoard(tid);
                    d.Show();
                    this.Hide();
                }
            }
            else
            {
                MessageBox.Show("Invalid Credentials");
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
