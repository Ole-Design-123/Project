﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using Assessment_Tool.Models;

namespace Assessment_Tool
{

    public partial class QueAnswer178 : Form
    {
        SqlConnection con = new SqlConnection();
        DataAccessLayer dc = new DataAccessLayer();
        DataSet ds = new DataSet();
        New_Course_ITDB_2021Entities db = new New_Course_ITDB_2021Entities();
        public static string ID = "";
        public static string MID = "";

        public QueAnswer178(string uid,string mid)
        {
            InitializeComponent();
            ID = uid;
            MID = mid;
            BindQuesAns();
            BindMarks();
            BindModelAns();

        }

        public void BindMarks()
        {
            DataTable MarksRow = dc.ReturnDataTable(@"select * from Tbl_Marks where ID= " + ID + "");

            R1.Checked = MarksRow.Rows[0]["Q1Ans1"].ToString() == "1" ? true : false;
            R2.Checked = MarksRow.Rows[0]["Q1Ans2"].ToString() == "1" ? true : false;
            R3.Checked = MarksRow.Rows[0]["Q1Ans3"].ToString() == "1" ? true : false;
            R4.Checked = MarksRow.Rows[0]["Q1Ans4"].ToString() == "1" ? true : false;
            R5.Checked = MarksRow.Rows[0]["Q1Ans5"].ToString() == "1" ? true : false;
            R6.Checked = MarksRow.Rows[0]["Q1Ans6"].ToString() == "1" ? true : false;
            R7.Checked = MarksRow.Rows[0]["Q1Ans7"].ToString() == "1" ? true : false;
            R8.Checked = MarksRow.Rows[0]["Q1Ans8"].ToString() == "1" ? true : false;
            R9.Checked = MarksRow.Rows[0]["Q1Ans9"].ToString() == "1" ? true : false;
            R10.Checked = MarksRow.Rows[0]["Q1Ans10"].ToString() == "1" ? true : false;
            CmbAns7_1.Text = MarksRow.Rows[0]["Q7Ans1"].ToString() ;
            CmbAns7_2.Text = MarksRow.Rows[0]["Q7Ans2"].ToString();
            CmbAns7_3.Text = MarksRow.Rows[0]["Q7Ans3"].ToString();
            CmbAns7_4.Text = MarksRow.Rows[0]["Q7Ans4"].ToString();
            CmbAns7_5.Text = MarksRow.Rows[0]["Q7Ans5"].ToString();
            CmbAns7_6.Text = MarksRow.Rows[0]["Q7Ans6"].ToString();
            CmbAns7_7.Text = MarksRow.Rows[0]["Q7Ans7"].ToString();
            CmbAns7_8.Text = MarksRow.Rows[0]["Q7Ans8"].ToString();
            Cmb8a1Ans.Text = MarksRow.Rows[0]["Q8Ans1"].ToString();
            Cmb8a2Ans.Text = MarksRow.Rows[0]["Q8Ans2"].ToString();
            Cmb8b1Ans.Text = MarksRow.Rows[0]["Q8Ans3"].ToString();
            Cmb8b2Ans.Text = MarksRow.Rows[0]["Q8Ans4"].ToString();
            BindGrid();
        }
        public void BindQuesAns()
        {
            DataTable MarksRow = dc.ReturnDataTable(@"select * from Tbl_Marks where ID= " + ID + "");
            DataTable Q178AnsRow = dc.ReturnDataTable(@"select * from Tbl_AllAns where Seat_No= '" + MarksRow.Rows[0]["Seat_No"].ToString() + "'");           

            if (Q178AnsRow.Rows.Count > 0)
            {
                //Q1 Ans binding
                txtPid.Text = Q178AnsRow.Rows[0]["Paper_ID"].ToString();
                lblStremName.Text = Q178AnsRow.Rows[0]["Stream"].ToString();
                Teacher_Id.Text = Q178AnsRow.Rows[0]["TID"].ToString();
                txtQ1Ans1.Text = Q178AnsRow.Rows[0]["Q1Ans1"].ToString();
                txtQ1Ans2.Text = Q178AnsRow.Rows[0]["Q1Ans2"].ToString();
                txtQ1Ans3.Text = Q178AnsRow.Rows[0]["Q1Ans3"].ToString();
                txtQ1Ans4.Text = Q178AnsRow.Rows[0]["Q1Ans4"].ToString();
                txtQ1Ans5.Text = Q178AnsRow.Rows[0]["Q1Ans5"].ToString();
                txtQ1Ans6.Text = Q178AnsRow.Rows[0]["Q1Ans6"].ToString();
                txtQ1Ans7.Text = Q178AnsRow.Rows[0]["Q1Ans7"].ToString();
                txtQ1Ans8.Text = Q178AnsRow.Rows[0]["Q1Ans8"].ToString();
                txtQ1Ans9.Text = Q178AnsRow.Rows[0]["Q1Ans9"].ToString();
                txtQ1Ans10.Text = Q178AnsRow.Rows[0]["Q1Ans10"].ToString();

                //Q7 ans binding
                textQ7Ans1.Text = Q178AnsRow.Rows[0]["Q7Ans1"].ToString().Replace("Ω", Environment.NewLine);
                textQ7Ans2.Text = Q178AnsRow.Rows[0]["Q7Ans2"].ToString().Replace("Ω", Environment.NewLine);
                textQ7Ans3.Text = Q178AnsRow.Rows[0]["Q7Ans3"].ToString().Replace("Ω", Environment.NewLine);
                textQ7Ans4.Text = Q178AnsRow.Rows[0]["Q7Ans4"].ToString().Replace("Ω", Environment.NewLine);
                textQ7Ans5.Text = Q178AnsRow.Rows[0]["Q7Ans5"].ToString().Replace("Ω", Environment.NewLine);
                textQ7Ans6.Text = Q178AnsRow.Rows[0]["Q7Ans6"].ToString().Replace("Ω", Environment.NewLine);
                textQ7Ans7.Text = Q178AnsRow.Rows[0]["Q7Ans7"].ToString().Replace("Ω", Environment.NewLine);
                textQ7Ans8.Text = Q178AnsRow.Rows[0]["Q7Ans8"].ToString().Replace("Ω", Environment.NewLine);

                //Q8 ans binding
                textQ8Ans1.Text = Q178AnsRow.Rows[0]["Q8Ans1"].ToString().Replace("Ω", Environment.NewLine);
                textQ8Ans2.Text = Q178AnsRow.Rows[0]["Q8Ans2"].ToString().Replace("Ω", Environment.NewLine);
                textQ8Ans3.Text = Q178AnsRow.Rows[0]["Q8Ans3"].ToString().Replace("Ω", Environment.NewLine);
                textQ8Ans4.Text = Q178AnsRow.Rows[0]["Q8Ans4"].ToString().Replace("Ω", Environment.NewLine);
            }

            else
            {
                MessageBox.Show("No Paper available for you..!!");
                txtPid.Text = "";
                lblStremName.Text = "";
                txtQ1Ans1.Text = "";
                txtQ1Ans2.Text = "";
                txtQ1Ans3.Text = "";
                txtQ1Ans4.Text = "";
                txtQ1Ans5.Text = "";
                txtQ1Ans6.Text = "";
                txtQ1Ans7.Text = "";
                txtQ1Ans8.Text = "";
                txtQ1Ans9.Text = "";
                txtQ1Ans10.Text = "";

                textQ7Ans1.Text = "";
                textQ7Ans2.Text = "";
                textQ7Ans3.Text = "";
                textQ7Ans4.Text = "";
                textQ7Ans5.Text = "";
                textQ7Ans6.Text = "";
                textQ7Ans7.Text = "";
                textQ7Ans8.Text = "";

                textQ8Ans1.Text = "";
                textQ8Ans2.Text = "";
                textQ8Ans3.Text = "";
                textQ8Ans4.Text = "";

                resetAllMarks();
                ResetInputControls();


            }
        }
        public void ResetInputControls()
        {
            btnSubmit.Enabled = false;
            R1.Enabled = false;
            R2.Enabled = false;
            R3.Enabled = false;
            R4.Enabled = false;
            R5.Enabled = false;
            R6.Enabled = false;
            R7.Enabled = false;
            R8.Enabled = false;
            R9.Enabled = false;
            R10.Enabled = false;
            CmbAns7_1.Enabled = false;
            CmbAns7_2.Enabled = false;
            CmbAns7_3.Enabled = false;
            CmbAns7_4.Enabled = false;
            CmbAns7_5.Enabled = false;
            CmbAns7_6.Enabled = false;
            CmbAns7_7.Enabled = false;
            CmbAns7_8.Enabled = false;
            Cmb8a1Ans.Enabled = false;
            Cmb8a2Ans.Enabled = false;
            Cmb8b1Ans.Enabled = false;
            Cmb8b2Ans.Enabled = false;
        }        

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

            CheckActivity1();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

            CheckActivity1();
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            CheckActivity1();
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            CheckActivity1();
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            CheckActivity1();
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            CheckActivity1();
        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {
            CheckActivity1();

        }
        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            CheckActivity1();
        }

        private void checkBox11_CheckedChanged(object sender, EventArgs e)
        {
            CheckActivity1();
        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {
            CheckActivity1();
        }

        private void checkBox13_CheckedChanged(object sender, EventArgs e)
        {
            CheckActivity1();
        }

        private void checkBox12_CheckedChanged(object sender, EventArgs e)
        {
            CheckActivity1();
        }

        private void checkBox15_CheckedChanged(object sender, EventArgs e)
        {
            CheckActivity1();

        }

        private void checkBox14_CheckedChanged(object sender, EventArgs e)
        {
            CheckActivity1();
        }

        private void checkBox17_CheckedChanged(object sender, EventArgs e)
        {
            CheckActivity1();
        }

        private void checkBox16_CheckedChanged(object sender, EventArgs e)
        {
            CheckActivity1();
        }

        private void checkBox19_CheckedChanged(object sender, EventArgs e)
        {
            CheckActivity1();
        }

        private void checkBox18_CheckedChanged(object sender, EventArgs e)
        {
            CheckActivity1();
        }

        private void checkBox21_CheckedChanged(object sender, EventArgs e)
        {
            CheckActivity1();
        }

        private void checkBox20_CheckedChanged(object sender, EventArgs e)
        {
            CheckActivity1();
        }
        public void CheckActivity1()
        {
            int i = 0;
            if (R1.Checked == true) { i = i + 1; }
            if (R2.Checked == true) { i = i + 1; }
            if (R3.Checked == true) { i = i + 1; }
            if (R4.Checked == true) { i = i + 1; }
            if (R5.Checked == true) { i = i + 1; }
            if (R6.Checked == true) { i = i + 1; }
            if (R7.Checked == true) { i = i + 1; }
            if (R8.Checked == true) { i = i + 1; }
            if (R9.Checked == true) { i = i + 1; }
            if (R10.Checked == true) { i = i + 1; }

            txtOutofTen.Text = i.ToString();
            grid1.Rows.Clear();
            BindGrid();
            grid1.Rows[0].Visible = true;

        }

        private void btnGiveUp_Click(object sender, EventArgs e)
        {
            this.Hide();
            new ModeratorDashBoard(lblMIndex.Text).Show();
        }

        void resetAllMarks()
        {
            R1.Checked = false;
            R2.Checked = false;
            R3.Checked = false;
            R4.Checked = false;
            R5.Checked = false;
            R6.Checked = false;
            R7.Checked = false;
            R8.Checked = false;
            R9.Checked = false;
            R10.Checked = false;

            CmbAns7_1.SelectedItem = "Select";
            CmbAns7_2.SelectedItem = "Select";
            CmbAns7_3.SelectedItem = "Select";
            CmbAns7_4.SelectedItem = "Select";
            CmbAns7_5.SelectedItem = "Select";
            CmbAns7_6.SelectedItem = "Select";
            CmbAns7_7.SelectedItem = "Select";
            CmbAns7_8.SelectedItem = "Select";

            Cmb8a1Ans.SelectedItem = "Select";
            Cmb8a2Ans.SelectedItem = "Select";
            Cmb8b1Ans.SelectedItem = "Select";
            Cmb8b2Ans.SelectedItem = "Select";
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToDecimal(txtOutofTen.Text) == 0)
                {
                    if (allwrong.Checked == false)
                    {
                        MessageBox.Show("If First Question's all Answers are wrong then Tick option of All Wrong");
                        return;
                    }
                }
                if (CmbAns7_1.SelectedItem.ToString() == "Select" || CmbAns7_2.SelectedItem.ToString() == "Select" || CmbAns7_3.SelectedItem.ToString() == "Select" || CmbAns7_4.SelectedItem.ToString() == "Select" || CmbAns7_5.SelectedItem.ToString() == "Select" || CmbAns7_6.SelectedItem.ToString() == "Select" || CmbAns7_7.SelectedItem.ToString() == "Select" || CmbAns7_8.SelectedItem.ToString() == "Select")
                {
                    MessageBox.Show("Please check the answers of question number 7");
                    return;
                }
                if (Cmb8a1Ans.SelectedItem.ToString() == "Select" || Cmb8a2Ans.SelectedItem.ToString() == "Select" || Cmb8b1Ans.SelectedItem.ToString() == "Select" || Cmb8b2Ans.SelectedItem.ToString() == "Select")
                {
                    MessageBox.Show("Please check the answers of question number 8");
                    return;
                }                
                DataTable dt1 = dc.ReturnDataTable(@"select * from Tbl_Marks where ID= " + ID + "");
                Tbl_Moderator_Marks tbl_Marks = new Tbl_Moderator_Marks();
                var q7totans = 0.0;
                var q8totans = 0.0;
                tbl_Marks.Seat_No = dt1.Rows[0]["Seat_No"].ToString();
                tbl_Marks.Paper_ID = dt1.Rows[0]["Paper_ID"].ToString();
                tbl_Marks.Q1Ans1 = R1.Checked == true ? 1 : 0;
                tbl_Marks.Q1Ans2 = R2.Checked == true ? 1 : 0;
                tbl_Marks.Q1Ans3 = R3.Checked == true ? 1 : 0;
                tbl_Marks.Q1Ans4 = R4.Checked == true ? 1 : 0;
                tbl_Marks.Q1Ans5 = R5.Checked == true ? 1 : 0;
                tbl_Marks.Q1Ans6 = R6.Checked == true ? 1 : 0;
                tbl_Marks.Q1Ans7 = R7.Checked == true ? 1 : 0;
                tbl_Marks.Q1Ans8 = R8.Checked == true ? 1 : 0;
                tbl_Marks.Q1Ans9 = R9.Checked == true ? 1 : 0;
                tbl_Marks.Q1Ans10 = R10.Checked == true ? 1 : 0;
                var Q1Marks = tbl_Marks.Q1Ans1 + tbl_Marks.Q1Ans2 + tbl_Marks.Q1Ans3 + tbl_Marks.Q1Ans4 + tbl_Marks.Q1Ans5 + tbl_Marks.Q1Ans6 + tbl_Marks.Q1Ans7 + tbl_Marks.Q1Ans8 + tbl_Marks.Q1Ans9 + tbl_Marks.Q1Ans10;
                tbl_Marks.Q1 = Int32.Parse(Q1Marks.ToString());
                float[] q7ansarr = new float[8];
                tbl_Marks.Q7Ans1 = float.Parse(CmbAns7_1.SelectedItem.ToString());
                tbl_Marks.Q7Ans2 = float.Parse(CmbAns7_2.SelectedItem.ToString());
                tbl_Marks.Q7Ans3 = float.Parse(CmbAns7_3.SelectedItem.ToString());
                tbl_Marks.Q7Ans4 = float.Parse(CmbAns7_4.SelectedItem.ToString());
                tbl_Marks.Q7Ans5 = float.Parse(CmbAns7_5.SelectedItem.ToString());
                tbl_Marks.Q7Ans6 = float.Parse(CmbAns7_6.SelectedItem.ToString());
                tbl_Marks.Q7Ans7 = float.Parse(CmbAns7_7.SelectedItem.ToString());
                tbl_Marks.Q7Ans8 = float.Parse(CmbAns7_8.SelectedItem.ToString());

                q7ansarr[0] = float.Parse(tbl_Marks.Q7Ans1.ToString());
                q7ansarr[1] = float.Parse(tbl_Marks.Q7Ans2.ToString());
                q7ansarr[2] = float.Parse(tbl_Marks.Q7Ans3.ToString());
                q7ansarr[3] = float.Parse(tbl_Marks.Q7Ans4.ToString());
                q7ansarr[4] = float.Parse(tbl_Marks.Q7Ans5.ToString());
                q7ansarr[5] = float.Parse(tbl_Marks.Q7Ans6.ToString());
                q7ansarr[6] = float.Parse(tbl_Marks.Q7Ans7.ToString());
                q7ansarr[7] = float.Parse(tbl_Marks.Q7Ans8.ToString());
                sortArrayAns7(q7ansarr);

                void sortArrayAns7(float[] array)
                {
                    var temp = 0.0;
                    for (int i = 0; i < 8; i++)
                    {
                        for (int j = i + 1; j < 8; j++)
                        {
                            if (array[i] < array[j])
                            {
                                temp = array[i];
                                array[i] = array[j];
                                array[j] = float.Parse(temp.ToString());
                            }
                        }
                    }
                    for (int i = 0; i <= 4; i++)
                    {
                        q7totans = q7totans + array[i];
                    }
                }
                var q7totmarks = Math.Round(Convert.ToDecimal(q7totans), MidpointRounding.AwayFromZero);
                tbl_Marks.Q7 = Convert.ToInt32(q7totmarks);
                tbl_Marks.Q8Ans1 = float.Parse(Cmb8a1Ans.SelectedItem.ToString());
                tbl_Marks.Q8Ans2 = float.Parse(Cmb8a2Ans.SelectedItem.ToString());
                tbl_Marks.Q8Ans3 = float.Parse(Cmb8b1Ans.SelectedItem.ToString());
                tbl_Marks.Q8Ans4 = float.Parse(Cmb8b2Ans.SelectedItem.ToString());
                var q8a = tbl_Marks.Q8Ans1 > tbl_Marks.Q8Ans2 ? tbl_Marks.Q8Ans1 : tbl_Marks.Q8Ans2;
                var q8b = tbl_Marks.Q8Ans3 > tbl_Marks.Q8Ans4 ? tbl_Marks.Q8Ans3 : tbl_Marks.Q8Ans4;
                q8totans = float.Parse((q8a + q8b).ToString());
                var q8totmarks = Math.Round(Convert.ToDecimal(q8totans), MidpointRounding.AwayFromZero);
                tbl_Marks.Q8 = Convert.ToInt32(q8totmarks);
                tbl_Marks.Total = tbl_Marks.Q1 + tbl_Marks.Q7 + tbl_Marks.Q8;
                tbl_Marks.Submission_Time = DateTime.Now;
                tbl_Marks.Moderator_Index_No = MID;
                string dist_code = MID.Substring(0, 2);
                DataTable Div = dc.ReturnDataTable("select distinct DIVISION_CODE from Tbl_Code_Master where DISTRICT_CODE = '" + dist_code + "'");
                tbl_Marks.Div_Code = Div.Rows[0]["DIVISION_CODE"].ToString();
                db.Tbl_Moderator_Marks.Add(tbl_Marks);
                db.SaveChanges();                
                MessageBox.Show("Paper no - " + txtPid.Text + " saved successfully..!");                
                grid1.Rows.Clear();               
                resetAllMarks();
                ResetInputControls();
                this.Hide();
                new ModeratorDashBoard(lblMIndex.Text).Show();
            }
            catch (Exception ex)
            
            {
                MessageBox.Show("Error :" + ex.ToString());
            }
            
        }
        private void btnNext_Click(object sender, EventArgs e)
        {
            new Login();
            BindQuesAns();
            BindModelAns();
            btnSubmit.Enabled = true;
            allwrong.Visible = true;
            allwrong.Checked = false;
        }

        private void txtOutofTen_TextChanged(object sender, EventArgs e)
        {
            if (txtOutofTen.Text != "0")
            {
                allwrong.Visible = false;
            }

            else
            {
                allwrong.Visible = true;
                allwrong.Checked = false;
            }

            grid1.Rows.Clear();
            BindGrid();
        }

        private void cmb7aAns_SelectedIndexChanged(object sender, EventArgs e)
        {
            grid1.Rows.Clear();
            BindGrid();
            grid1.Rows[1].Visible = false;
        }

        private void cmb7bAns_SelectedIndexChanged(object sender, EventArgs e)
        {
            grid1.Rows.Clear();
            BindGrid();
            grid1.Rows[1].Visible = false;
        }

        private void cmb7cAns_SelectedIndexChanged(object sender, EventArgs e)
        {
            grid1.Rows.Clear();
            BindGrid();
        }

        float[] q7ansarr = new float[8];
        public void BindGrid()
        {
            grid1.Rows.Clear();
            decimal TotalMarks;
            float q7totans = 0;
            float q8totans = 0;
            q7ansarr[0] = (CmbAns7_1.SelectedItem.ToString() == "Select") ? 0 : float.Parse(CmbAns7_1.SelectedItem.ToString());
            q7ansarr[1] = (CmbAns7_2.SelectedItem.ToString() == "Select") ? 0 : float.Parse(CmbAns7_2.SelectedItem.ToString());
            q7ansarr[2] = (CmbAns7_3.SelectedItem.ToString() == "Select") ? 0 : float.Parse(CmbAns7_3.SelectedItem.ToString());
            q7ansarr[3] = (CmbAns7_4.SelectedItem.ToString() == "Select") ? 0 : float.Parse(CmbAns7_4.SelectedItem.ToString());
            q7ansarr[4] = (CmbAns7_5.SelectedItem.ToString() == "Select") ? 0 : float.Parse(CmbAns7_5.SelectedItem.ToString());
            q7ansarr[5] = (CmbAns7_6.SelectedItem.ToString() == "Select") ? 0 : float.Parse(CmbAns7_6.SelectedItem.ToString());
            q7ansarr[6] = (CmbAns7_7.SelectedItem.ToString() == "Select") ? 0 : float.Parse(CmbAns7_7.SelectedItem.ToString());
            q7ansarr[7] = (CmbAns7_8.SelectedItem.ToString() == "Select") ? 0 : float.Parse(CmbAns7_8.SelectedItem.ToString());
            sortArrayAns7(q7ansarr);

            void sortArrayAns7(float[] array)
            {
                var temp = 0.0;

                for (int i = 0; i < 8; i++)
                {
                    for (int j = i + 1; j < 8; j++)
                    {
                        if (array[i] < array[j])
                        {
                            temp = array[i];
                            array[i] = array[j];
                            array[j] = float.Parse(temp.ToString());
                        }
                    }
                }
                for (int i = 0; i <= 4; i++)
                {
                    q7totans = q7totans + array[i];
                }

            }

            float q8_a1 = (Cmb8a1Ans.SelectedItem.ToString() == "Select") ? 0 : float.Parse(Cmb8a1Ans.SelectedItem.ToString());
            float q8_a2 = (Cmb8a2Ans.SelectedItem.ToString() == "Select") ? 0 : float.Parse(Cmb8a2Ans.SelectedItem.ToString());
            float q8_b1 = (Cmb8b1Ans.SelectedItem.ToString() == "Select") ? 0 : float.Parse(Cmb8b1Ans.SelectedItem.ToString());
            float q8_b2 = (Cmb8b2Ans.SelectedItem.ToString() == "Select") ? 0 : float.Parse(Cmb8b2Ans.SelectedItem.ToString());

            float q8amax = q8_a1 > q8_a2 ? q8_a1 : q8_a2;
            float q8bmax = q8_b1 > q8_b2 ? q8_b1 : q8_b2;
            q8totans = q8amax + q8bmax;

            decimal q7totmarks = Math.Round(Convert.ToDecimal(q7totans), MidpointRounding.AwayFromZero);
            decimal q8totmarks = Math.Round(Convert.ToDecimal(q8totans), MidpointRounding.AwayFromZero);
            TotalMarks = Convert.ToDecimal(txtOutofTen.Text) + q7totmarks + q8totmarks;
            grid1.Rows.Add(txtOutofTen.Text, q7totmarks, q8totmarks, TotalMarks);
            grid1.Update();
            grid1.Refresh();
            if (grid1.Rows.Count > 0)
            {
                btnSubmit.Enabled = true;
            }
        }
       

        public void BindModelAns()
        {
            DataTable MarksRow = dc.ReturnDataTable(@"select * from Tbl_Marks where ID= " + ID + "");            
            DataTable Q1ModelAns = dc.ReturnDataTable(@"SELECT * from Tbl_Model_Ans where Question_No like '%1%' and Paper_ID = '" + MarksRow.Rows[0]["Paper_ID"].ToString() + "'");

            if (Q1ModelAns.Rows.Count > 0)
            {
                txtQ1.Text = Q1ModelAns.Rows[0]["Question"].ToString();
                txtQ2.Text = Q1ModelAns.Rows[1]["Question"].ToString();
                txtQ3.Text = Q1ModelAns.Rows[2]["Question"].ToString();
                txtQ4.Text = Q1ModelAns.Rows[3]["Question"].ToString();
                txtQ5.Text = Q1ModelAns.Rows[4]["Question"].ToString();
                txtQ6.Text = Q1ModelAns.Rows[5]["Question"].ToString();
                txtQ7.Text = Q1ModelAns.Rows[6]["Question"].ToString();
                txtQ8.Text = Q1ModelAns.Rows[7]["Question"].ToString();
                txtQ9.Text = Q1ModelAns.Rows[8]["Question"].ToString();
                txtQ10.Text = Q1ModelAns.Rows[9]["Question"].ToString();

                txtQ1MAns.Text = Q1ModelAns.Rows[0]["Model_Ans"].ToString();
                textBox24.Text = Q1ModelAns.Rows[1]["Model_Ans"].ToString();
                textBox31.Text = Q1ModelAns.Rows[2]["Model_Ans"].ToString();
                textBox32.Text = Q1ModelAns.Rows[3]["Model_Ans"].ToString();
                textBox33.Text = Q1ModelAns.Rows[4]["Model_Ans"].ToString();
                textBox34.Text = Q1ModelAns.Rows[5]["Model_Ans"].ToString();
                textBox35.Text = Q1ModelAns.Rows[6]["Model_Ans"].ToString();
                textBox36.Text = Q1ModelAns.Rows[7]["Model_Ans"].ToString();
                textBox37.Text = Q1ModelAns.Rows[8]["Model_Ans"].ToString();
                textBox38.Text = Q1ModelAns.Rows[9]["Model_Ans"].ToString();
            }
            else
            {
                txtQ1.Text = "";
                txtQ2.Text = "";
                txtQ3.Text = "";
                txtQ4.Text = "";
                txtQ5.Text = "";
                txtQ6.Text = "";
                txtQ7.Text = "";
                txtQ8.Text = "";
                txtQ9.Text = "";
                txtQ10.Text = "";

                txtQ1MAns.Text = "";
                textBox24.Text = "";
                textBox31.Text = "";
                textBox32.Text = "";
                textBox33.Text = "";
                textBox34.Text = "";
                textBox35.Text = "";
                textBox36.Text = "";
                textBox37.Text = "";
                textBox38.Text = "";
            }

            DataTable Q7Ques = dc.ReturnDataTable(@"Select * from Tbl_Model_Ans where Paper_ID = '" + MarksRow.Rows[0]["Paper_ID"].ToString() + "' and Question_No like '%7%'");

            if (Q7Ques.Rows.Count > 0)
            {
                textQ7q1.Text = Q7Ques.Rows[0]["Question"].ToString();
                textQ7q2.Text = Q7Ques.Rows[1]["Question"].ToString();
                textQ7q3.Text = Q7Ques.Rows[2]["Question"].ToString();
                textQ7q4.Text = Q7Ques.Rows[3]["Question"].ToString();
                textQ7q5.Text = Q7Ques.Rows[4]["Question"].ToString();
                textQ7q6.Text = Q7Ques.Rows[5]["Question"].ToString();
                textQ7q7.Text = Q7Ques.Rows[6]["Question"].ToString();
                textQ7q8.Text = Q7Ques.Rows[7]["Question"].ToString();
            }
            else
            {
                textQ7q1.Text = "";
                textQ7q2.Text = "";
                textQ7q3.Text = "";
                textQ7q4.Text = "";
                textQ7q5.Text = "";
                textQ7q6.Text = "";
                textQ7q7.Text = "";
                textQ7q8.Text = "";
            }
            DataTable Q8Ques = dc.ReturnDataTable(@"select * from Tbl_Model_Ans where Paper_ID ='" + MarksRow.Rows[0]["Paper_ID"].ToString() + "' and Question_No like '%8%'");

            if (Q8Ques.Rows.Count > 0)
            {
                textQ8q1.Text = Q8Ques.Rows[0]["Question"].ToString();
                textQ8q2.Text = Q8Ques.Rows[1]["Question"].ToString();
                textQ8q3.Text = Q8Ques.Rows[2]["Question"].ToString();
                textQ8q4.Text = Q8Ques.Rows[3]["Question"].ToString();
            }
            else
            {
                textQ8q1.Text = "";
                textQ8q2.Text = "";
                textQ8q3.Text = "";
                textQ8q4.Text = "";
            }
            //}
        }
        private void QueAnswer178_Load(object sender, EventArgs e)
        {
            DataTable MarksRow = dc.ReturnDataTable(@"select * from Tbl_Marks where ID= " + ID + "");
            lblMIndex.Text = MID;
        }
        private void CmbAns7_1_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGrid();
        }
        private void CmbAns7_2_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGrid();
        }

        private void CmbAns7_3_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGrid();
        }

        private void CmbAns7_4_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGrid();
        }

        private void CmbAns7_5_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGrid();
        }

        private void CmbAns7_6_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGrid();
        }

        private void CmbAns7_7_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGrid();
        }

        private void CmbAns7_8_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGrid();
        }
        private void Cmb8a1Ans_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGrid();
        }

        private void Cmb8a2Ans_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGrid();
        }
        private void Cmb8b1Ans_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGrid();
        }
        private void Cmb8b2Ans_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGrid();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //reasonchk = 1;
        }               
    }
}
