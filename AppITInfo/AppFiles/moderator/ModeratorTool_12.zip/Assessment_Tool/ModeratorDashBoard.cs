﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Assessment_Tool
{
    public partial class ModeratorDashBoard : Form
    {
        DataAccessLayer dc = new DataAccessLayer();
        public static string mid = "";
        public ModeratorDashBoard(string tid)
        {
            InitializeComponent();
            mid = tid;
        }

        private void ModeratorDashBoard_Load(object sender, EventArgs e)
        {
            BindModeratorGrid();
            string dist_code = mid.Substring(0, 2);
            DataTable Div = dc.ReturnDataTable("select distinct DIVISION_CODE from Tbl_Code_Master where DISTRICT_CODE = '" + dist_code + "'");
            string DivCode = Div.Rows[0]["DIVISION_CODE"].ToString();
            DataTable ModeratorInfo = dc.ReturnDataTable("select IndexNo,Name,Subject from Tbl_Moderator where IndexNo = '" + mid + "'");
            lblmidindex.Text = ModeratorInfo.Rows[0]["IndexNo"].ToString();
            lblMName.Text = ModeratorInfo.Rows[0]["Name"].ToString();
            DataTable MTotalPaper = dc.ReturnDataTable(@"select count(A.ID) total from Tbl_Marks A, Tbl_AllAns B where A.Seat_No = B.Seat_No and B.DivisionCode = '" + DivCode + "'");
            lbltotalpaper.Text = MTotalPaper.Rows[0]["total"].ToString();
            DataTable MChecedPaper = dc.ReturnDataTable(@"select count(A.ID) checked from Tbl_Moderator_Marks A where A.Moderator_Index_No = '" + mid + "'");
            lblpaperchecked.Text = MChecedPaper.Rows[0]["checked"].ToString();
        }
        private void ModeratorGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string id = ModeratorGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
            this.Hide();
            QueAnswer178 queAnswer178 = new QueAnswer178(id,mid);
            queAnswer178.Show();
        }
        public void BindModeratorGrid()
        {
            string dist_code = mid.Substring(0, 2);
            DataTable Div = dc.ReturnDataTable("select distinct DIVISION_CODE from Tbl_Code_Master where DISTRICT_CODE = '" + dist_code + "'");
            string DivCode = Div.Rows[0]["DIVISION_CODE"].ToString();
            DataTable TotalData = dc.ReturnDataTable(@"select A.ID,B.TID,A.Paper_ID, A.Q1, A.Q7, A.Q8, A.Total  from Tbl_Marks A, Tbl_AllAns B where A.Seat_No = B.Seat_No and B.DivisionCode = '" + DivCode + "'and A.Seat_No not in (select Seat_No from Tbl_Moderator_Marks) ");
            ModeratorGridView.DataSource = TotalData;
        }

        private void btnSearchByTID_Click(object sender, EventArgs e)
        {
            string dist_code = mid.Substring(0, 2);
            DataTable Div = dc.ReturnDataTable("select distinct DIVISION_CODE from Tbl_Code_Master where DISTRICT_CODE = '" + dist_code + "'");
            string DivCode = Div.Rows[0]["DIVISION_CODE"].ToString();
            DataTable TotalData = dc.ReturnDataTable(@"select A.ID,B.TID,A.Paper_ID, A.Q1, A.Q7, A.Q8, A.Total  from Tbl_Marks A, Tbl_AllAns B where A.Seat_No = B.Seat_No and B.DivisionCode = '" + DivCode + "'and A.Seat_No not in (select Seat_No from Tbl_Moderator_Marks) and B.TID = '"+txtTID.Text+"'");
            ModeratorGridView.DataSource = TotalData;
        }

        private void btnSearchBymarks_Click(object sender, EventArgs e)
        {
            string dist_code = mid.Substring(0, 2);
            DataTable Div = dc.ReturnDataTable("select distinct DIVISION_CODE from Tbl_Code_Master where DISTRICT_CODE = '" + dist_code + "'");
            string DivCode = Div.Rows[0]["DIVISION_CODE"].ToString();
            DataTable TotalData = dc.ReturnDataTable(@"select A.ID,B.TID,A.Paper_ID, A.Q1, A.Q7, A.Q8, A.Total  from Tbl_Marks A, Tbl_AllAns B where A.Seat_No = B.Seat_No and B.DivisionCode = '" + DivCode + "'and A.Seat_No not in (select Seat_No from Tbl_Moderator_Marks) and A.Total = '" + txtMarks.Text + "'");
            ModeratorGridView.DataSource = TotalData;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BindModeratorGrid();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Login().Show();
        }
    }
}
