﻿//using Assesment.Properties;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assesment
{
    class registry_key
    {
        //public string Check_Registry()
        //{
        //    string ss = Resources.ResourceManager.GetString("Registry_Name");
        //   // Cindex cs = new Cindex();
        //    if (IntPtr.Size == 4)
        //    {
        //        //-------- check for "JULY2017" key for xp ---------

        //        RegistryKey key = Registry.LocalMachine.OpenSubKey("Software\\");

        //        int cnt = key.SubKeyCount;
        //        int flag = 0;
        //        string[] subkeys = key.GetSubKeyNames();
        //        for (int i = 0; i < cnt; i++)
        //        {
        //            string str = subkeys[i];
        //            if (str == Resources.ResourceManager.GetString("Registry_Name"))
        //            {
        //                flag = 1;
        //                break;
        //            }
        //        }
        //        if (flag == 0)
        //        {
        //            // MessageBox.Show("The System is not inspected yet... Please Wait !!!");
        //            RegistryKey key1 = Registry.LocalMachine.CreateSubKey("Software\\" + Resources.ResourceManager.GetString("Registry_Name"));
        //            return "0~0";
        //        }
        //        else if (flag == 1)
        //        {
        //            RegistryKey dttkey = Registry.LocalMachine.CreateSubKey("Software\\" + Resources.ResourceManager.GetString("Registry_Name"));
        //            int count1 = dttkey.SubKeyCount;
        //            int flag1 = 0;
        //            string[] subkeys1 = dttkey.GetSubKeyNames();
        //            for (int i = 0; i < count1; i++)
        //            {
        //                string str1 = subkeys1[i];
        //                if (str1 == "cindex")
        //                {
        //                    flag1 = 1;
        //                    break;
        //                }
        //            }
        //            if (flag1 == 0)
        //            {
        //                RegistryKey subkey3 = Registry.LocalMachine.CreateSubKey("Software\\" + Resources.ResourceManager.GetString("Registry_Name") + "\\cindex");
        //            }
        //            else
        //            {
        //                RegistryKey subkey3 = Registry.LocalMachine.OpenSubKey("Software\\" + Resources.ResourceManager.GetString("Registry_Name") + "\\cindex");
        //                string[] valname = subkey3.GetValueNames();
        //                int valcnt = subkey3.ValueCount;
        //                string data;
        //                for (int i = 0; i < valcnt; )
        //                {
        //                    data = subkey3.GetValue(valname[i]).ToString();
        //                    if (data != "")
        //                    {
        //                        //MessageBox.Show("Sorry !!! You Have Done it Before...");
        //                        return data + "~" + subkey3;
        //                    }
        //                    break;
        //                }
        //            }
        //        }
        //        return "0~0";
        //    }
        //    else if (IntPtr.Size == 8)
        //    {
        //        //-------- check for "JULY2017" key for windows 7 ---------

        //        RegistryKey key = Registry.LocalMachine.OpenSubKey("Software\\Wow6432Node");

        //        int cnt = key.SubKeyCount;
        //        int flag = 0;
        //        string[] subkeys = key.GetSubKeyNames();
        //        for (int i = 0; i < cnt; i++)
        //        {
        //            string str = subkeys[i];
        //            if (str == Resources.ResourceManager.GetString("Registry_Name"))
        //            {
        //                flag = 1;
        //                break;
        //            }
        //        }
        //        if (flag == 0)
        //        {
        //            // MessageBox.Show("The System is not inspected yet... Please Wait !!!");
        //            RegistryKey key1 = Registry.LocalMachine.CreateSubKey("Software\\Wow6432Node\\" + Resources.ResourceManager.GetString("Registry_Name"));
        //        }
        //        else if (flag == 1)
        //        {
        //            RegistryKey dttkey = Registry.LocalMachine.CreateSubKey("Software\\Wow6432Node\\" + Resources.ResourceManager.GetString("Registry_Name"));
        //            int count1 = dttkey.SubKeyCount;
        //            int flag1 = 0;
        //            string[] subkeys1 = dttkey.GetSubKeyNames();
        //            for (int i = 0; i < count1; i++)
        //            {
        //                string str1 = subkeys1[i];
        //                if (str1 == "cindex")
        //                {
        //                    flag1 = 1;
        //                    break;
        //                }
        //            }
        //            if (flag1 == 0)
        //            {
        //                RegistryKey subkey3 = Registry.LocalMachine.CreateSubKey("Software\\Wow6432Node\\" + Resources.ResourceManager.GetString("Registry_Name") + "\\cindex");
        //                return "0~0";
        //            }
        //            else
        //            {
        //                //string cindex ="0101003";
        //                // string cindex = "cindexno";
        //                RegistryKey subkey3 = Registry.LocalMachine.OpenSubKey("Software\\Wow6432Node\\" + Resources.ResourceManager.GetString("Registry_Name") + "\\cindex");
        //                string[] valname = subkey3.GetValueNames();
        //                //string[] valname = cs.Cindexno;
        //                int valcnt = subkey3.ValueCount;
        //                string data;
        //                for (int i = 0; i < valcnt; )
        //                {
        //                    data = subkey3.GetValue(valname[i]).ToString();
        //                    if (data != "")
        //                    {
        //                        //MessageBox.Show("Sorry !!! You Have Done it Before...");
        //                        return data + "~" + subkey3;
        //                    }
        //                    break;
        //                }
        //            }
        //        }
        //        return "0~0";
        //    }
        //    return "0~0";
        //}
    }
}
