﻿namespace Assessment_Tool
{
    partial class QueAnswer178
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QueAnswer178));
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.Q3BR1Q18 = new System.Windows.Forms.RadioButton();
            this.Q3BR2Q18 = new System.Windows.Forms.RadioButton();
            this.Q3BR3Q18 = new System.Windows.Forms.RadioButton();
            this.Q3BR4Q18 = new System.Windows.Forms.RadioButton();
            this.groupBox33 = new System.Windows.Forms.GroupBox();
            this.Q3BR1Q12 = new System.Windows.Forms.RadioButton();
            this.Q3BR2Q12 = new System.Windows.Forms.RadioButton();
            this.Q3BR3Q12 = new System.Windows.Forms.RadioButton();
            this.Q3BR4Q12 = new System.Windows.Forms.RadioButton();
            this.que32 = new System.Windows.Forms.TextBox();
            this.que38 = new System.Windows.Forms.TextBox();
            this.que33 = new System.Windows.Forms.TextBox();
            this.groupBox49 = new System.Windows.Forms.GroupBox();
            this.Q3BR1Q11 = new System.Windows.Forms.RadioButton();
            this.Q3BR2Q11 = new System.Windows.Forms.RadioButton();
            this.Q3BR3Q11 = new System.Windows.Forms.RadioButton();
            this.Q3BR4Q11 = new System.Windows.Forms.RadioButton();
            this.que31 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.que37 = new System.Windows.Forms.TextBox();
            this.que36 = new System.Windows.Forms.TextBox();
            this.que35 = new System.Windows.Forms.TextBox();
            this.que34 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.que39 = new System.Windows.Forms.TextBox();
            this.que40 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.btn_Q3B_submit = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox34 = new System.Windows.Forms.GroupBox();
            this.Q3BR1Q13 = new System.Windows.Forms.RadioButton();
            this.Q3BR2Q13 = new System.Windows.Forms.RadioButton();
            this.Q3BR3Q13 = new System.Windows.Forms.RadioButton();
            this.Q3BR4Q13 = new System.Windows.Forms.RadioButton();
            this.groupBox35 = new System.Windows.Forms.GroupBox();
            this.Q3BR1Q14 = new System.Windows.Forms.RadioButton();
            this.Q3BR2Q14 = new System.Windows.Forms.RadioButton();
            this.Q3BR3Q14 = new System.Windows.Forms.RadioButton();
            this.Q3BR4Q14 = new System.Windows.Forms.RadioButton();
            this.groupBox36 = new System.Windows.Forms.GroupBox();
            this.Q3BR1Q15 = new System.Windows.Forms.RadioButton();
            this.Q3BR2Q15 = new System.Windows.Forms.RadioButton();
            this.Q3BR3Q15 = new System.Windows.Forms.RadioButton();
            this.Q3BR4Q15 = new System.Windows.Forms.RadioButton();
            this.groupBox37 = new System.Windows.Forms.GroupBox();
            this.Q3BR1Q16 = new System.Windows.Forms.RadioButton();
            this.Q3BR2Q16 = new System.Windows.Forms.RadioButton();
            this.Q3BR3Q16 = new System.Windows.Forms.RadioButton();
            this.Q3BR4Q16 = new System.Windows.Forms.RadioButton();
            this.groupBox38 = new System.Windows.Forms.GroupBox();
            this.Q3BR1Q17 = new System.Windows.Forms.RadioButton();
            this.Q3BR2Q17 = new System.Windows.Forms.RadioButton();
            this.Q3BR3Q17 = new System.Windows.Forms.RadioButton();
            this.Q3BR4Q17 = new System.Windows.Forms.RadioButton();
            this.groupBox39 = new System.Windows.Forms.GroupBox();
            this.Q3BR1Q19 = new System.Windows.Forms.RadioButton();
            this.Q3BR2Q19 = new System.Windows.Forms.RadioButton();
            this.Q3BR3Q19 = new System.Windows.Forms.RadioButton();
            this.Q3BR4Q19 = new System.Windows.Forms.RadioButton();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.Q3BR1Q20 = new System.Windows.Forms.RadioButton();
            this.Q3BR2Q20 = new System.Windows.Forms.RadioButton();
            this.Q3BR3Q20 = new System.Windows.Forms.RadioButton();
            this.Q3BR4Q20 = new System.Windows.Forms.RadioButton();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.Q3AR1Q4 = new System.Windows.Forms.RadioButton();
            this.Q3AR2Q4 = new System.Windows.Forms.RadioButton();
            this.Q3AR3Q4 = new System.Windows.Forms.RadioButton();
            this.Q3AR4Q4 = new System.Windows.Forms.RadioButton();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.Q3AR1Q3 = new System.Windows.Forms.RadioButton();
            this.Q3AR2Q3 = new System.Windows.Forms.RadioButton();
            this.Q3AR3Q3 = new System.Windows.Forms.RadioButton();
            this.Q3AR4Q3 = new System.Windows.Forms.RadioButton();
            this.groupBox31 = new System.Windows.Forms.GroupBox();
            this.Q3AR1Q1 = new System.Windows.Forms.RadioButton();
            this.Q3AR2Q1 = new System.Windows.Forms.RadioButton();
            this.Q3AR3Q1 = new System.Windows.Forms.RadioButton();
            this.Q3AR4Q1 = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_mcqa1_view = new System.Windows.Forms.Button();
            this.btn_Q3A_submit = new System.Windows.Forms.Button();
            this.que23 = new System.Windows.Forms.TextBox();
            this.que21 = new System.Windows.Forms.TextBox();
            this.q23 = new System.Windows.Forms.Label();
            this.q22 = new System.Windows.Forms.Label();
            this.que27 = new System.Windows.Forms.TextBox();
            this.que26 = new System.Windows.Forms.TextBox();
            this.que25 = new System.Windows.Forms.TextBox();
            this.que24 = new System.Windows.Forms.TextBox();
            this.que22 = new System.Windows.Forms.TextBox();
            this.q21 = new System.Windows.Forms.Label();
            this.q24 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.que28 = new System.Windows.Forms.TextBox();
            this.que29 = new System.Windows.Forms.TextBox();
            this.que30 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.Q3AR1Q2 = new System.Windows.Forms.RadioButton();
            this.Q3AR2Q2 = new System.Windows.Forms.RadioButton();
            this.Q3AR3Q2 = new System.Windows.Forms.RadioButton();
            this.Q3AR4Q2 = new System.Windows.Forms.RadioButton();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.Q3AR1Q5 = new System.Windows.Forms.RadioButton();
            this.Q3AR2Q5 = new System.Windows.Forms.RadioButton();
            this.Q3AR3Q5 = new System.Windows.Forms.RadioButton();
            this.Q3AR4Q5 = new System.Windows.Forms.RadioButton();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.Q3AR1Q6 = new System.Windows.Forms.RadioButton();
            this.Q3AR2Q6 = new System.Windows.Forms.RadioButton();
            this.Q3AR3Q6 = new System.Windows.Forms.RadioButton();
            this.Q3AR4Q6 = new System.Windows.Forms.RadioButton();
            this.groupBox28 = new System.Windows.Forms.GroupBox();
            this.Q3AR1Q7 = new System.Windows.Forms.RadioButton();
            this.Q3AR2Q7 = new System.Windows.Forms.RadioButton();
            this.Q3AR3Q7 = new System.Windows.Forms.RadioButton();
            this.Q3AR4Q7 = new System.Windows.Forms.RadioButton();
            this.groupBox29 = new System.Windows.Forms.GroupBox();
            this.Q3AR1Q8 = new System.Windows.Forms.RadioButton();
            this.Q3AR2Q8 = new System.Windows.Forms.RadioButton();
            this.Q3AR3Q8 = new System.Windows.Forms.RadioButton();
            this.Q3AR4Q8 = new System.Windows.Forms.RadioButton();
            this.groupBox30 = new System.Windows.Forms.GroupBox();
            this.Q3AR1Q9 = new System.Windows.Forms.RadioButton();
            this.Q3AR2Q9 = new System.Windows.Forms.RadioButton();
            this.Q3AR3Q9 = new System.Windows.Forms.RadioButton();
            this.Q3AR4Q9 = new System.Windows.Forms.RadioButton();
            this.groupBox32 = new System.Windows.Forms.GroupBox();
            this.Q3AR1Q10 = new System.Windows.Forms.RadioButton();
            this.Q3AR2Q10 = new System.Windows.Forms.RadioButton();
            this.Q3AR3Q10 = new System.Windows.Forms.RadioButton();
            this.Q3AR4Q10 = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel_fib = new System.Windows.Forms.TableLayoutPanel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.btn_view = new System.Windows.Forms.Button();
            this.btn_Q1_submit = new System.Windows.Forms.Button();
            this.txtans10 = new System.Windows.Forms.TextBox();
            this.txtans9 = new System.Windows.Forms.TextBox();
            this.txtans8 = new System.Windows.Forms.TextBox();
            this.txtans7 = new System.Windows.Forms.TextBox();
            this.txtans6 = new System.Windows.Forms.TextBox();
            this.txtans5 = new System.Windows.Forms.TextBox();
            this.txtans4 = new System.Windows.Forms.TextBox();
            this.txtans3 = new System.Windows.Forms.TextBox();
            this.txtans2 = new System.Windows.Forms.TextBox();
            this.que10 = new System.Windows.Forms.TextBox();
            this.q9 = new System.Windows.Forms.Label();
            this.q8 = new System.Windows.Forms.Label();
            this.q7 = new System.Windows.Forms.Label();
            this.q6 = new System.Windows.Forms.Label();
            this.que3 = new System.Windows.Forms.TextBox();
            this.que9 = new System.Windows.Forms.TextBox();
            this.que8 = new System.Windows.Forms.TextBox();
            this.que7 = new System.Windows.Forms.TextBox();
            this.que5 = new System.Windows.Forms.TextBox();
            this.que4 = new System.Windows.Forms.TextBox();
            this.que2 = new System.Windows.Forms.TextBox();
            this.txtans1 = new System.Windows.Forms.TextBox();
            this.q5 = new System.Windows.Forms.Label();
            this.q4 = new System.Windows.Forms.Label();
            this.q3 = new System.Windows.Forms.Label();
            this.q2 = new System.Windows.Forms.Label();
            this.q1 = new System.Windows.Forms.Label();
            this.que6 = new System.Windows.Forms.TextBox();
            this.que1 = new System.Windows.Forms.TextBox();
            this.q10 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.que15 = new System.Windows.Forms.TextBox();
            this.q17 = new System.Windows.Forms.Label();
            this.q16 = new System.Windows.Forms.Label();
            this.q15 = new System.Windows.Forms.Label();
            this.q14 = new System.Windows.Forms.Label();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.rb_tf19 = new System.Windows.Forms.RadioButton();
            this.rb_tf20 = new System.Windows.Forms.RadioButton();
            this.que20 = new System.Windows.Forms.TextBox();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.rb_tf17 = new System.Windows.Forms.RadioButton();
            this.rb_tf18 = new System.Windows.Forms.RadioButton();
            this.que19 = new System.Windows.Forms.TextBox();
            this.que18 = new System.Windows.Forms.TextBox();
            this.que17 = new System.Windows.Forms.TextBox();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.rb_tf13 = new System.Windows.Forms.RadioButton();
            this.rb_tf14 = new System.Windows.Forms.RadioButton();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.rb_tf11 = new System.Windows.Forms.RadioButton();
            this.rb_tf12 = new System.Windows.Forms.RadioButton();
            this.gb_middle = new System.Windows.Forms.GroupBox();
            this.rb_tf9 = new System.Windows.Forms.RadioButton();
            this.rb_tf10 = new System.Windows.Forms.RadioButton();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.rb_tf7 = new System.Windows.Forms.RadioButton();
            this.rb_tf8 = new System.Windows.Forms.RadioButton();
            this.que16 = new System.Windows.Forms.TextBox();
            this.que14 = new System.Windows.Forms.TextBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.rb_tf5 = new System.Windows.Forms.RadioButton();
            this.rb_tf6 = new System.Windows.Forms.RadioButton();
            this.que13 = new System.Windows.Forms.TextBox();
            this.q12 = new System.Windows.Forms.Label();
            this.q18 = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.rb_tf3 = new System.Windows.Forms.RadioButton();
            this.rb_tf4 = new System.Windows.Forms.RadioButton();
            this.que12 = new System.Windows.Forms.TextBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.rb_tf1 = new System.Windows.Forms.RadioButton();
            this.rb_tf2 = new System.Windows.Forms.RadioButton();
            this.que11 = new System.Windows.Forms.TextBox();
            this.q11 = new System.Windows.Forms.Label();
            this.q13 = new System.Windows.Forms.Label();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.rb_tf15 = new System.Windows.Forms.RadioButton();
            this.rb_tf16 = new System.Windows.Forms.RadioButton();
            this.q19 = new System.Windows.Forms.Label();
            this.q20 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.btn_tf_view = new System.Windows.Forms.Button();
            this.btn_Q2_submit = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tab_Q1 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.groupBox55 = new System.Windows.Forms.GroupBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.groupBox53 = new System.Windows.Forms.GroupBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.groupBox52 = new System.Windows.Forms.GroupBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.groupBox51 = new System.Windows.Forms.GroupBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.groupBox50 = new System.Windows.Forms.GroupBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.groupBox48 = new System.Windows.Forms.GroupBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.groupBox47 = new System.Windows.Forms.GroupBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.txtQ1Ans10 = new System.Windows.Forms.TextBox();
            this.R10 = new System.Windows.Forms.CheckBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.txtQ1Ans9 = new System.Windows.Forms.TextBox();
            this.R9 = new System.Windows.Forms.CheckBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.txtQ1Ans8 = new System.Windows.Forms.TextBox();
            this.R8 = new System.Windows.Forms.CheckBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtQ1Ans7 = new System.Windows.Forms.TextBox();
            this.R7 = new System.Windows.Forms.CheckBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txtQ1Ans6 = new System.Windows.Forms.TextBox();
            this.R6 = new System.Windows.Forms.CheckBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtQ1Ans5 = new System.Windows.Forms.TextBox();
            this.R5 = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtQ1Ans4 = new System.Windows.Forms.TextBox();
            this.R4 = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtQ1Ans3 = new System.Windows.Forms.TextBox();
            this.R3 = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.R2 = new System.Windows.Forms.CheckBox();
            this.txtQ1Ans2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtQ6 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtQ2 = new System.Windows.Forms.TextBox();
            this.txtQ4 = new System.Windows.Forms.TextBox();
            this.txtQ5 = new System.Windows.Forms.TextBox();
            this.txtQ7 = new System.Windows.Forms.TextBox();
            this.txtQ8 = new System.Windows.Forms.TextBox();
            this.txtQ9 = new System.Windows.Forms.TextBox();
            this.txtQ3 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtQ10 = new System.Windows.Forms.TextBox();
            this.txtQ1 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.R1 = new System.Windows.Forms.CheckBox();
            this.txtQ1Ans1 = new System.Windows.Forms.TextBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.txtOutofTen = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox45 = new System.Windows.Forms.GroupBox();
            this.txtQ1MAns = new System.Windows.Forms.TextBox();
            this.groupBox46 = new System.Windows.Forms.GroupBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.groupBox54 = new System.Windows.Forms.GroupBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.allwrong = new System.Windows.Forms.CheckBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.tab_short_ans = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.label78 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.groupBox61 = new System.Windows.Forms.GroupBox();
            this.CmbAns7_8 = new System.Windows.Forms.ComboBox();
            this.label73 = new System.Windows.Forms.Label();
            this.groupBox60 = new System.Windows.Forms.GroupBox();
            this.CmbAns7_7 = new System.Windows.Forms.ComboBox();
            this.label72 = new System.Windows.Forms.Label();
            this.groupBox59 = new System.Windows.Forms.GroupBox();
            this.CmbAns7_6 = new System.Windows.Forms.ComboBox();
            this.label71 = new System.Windows.Forms.Label();
            this.groupBox58 = new System.Windows.Forms.GroupBox();
            this.CmbAns7_5 = new System.Windows.Forms.ComboBox();
            this.label70 = new System.Windows.Forms.Label();
            this.groupBox57 = new System.Windows.Forms.GroupBox();
            this.CmbAns7_4 = new System.Windows.Forms.ComboBox();
            this.label69 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.textQ7q1 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.groupBox40 = new System.Windows.Forms.GroupBox();
            this.label48 = new System.Windows.Forms.Label();
            this.textQ7Ans1 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.textQ7q2 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.textQ7Ans2 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.textQ7q3 = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.textQ7Ans3 = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.textQ7q4 = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.textQ7Ans4 = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.textQ7q5 = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.textQ7Ans5 = new System.Windows.Forms.TextBox();
            this.textQ7q6 = new System.Windows.Forms.TextBox();
            this.textQ7Ans6 = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.textQ7q7 = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.textQ7Ans7 = new System.Windows.Forms.TextBox();
            this.textQ7q8 = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.textQ7Ans8 = new System.Windows.Forms.TextBox();
            this.groupBox41 = new System.Windows.Forms.GroupBox();
            this.CmbAns7_1 = new System.Windows.Forms.ComboBox();
            this.label66 = new System.Windows.Forms.Label();
            this.groupBox42 = new System.Windows.Forms.GroupBox();
            this.CmbAns7_2 = new System.Windows.Forms.ComboBox();
            this.label67 = new System.Windows.Forms.Label();
            this.groupBox56 = new System.Windows.Forms.GroupBox();
            this.CmbAns7_3 = new System.Windows.Forms.ComboBox();
            this.label68 = new System.Windows.Forms.Label();
            this.tab_programme = new System.Windows.Forms.TabPage();
            this.panel17 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
            this.label81 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.groupBox63 = new System.Windows.Forms.GroupBox();
            this.Cmb8b2Ans = new System.Windows.Forms.ComboBox();
            this.label75 = new System.Windows.Forms.Label();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.textQ8q2 = new System.Windows.Forms.TextBox();
            this.textQ8Ans2 = new System.Windows.Forms.TextBox();
            this.textQ8q1 = new System.Windows.Forms.TextBox();
            this.groupBox44 = new System.Windows.Forms.GroupBox();
            this.Cmb8a2Ans = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.textQ8Ans1 = new System.Windows.Forms.TextBox();
            this.textQ8q3 = new System.Windows.Forms.TextBox();
            this.textQ8Ans3 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox43 = new System.Windows.Forms.GroupBox();
            this.Cmb8a1Ans = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.textQ8q4 = new System.Windows.Forms.TextBox();
            this.textQ8Ans4 = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.groupBox62 = new System.Windows.Forms.GroupBox();
            this.Cmb8b1Ans = new System.Windows.Forms.ComboBox();
            this.label74 = new System.Windows.Forms.Label();
            this.txtPid = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.btnGiveUp = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.grid1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.q7a = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.q8b = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TotalMarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblStream = new System.Windows.Forms.Label();
            this.lblStremName = new System.Windows.Forms.Label();
            this.lblMIndex = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.Teacher_Id = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tab_Q1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox55.SuspendLayout();
            this.groupBox53.SuspendLayout();
            this.groupBox52.SuspendLayout();
            this.groupBox51.SuspendLayout();
            this.groupBox50.SuspendLayout();
            this.groupBox48.SuspendLayout();
            this.groupBox47.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox45.SuspendLayout();
            this.groupBox46.SuspendLayout();
            this.groupBox54.SuspendLayout();
            this.tab_short_ans.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.groupBox61.SuspendLayout();
            this.groupBox60.SuspendLayout();
            this.groupBox59.SuspendLayout();
            this.groupBox58.SuspendLayout();
            this.groupBox57.SuspendLayout();
            this.groupBox40.SuspendLayout();
            this.groupBox41.SuspendLayout();
            this.groupBox42.SuspendLayout();
            this.groupBox56.SuspendLayout();
            this.tab_programme.SuspendLayout();
            this.panel17.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.groupBox63.SuspendLayout();
            this.groupBox44.SuspendLayout();
            this.groupBox43.SuspendLayout();
            this.groupBox62.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel4.Location = new System.Drawing.Point(21, 2);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 23;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(728, 2004);
            this.tableLayoutPanel4.TabIndex = 152;
            // 
            // groupBox18
            // 
            this.groupBox18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox18.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox18.Location = new System.Drawing.Point(79, 1425);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(644, 121);
            this.groupBox18.TabIndex = 39;
            this.groupBox18.TabStop = false;
            // 
            // Q3BR1Q18
            // 
            this.Q3BR1Q18.AutoSize = true;
            this.Q3BR1Q18.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR1Q18.Location = new System.Drawing.Point(24, 11);
            this.Q3BR1Q18.Name = "Q3BR1Q18";
            this.Q3BR1Q18.Size = new System.Drawing.Size(14, 13);
            this.Q3BR1Q18.TabIndex = 4;
            this.Q3BR1Q18.TabStop = true;
            this.Q3BR1Q18.UseVisualStyleBackColor = true;
            // 
            // Q3BR2Q18
            // 
            this.Q3BR2Q18.AutoSize = true;
            this.Q3BR2Q18.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR2Q18.Location = new System.Drawing.Point(24, 40);
            this.Q3BR2Q18.Name = "Q3BR2Q18";
            this.Q3BR2Q18.Size = new System.Drawing.Size(14, 13);
            this.Q3BR2Q18.TabIndex = 5;
            this.Q3BR2Q18.TabStop = true;
            this.Q3BR2Q18.UseVisualStyleBackColor = true;
            // 
            // Q3BR3Q18
            // 
            this.Q3BR3Q18.AutoSize = true;
            this.Q3BR3Q18.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR3Q18.Location = new System.Drawing.Point(24, 68);
            this.Q3BR3Q18.Name = "Q3BR3Q18";
            this.Q3BR3Q18.Size = new System.Drawing.Size(14, 13);
            this.Q3BR3Q18.TabIndex = 6;
            this.Q3BR3Q18.TabStop = true;
            this.Q3BR3Q18.UseVisualStyleBackColor = true;
            // 
            // Q3BR4Q18
            // 
            this.Q3BR4Q18.AutoSize = true;
            this.Q3BR4Q18.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR4Q18.Location = new System.Drawing.Point(24, 98);
            this.Q3BR4Q18.Name = "Q3BR4Q18";
            this.Q3BR4Q18.Size = new System.Drawing.Size(14, 13);
            this.Q3BR4Q18.TabIndex = 7;
            this.Q3BR4Q18.TabStop = true;
            this.Q3BR4Q18.UseVisualStyleBackColor = true;
            // 
            // groupBox33
            // 
            this.groupBox33.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox33.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox33.Location = new System.Drawing.Point(79, 261);
            this.groupBox33.Name = "groupBox33";
            this.groupBox33.Size = new System.Drawing.Size(644, 121);
            this.groupBox33.TabIndex = 33;
            this.groupBox33.TabStop = false;
            // 
            // Q3BR1Q12
            // 
            this.Q3BR1Q12.AutoSize = true;
            this.Q3BR1Q12.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR1Q12.Location = new System.Drawing.Point(24, 11);
            this.Q3BR1Q12.Name = "Q3BR1Q12";
            this.Q3BR1Q12.Size = new System.Drawing.Size(14, 13);
            this.Q3BR1Q12.TabIndex = 4;
            this.Q3BR1Q12.TabStop = true;
            this.Q3BR1Q12.UseVisualStyleBackColor = true;
            // 
            // Q3BR2Q12
            // 
            this.Q3BR2Q12.AutoSize = true;
            this.Q3BR2Q12.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR2Q12.Location = new System.Drawing.Point(24, 40);
            this.Q3BR2Q12.Name = "Q3BR2Q12";
            this.Q3BR2Q12.Size = new System.Drawing.Size(14, 13);
            this.Q3BR2Q12.TabIndex = 5;
            this.Q3BR2Q12.TabStop = true;
            this.Q3BR2Q12.UseVisualStyleBackColor = true;
            // 
            // Q3BR3Q12
            // 
            this.Q3BR3Q12.AutoSize = true;
            this.Q3BR3Q12.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR3Q12.Location = new System.Drawing.Point(24, 68);
            this.Q3BR3Q12.Name = "Q3BR3Q12";
            this.Q3BR3Q12.Size = new System.Drawing.Size(14, 13);
            this.Q3BR3Q12.TabIndex = 6;
            this.Q3BR3Q12.TabStop = true;
            this.Q3BR3Q12.UseVisualStyleBackColor = true;
            // 
            // Q3BR4Q12
            // 
            this.Q3BR4Q12.AutoSize = true;
            this.Q3BR4Q12.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR4Q12.Location = new System.Drawing.Point(24, 98);
            this.Q3BR4Q12.Name = "Q3BR4Q12";
            this.Q3BR4Q12.Size = new System.Drawing.Size(14, 13);
            this.Q3BR4Q12.TabIndex = 7;
            this.Q3BR4Q12.TabStop = true;
            this.Q3BR4Q12.UseVisualStyleBackColor = true;
            // 
            // que32
            // 
            this.que32.Location = new System.Drawing.Point(79, 199);
            this.que32.Multiline = true;
            this.que32.Name = "que32";
            this.que32.ReadOnly = true;
            this.que32.Size = new System.Drawing.Size(644, 54);
            this.que32.TabIndex = 54;
            // 
            // que38
            // 
            this.que38.BackColor = System.Drawing.Color.Gainsboro;
            this.que38.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que38.Location = new System.Drawing.Point(79, 1363);
            this.que38.Multiline = true;
            this.que38.Name = "que38";
            this.que38.ReadOnly = true;
            this.que38.Size = new System.Drawing.Size(644, 54);
            this.que38.TabIndex = 50;
            // 
            // que33
            // 
            this.que33.BackColor = System.Drawing.Color.Gainsboro;
            this.que33.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que33.Location = new System.Drawing.Point(79, 393);
            this.que33.Multiline = true;
            this.que33.Name = "que33";
            this.que33.ReadOnly = true;
            this.que33.Size = new System.Drawing.Size(644, 54);
            this.que33.TabIndex = 35;
            // 
            // groupBox49
            // 
            this.groupBox49.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox49.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox49.Location = new System.Drawing.Point(79, 67);
            this.groupBox49.Name = "groupBox49";
            this.groupBox49.Size = new System.Drawing.Size(644, 121);
            this.groupBox49.TabIndex = 32;
            this.groupBox49.TabStop = false;
            // 
            // Q3BR1Q11
            // 
            this.Q3BR1Q11.AutoSize = true;
            this.Q3BR1Q11.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR1Q11.Location = new System.Drawing.Point(24, 11);
            this.Q3BR1Q11.Name = "Q3BR1Q11";
            this.Q3BR1Q11.Size = new System.Drawing.Size(14, 13);
            this.Q3BR1Q11.TabIndex = 4;
            this.Q3BR1Q11.TabStop = true;
            this.Q3BR1Q11.UseVisualStyleBackColor = true;
            // 
            // Q3BR2Q11
            // 
            this.Q3BR2Q11.AutoSize = true;
            this.Q3BR2Q11.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR2Q11.Location = new System.Drawing.Point(24, 40);
            this.Q3BR2Q11.Name = "Q3BR2Q11";
            this.Q3BR2Q11.Size = new System.Drawing.Size(14, 13);
            this.Q3BR2Q11.TabIndex = 5;
            this.Q3BR2Q11.TabStop = true;
            this.Q3BR2Q11.UseVisualStyleBackColor = true;
            // 
            // Q3BR3Q11
            // 
            this.Q3BR3Q11.AutoSize = true;
            this.Q3BR3Q11.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR3Q11.Location = new System.Drawing.Point(24, 68);
            this.Q3BR3Q11.Name = "Q3BR3Q11";
            this.Q3BR3Q11.Size = new System.Drawing.Size(14, 13);
            this.Q3BR3Q11.TabIndex = 6;
            this.Q3BR3Q11.TabStop = true;
            this.Q3BR3Q11.UseVisualStyleBackColor = true;
            // 
            // Q3BR4Q11
            // 
            this.Q3BR4Q11.AutoSize = true;
            this.Q3BR4Q11.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR4Q11.Location = new System.Drawing.Point(24, 98);
            this.Q3BR4Q11.Name = "Q3BR4Q11";
            this.Q3BR4Q11.Size = new System.Drawing.Size(14, 13);
            this.Q3BR4Q11.TabIndex = 7;
            this.Q3BR4Q11.TabStop = true;
            this.Q3BR4Q11.UseVisualStyleBackColor = true;
            // 
            // que31
            // 
            this.que31.BackColor = System.Drawing.Color.Gainsboro;
            this.que31.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que31.Location = new System.Drawing.Point(79, 5);
            this.que31.Multiline = true;
            this.que31.Name = "que31";
            this.que31.ReadOnly = true;
            this.que31.Size = new System.Drawing.Size(644, 54);
            this.que31.TabIndex = 31;
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(23, 413);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(30, 13);
            this.label15.TabIndex = 48;
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(23, 219);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(30, 13);
            this.label14.TabIndex = 47;
            // 
            // que37
            // 
            this.que37.BackColor = System.Drawing.Color.Gainsboro;
            this.que37.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que37.Location = new System.Drawing.Point(79, 1169);
            this.que37.Multiline = true;
            this.que37.Name = "que37";
            this.que37.ReadOnly = true;
            this.que37.Size = new System.Drawing.Size(644, 54);
            this.que37.TabIndex = 42;
            // 
            // que36
            // 
            this.que36.BackColor = System.Drawing.Color.Gainsboro;
            this.que36.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que36.Location = new System.Drawing.Point(79, 975);
            this.que36.Multiline = true;
            this.que36.Name = "que36";
            this.que36.ReadOnly = true;
            this.que36.Size = new System.Drawing.Size(644, 54);
            this.que36.TabIndex = 41;
            // 
            // que35
            // 
            this.que35.BackColor = System.Drawing.Color.Gainsboro;
            this.que35.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que35.Location = new System.Drawing.Point(79, 781);
            this.que35.Multiline = true;
            this.que35.Name = "que35";
            this.que35.ReadOnly = true;
            this.que35.Size = new System.Drawing.Size(644, 54);
            this.que35.TabIndex = 43;
            // 
            // que34
            // 
            this.que34.BackColor = System.Drawing.Color.Gainsboro;
            this.que34.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que34.Location = new System.Drawing.Point(79, 587);
            this.que34.Multiline = true;
            this.que34.Name = "que34";
            this.que34.ReadOnly = true;
            this.que34.Size = new System.Drawing.Size(644, 54);
            this.que34.TabIndex = 38;
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(23, 25);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(30, 13);
            this.label13.TabIndex = 33;
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(23, 607);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(30, 13);
            this.label12.TabIndex = 34;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(23, 801);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(30, 13);
            this.label11.TabIndex = 34;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(23, 995);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 13);
            this.label10.TabIndex = 34;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(23, 1189);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(30, 13);
            this.label9.TabIndex = 49;
            // 
            // que39
            // 
            this.que39.BackColor = System.Drawing.Color.Gainsboro;
            this.que39.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que39.Location = new System.Drawing.Point(79, 1557);
            this.que39.Multiline = true;
            this.que39.Name = "que39";
            this.que39.ReadOnly = true;
            this.que39.Size = new System.Drawing.Size(644, 54);
            this.que39.TabIndex = 51;
            // 
            // que40
            // 
            this.que40.BackColor = System.Drawing.Color.Gainsboro;
            this.que40.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que40.Location = new System.Drawing.Point(79, 1751);
            this.que40.Multiline = true;
            this.que40.Name = "que40";
            this.que40.ReadOnly = true;
            this.que40.Size = new System.Drawing.Size(644, 54);
            this.que40.TabIndex = 52;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(23, 1383);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 13);
            this.label6.TabIndex = 50;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(23, 1577);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 13);
            this.label5.TabIndex = 50;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(23, 1771);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 53;
            // 
            // panel21
            // 
            this.panel21.Location = new System.Drawing.Point(79, 1945);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(545, 35);
            this.panel21.TabIndex = 4;
            // 
            // btn_Q3B_submit
            // 
            this.btn_Q3B_submit.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Q3B_submit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.btn_Q3B_submit.Location = new System.Drawing.Point(89, -1);
            this.btn_Q3B_submit.Name = "btn_Q3B_submit";
            this.btn_Q3B_submit.Size = new System.Drawing.Size(81, 35);
            this.btn_Q3B_submit.TabIndex = 55;
            this.btn_Q3B_submit.Text = "Submit";
            this.btn_Q3B_submit.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.SteelBlue;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.button1.Location = new System.Drawing.Point(283, -1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(118, 35);
            this.button1.TabIndex = 56;
            this.button1.Text = "View Answer";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            // 
            // groupBox34
            // 
            this.groupBox34.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox34.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox34.Location = new System.Drawing.Point(79, 455);
            this.groupBox34.Name = "groupBox34";
            this.groupBox34.Size = new System.Drawing.Size(644, 121);
            this.groupBox34.TabIndex = 34;
            this.groupBox34.TabStop = false;
            // 
            // Q3BR1Q13
            // 
            this.Q3BR1Q13.AutoSize = true;
            this.Q3BR1Q13.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR1Q13.Location = new System.Drawing.Point(24, 11);
            this.Q3BR1Q13.Name = "Q3BR1Q13";
            this.Q3BR1Q13.Size = new System.Drawing.Size(14, 13);
            this.Q3BR1Q13.TabIndex = 4;
            this.Q3BR1Q13.TabStop = true;
            this.Q3BR1Q13.UseVisualStyleBackColor = true;
            // 
            // Q3BR2Q13
            // 
            this.Q3BR2Q13.AutoSize = true;
            this.Q3BR2Q13.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR2Q13.Location = new System.Drawing.Point(24, 40);
            this.Q3BR2Q13.Name = "Q3BR2Q13";
            this.Q3BR2Q13.Size = new System.Drawing.Size(14, 13);
            this.Q3BR2Q13.TabIndex = 5;
            this.Q3BR2Q13.TabStop = true;
            this.Q3BR2Q13.UseVisualStyleBackColor = true;
            // 
            // Q3BR3Q13
            // 
            this.Q3BR3Q13.AutoSize = true;
            this.Q3BR3Q13.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR3Q13.Location = new System.Drawing.Point(24, 68);
            this.Q3BR3Q13.Name = "Q3BR3Q13";
            this.Q3BR3Q13.Size = new System.Drawing.Size(14, 13);
            this.Q3BR3Q13.TabIndex = 6;
            this.Q3BR3Q13.TabStop = true;
            this.Q3BR3Q13.UseVisualStyleBackColor = true;
            // 
            // Q3BR4Q13
            // 
            this.Q3BR4Q13.AutoSize = true;
            this.Q3BR4Q13.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR4Q13.Location = new System.Drawing.Point(24, 98);
            this.Q3BR4Q13.Name = "Q3BR4Q13";
            this.Q3BR4Q13.Size = new System.Drawing.Size(14, 13);
            this.Q3BR4Q13.TabIndex = 7;
            this.Q3BR4Q13.TabStop = true;
            this.Q3BR4Q13.UseVisualStyleBackColor = true;
            // 
            // groupBox35
            // 
            this.groupBox35.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox35.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox35.Location = new System.Drawing.Point(79, 649);
            this.groupBox35.Name = "groupBox35";
            this.groupBox35.Size = new System.Drawing.Size(644, 121);
            this.groupBox35.TabIndex = 35;
            this.groupBox35.TabStop = false;
            // 
            // Q3BR1Q14
            // 
            this.Q3BR1Q14.AutoSize = true;
            this.Q3BR1Q14.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR1Q14.Location = new System.Drawing.Point(24, 11);
            this.Q3BR1Q14.Name = "Q3BR1Q14";
            this.Q3BR1Q14.Size = new System.Drawing.Size(14, 13);
            this.Q3BR1Q14.TabIndex = 4;
            this.Q3BR1Q14.TabStop = true;
            this.Q3BR1Q14.UseVisualStyleBackColor = true;
            // 
            // Q3BR2Q14
            // 
            this.Q3BR2Q14.AutoSize = true;
            this.Q3BR2Q14.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR2Q14.Location = new System.Drawing.Point(24, 40);
            this.Q3BR2Q14.Name = "Q3BR2Q14";
            this.Q3BR2Q14.Size = new System.Drawing.Size(14, 13);
            this.Q3BR2Q14.TabIndex = 5;
            this.Q3BR2Q14.TabStop = true;
            this.Q3BR2Q14.UseVisualStyleBackColor = true;
            // 
            // Q3BR3Q14
            // 
            this.Q3BR3Q14.AutoSize = true;
            this.Q3BR3Q14.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR3Q14.Location = new System.Drawing.Point(24, 68);
            this.Q3BR3Q14.Name = "Q3BR3Q14";
            this.Q3BR3Q14.Size = new System.Drawing.Size(14, 13);
            this.Q3BR3Q14.TabIndex = 6;
            this.Q3BR3Q14.TabStop = true;
            this.Q3BR3Q14.UseVisualStyleBackColor = true;
            // 
            // Q3BR4Q14
            // 
            this.Q3BR4Q14.AutoSize = true;
            this.Q3BR4Q14.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR4Q14.Location = new System.Drawing.Point(24, 98);
            this.Q3BR4Q14.Name = "Q3BR4Q14";
            this.Q3BR4Q14.Size = new System.Drawing.Size(14, 13);
            this.Q3BR4Q14.TabIndex = 7;
            this.Q3BR4Q14.TabStop = true;
            this.Q3BR4Q14.UseVisualStyleBackColor = true;
            // 
            // groupBox36
            // 
            this.groupBox36.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox36.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox36.Location = new System.Drawing.Point(79, 843);
            this.groupBox36.Name = "groupBox36";
            this.groupBox36.Size = new System.Drawing.Size(644, 121);
            this.groupBox36.TabIndex = 36;
            this.groupBox36.TabStop = false;
            // 
            // Q3BR1Q15
            // 
            this.Q3BR1Q15.AutoSize = true;
            this.Q3BR1Q15.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR1Q15.Location = new System.Drawing.Point(24, 11);
            this.Q3BR1Q15.Name = "Q3BR1Q15";
            this.Q3BR1Q15.Size = new System.Drawing.Size(14, 13);
            this.Q3BR1Q15.TabIndex = 4;
            this.Q3BR1Q15.TabStop = true;
            this.Q3BR1Q15.UseVisualStyleBackColor = true;
            // 
            // Q3BR2Q15
            // 
            this.Q3BR2Q15.AutoSize = true;
            this.Q3BR2Q15.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR2Q15.Location = new System.Drawing.Point(24, 40);
            this.Q3BR2Q15.Name = "Q3BR2Q15";
            this.Q3BR2Q15.Size = new System.Drawing.Size(14, 13);
            this.Q3BR2Q15.TabIndex = 5;
            this.Q3BR2Q15.TabStop = true;
            this.Q3BR2Q15.UseVisualStyleBackColor = true;
            // 
            // Q3BR3Q15
            // 
            this.Q3BR3Q15.AutoSize = true;
            this.Q3BR3Q15.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR3Q15.Location = new System.Drawing.Point(24, 68);
            this.Q3BR3Q15.Name = "Q3BR3Q15";
            this.Q3BR3Q15.Size = new System.Drawing.Size(14, 13);
            this.Q3BR3Q15.TabIndex = 6;
            this.Q3BR3Q15.TabStop = true;
            this.Q3BR3Q15.UseVisualStyleBackColor = true;
            // 
            // Q3BR4Q15
            // 
            this.Q3BR4Q15.AutoSize = true;
            this.Q3BR4Q15.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR4Q15.Location = new System.Drawing.Point(24, 98);
            this.Q3BR4Q15.Name = "Q3BR4Q15";
            this.Q3BR4Q15.Size = new System.Drawing.Size(14, 13);
            this.Q3BR4Q15.TabIndex = 7;
            this.Q3BR4Q15.TabStop = true;
            this.Q3BR4Q15.UseVisualStyleBackColor = true;
            // 
            // groupBox37
            // 
            this.groupBox37.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox37.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox37.Location = new System.Drawing.Point(79, 1037);
            this.groupBox37.Name = "groupBox37";
            this.groupBox37.Size = new System.Drawing.Size(644, 121);
            this.groupBox37.TabIndex = 37;
            this.groupBox37.TabStop = false;
            // 
            // Q3BR1Q16
            // 
            this.Q3BR1Q16.AutoSize = true;
            this.Q3BR1Q16.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR1Q16.Location = new System.Drawing.Point(24, 11);
            this.Q3BR1Q16.Name = "Q3BR1Q16";
            this.Q3BR1Q16.Size = new System.Drawing.Size(14, 13);
            this.Q3BR1Q16.TabIndex = 4;
            this.Q3BR1Q16.TabStop = true;
            this.Q3BR1Q16.UseVisualStyleBackColor = true;
            // 
            // Q3BR2Q16
            // 
            this.Q3BR2Q16.AutoSize = true;
            this.Q3BR2Q16.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR2Q16.Location = new System.Drawing.Point(24, 40);
            this.Q3BR2Q16.Name = "Q3BR2Q16";
            this.Q3BR2Q16.Size = new System.Drawing.Size(14, 13);
            this.Q3BR2Q16.TabIndex = 5;
            this.Q3BR2Q16.TabStop = true;
            this.Q3BR2Q16.UseVisualStyleBackColor = true;
            // 
            // Q3BR3Q16
            // 
            this.Q3BR3Q16.AutoSize = true;
            this.Q3BR3Q16.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR3Q16.Location = new System.Drawing.Point(24, 68);
            this.Q3BR3Q16.Name = "Q3BR3Q16";
            this.Q3BR3Q16.Size = new System.Drawing.Size(14, 13);
            this.Q3BR3Q16.TabIndex = 6;
            this.Q3BR3Q16.TabStop = true;
            this.Q3BR3Q16.UseVisualStyleBackColor = true;
            // 
            // Q3BR4Q16
            // 
            this.Q3BR4Q16.AutoSize = true;
            this.Q3BR4Q16.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR4Q16.Location = new System.Drawing.Point(24, 98);
            this.Q3BR4Q16.Name = "Q3BR4Q16";
            this.Q3BR4Q16.Size = new System.Drawing.Size(14, 13);
            this.Q3BR4Q16.TabIndex = 7;
            this.Q3BR4Q16.TabStop = true;
            this.Q3BR4Q16.UseVisualStyleBackColor = true;
            // 
            // groupBox38
            // 
            this.groupBox38.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox38.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox38.Location = new System.Drawing.Point(79, 1231);
            this.groupBox38.Name = "groupBox38";
            this.groupBox38.Size = new System.Drawing.Size(644, 121);
            this.groupBox38.TabIndex = 38;
            this.groupBox38.TabStop = false;
            // 
            // Q3BR1Q17
            // 
            this.Q3BR1Q17.AutoSize = true;
            this.Q3BR1Q17.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR1Q17.Location = new System.Drawing.Point(24, 11);
            this.Q3BR1Q17.Name = "Q3BR1Q17";
            this.Q3BR1Q17.Size = new System.Drawing.Size(14, 13);
            this.Q3BR1Q17.TabIndex = 4;
            this.Q3BR1Q17.TabStop = true;
            this.Q3BR1Q17.UseVisualStyleBackColor = true;
            // 
            // Q3BR2Q17
            // 
            this.Q3BR2Q17.AutoSize = true;
            this.Q3BR2Q17.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR2Q17.Location = new System.Drawing.Point(24, 40);
            this.Q3BR2Q17.Name = "Q3BR2Q17";
            this.Q3BR2Q17.Size = new System.Drawing.Size(14, 13);
            this.Q3BR2Q17.TabIndex = 5;
            this.Q3BR2Q17.TabStop = true;
            this.Q3BR2Q17.UseVisualStyleBackColor = true;
            // 
            // Q3BR3Q17
            // 
            this.Q3BR3Q17.AutoSize = true;
            this.Q3BR3Q17.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR3Q17.Location = new System.Drawing.Point(24, 68);
            this.Q3BR3Q17.Name = "Q3BR3Q17";
            this.Q3BR3Q17.Size = new System.Drawing.Size(14, 13);
            this.Q3BR3Q17.TabIndex = 6;
            this.Q3BR3Q17.TabStop = true;
            this.Q3BR3Q17.UseVisualStyleBackColor = true;
            // 
            // Q3BR4Q17
            // 
            this.Q3BR4Q17.AutoSize = true;
            this.Q3BR4Q17.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR4Q17.Location = new System.Drawing.Point(24, 98);
            this.Q3BR4Q17.Name = "Q3BR4Q17";
            this.Q3BR4Q17.Size = new System.Drawing.Size(14, 13);
            this.Q3BR4Q17.TabIndex = 7;
            this.Q3BR4Q17.TabStop = true;
            this.Q3BR4Q17.UseVisualStyleBackColor = true;
            // 
            // groupBox39
            // 
            this.groupBox39.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox39.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox39.Location = new System.Drawing.Point(79, 1619);
            this.groupBox39.Name = "groupBox39";
            this.groupBox39.Size = new System.Drawing.Size(644, 121);
            this.groupBox39.TabIndex = 40;
            this.groupBox39.TabStop = false;
            // 
            // Q3BR1Q19
            // 
            this.Q3BR1Q19.AutoSize = true;
            this.Q3BR1Q19.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR1Q19.Location = new System.Drawing.Point(24, 11);
            this.Q3BR1Q19.Name = "Q3BR1Q19";
            this.Q3BR1Q19.Size = new System.Drawing.Size(14, 13);
            this.Q3BR1Q19.TabIndex = 4;
            this.Q3BR1Q19.TabStop = true;
            this.Q3BR1Q19.UseVisualStyleBackColor = true;
            // 
            // Q3BR2Q19
            // 
            this.Q3BR2Q19.AutoSize = true;
            this.Q3BR2Q19.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR2Q19.Location = new System.Drawing.Point(24, 40);
            this.Q3BR2Q19.Name = "Q3BR2Q19";
            this.Q3BR2Q19.Size = new System.Drawing.Size(14, 13);
            this.Q3BR2Q19.TabIndex = 5;
            this.Q3BR2Q19.TabStop = true;
            this.Q3BR2Q19.UseVisualStyleBackColor = true;
            // 
            // Q3BR3Q19
            // 
            this.Q3BR3Q19.AutoSize = true;
            this.Q3BR3Q19.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR3Q19.Location = new System.Drawing.Point(24, 68);
            this.Q3BR3Q19.Name = "Q3BR3Q19";
            this.Q3BR3Q19.Size = new System.Drawing.Size(14, 13);
            this.Q3BR3Q19.TabIndex = 6;
            this.Q3BR3Q19.TabStop = true;
            this.Q3BR3Q19.UseVisualStyleBackColor = true;
            // 
            // Q3BR4Q19
            // 
            this.Q3BR4Q19.AutoSize = true;
            this.Q3BR4Q19.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR4Q19.Location = new System.Drawing.Point(24, 98);
            this.Q3BR4Q19.Name = "Q3BR4Q19";
            this.Q3BR4Q19.Size = new System.Drawing.Size(14, 13);
            this.Q3BR4Q19.TabIndex = 7;
            this.Q3BR4Q19.TabStop = true;
            this.Q3BR4Q19.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox12.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox12.Location = new System.Drawing.Point(79, 1813);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(644, 121);
            this.groupBox12.TabIndex = 41;
            this.groupBox12.TabStop = false;
            // 
            // Q3BR1Q20
            // 
            this.Q3BR1Q20.AutoSize = true;
            this.Q3BR1Q20.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR1Q20.Location = new System.Drawing.Point(24, 11);
            this.Q3BR1Q20.Name = "Q3BR1Q20";
            this.Q3BR1Q20.Size = new System.Drawing.Size(14, 13);
            this.Q3BR1Q20.TabIndex = 4;
            this.Q3BR1Q20.TabStop = true;
            this.Q3BR1Q20.UseVisualStyleBackColor = true;
            // 
            // Q3BR2Q20
            // 
            this.Q3BR2Q20.AutoSize = true;
            this.Q3BR2Q20.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR2Q20.Location = new System.Drawing.Point(24, 40);
            this.Q3BR2Q20.Name = "Q3BR2Q20";
            this.Q3BR2Q20.Size = new System.Drawing.Size(14, 13);
            this.Q3BR2Q20.TabIndex = 5;
            this.Q3BR2Q20.TabStop = true;
            this.Q3BR2Q20.UseVisualStyleBackColor = true;
            // 
            // Q3BR3Q20
            // 
            this.Q3BR3Q20.AutoSize = true;
            this.Q3BR3Q20.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR3Q20.Location = new System.Drawing.Point(24, 68);
            this.Q3BR3Q20.Name = "Q3BR3Q20";
            this.Q3BR3Q20.Size = new System.Drawing.Size(14, 13);
            this.Q3BR3Q20.TabIndex = 6;
            this.Q3BR3Q20.TabStop = true;
            this.Q3BR3Q20.UseVisualStyleBackColor = true;
            // 
            // Q3BR4Q20
            // 
            this.Q3BR4Q20.AutoSize = true;
            this.Q3BR4Q20.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3BR4Q20.Location = new System.Drawing.Point(24, 98);
            this.Q3BR4Q20.Name = "Q3BR4Q20";
            this.Q3BR4Q20.Size = new System.Drawing.Size(14, 13);
            this.Q3BR4Q20.TabIndex = 7;
            this.Q3BR4Q20.TabStop = true;
            this.Q3BR4Q20.UseVisualStyleBackColor = true;
            // 
            // groupBox25
            // 
            this.groupBox25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox25.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox25.Location = new System.Drawing.Point(78, 649);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(570, 124);
            this.groupBox25.TabIndex = 35;
            this.groupBox25.TabStop = false;
            // 
            // Q3AR1Q4
            // 
            this.Q3AR1Q4.AutoSize = true;
            this.Q3AR1Q4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR1Q4.Location = new System.Drawing.Point(23, 14);
            this.Q3AR1Q4.Name = "Q3AR1Q4";
            this.Q3AR1Q4.Size = new System.Drawing.Size(14, 13);
            this.Q3AR1Q4.TabIndex = 0;
            this.Q3AR1Q4.TabStop = true;
            this.Q3AR1Q4.UseVisualStyleBackColor = true;
            // 
            // Q3AR2Q4
            // 
            this.Q3AR2Q4.AutoSize = true;
            this.Q3AR2Q4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR2Q4.Location = new System.Drawing.Point(23, 44);
            this.Q3AR2Q4.Name = "Q3AR2Q4";
            this.Q3AR2Q4.Size = new System.Drawing.Size(14, 13);
            this.Q3AR2Q4.TabIndex = 1;
            this.Q3AR2Q4.TabStop = true;
            this.Q3AR2Q4.UseVisualStyleBackColor = true;
            // 
            // Q3AR3Q4
            // 
            this.Q3AR3Q4.AutoSize = true;
            this.Q3AR3Q4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR3Q4.Location = new System.Drawing.Point(23, 72);
            this.Q3AR3Q4.Name = "Q3AR3Q4";
            this.Q3AR3Q4.Size = new System.Drawing.Size(14, 13);
            this.Q3AR3Q4.TabIndex = 2;
            this.Q3AR3Q4.TabStop = true;
            this.Q3AR3Q4.UseVisualStyleBackColor = true;
            // 
            // Q3AR4Q4
            // 
            this.Q3AR4Q4.AutoSize = true;
            this.Q3AR4Q4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR4Q4.Location = new System.Drawing.Point(23, 100);
            this.Q3AR4Q4.Name = "Q3AR4Q4";
            this.Q3AR4Q4.Size = new System.Drawing.Size(14, 13);
            this.Q3AR4Q4.TabIndex = 3;
            this.Q3AR4Q4.TabStop = true;
            this.Q3AR4Q4.UseVisualStyleBackColor = true;
            // 
            // groupBox24
            // 
            this.groupBox24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox24.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox24.Location = new System.Drawing.Point(78, 455);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(570, 124);
            this.groupBox24.TabIndex = 34;
            this.groupBox24.TabStop = false;
            // 
            // Q3AR1Q3
            // 
            this.Q3AR1Q3.AutoSize = true;
            this.Q3AR1Q3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR1Q3.Location = new System.Drawing.Point(23, 14);
            this.Q3AR1Q3.Name = "Q3AR1Q3";
            this.Q3AR1Q3.Size = new System.Drawing.Size(14, 13);
            this.Q3AR1Q3.TabIndex = 0;
            this.Q3AR1Q3.TabStop = true;
            this.Q3AR1Q3.UseVisualStyleBackColor = true;
            // 
            // Q3AR2Q3
            // 
            this.Q3AR2Q3.AutoSize = true;
            this.Q3AR2Q3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR2Q3.Location = new System.Drawing.Point(23, 44);
            this.Q3AR2Q3.Name = "Q3AR2Q3";
            this.Q3AR2Q3.Size = new System.Drawing.Size(14, 13);
            this.Q3AR2Q3.TabIndex = 1;
            this.Q3AR2Q3.TabStop = true;
            this.Q3AR2Q3.UseVisualStyleBackColor = true;
            // 
            // Q3AR3Q3
            // 
            this.Q3AR3Q3.AutoSize = true;
            this.Q3AR3Q3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR3Q3.Location = new System.Drawing.Point(23, 72);
            this.Q3AR3Q3.Name = "Q3AR3Q3";
            this.Q3AR3Q3.Size = new System.Drawing.Size(14, 13);
            this.Q3AR3Q3.TabIndex = 2;
            this.Q3AR3Q3.TabStop = true;
            this.Q3AR3Q3.UseVisualStyleBackColor = true;
            // 
            // Q3AR4Q3
            // 
            this.Q3AR4Q3.AutoSize = true;
            this.Q3AR4Q3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR4Q3.Location = new System.Drawing.Point(23, 100);
            this.Q3AR4Q3.Name = "Q3AR4Q3";
            this.Q3AR4Q3.Size = new System.Drawing.Size(14, 13);
            this.Q3AR4Q3.TabIndex = 3;
            this.Q3AR4Q3.TabStop = true;
            this.Q3AR4Q3.UseVisualStyleBackColor = true;
            // 
            // groupBox31
            // 
            this.groupBox31.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox31.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox31.Location = new System.Drawing.Point(78, 67);
            this.groupBox31.Name = "groupBox31";
            this.groupBox31.Size = new System.Drawing.Size(570, 124);
            this.groupBox31.TabIndex = 32;
            this.groupBox31.TabStop = false;
            // 
            // Q3AR1Q1
            // 
            this.Q3AR1Q1.AutoSize = true;
            this.Q3AR1Q1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR1Q1.Location = new System.Drawing.Point(23, 14);
            this.Q3AR1Q1.Name = "Q3AR1Q1";
            this.Q3AR1Q1.Size = new System.Drawing.Size(14, 13);
            this.Q3AR1Q1.TabIndex = 0;
            this.Q3AR1Q1.TabStop = true;
            this.Q3AR1Q1.UseVisualStyleBackColor = true;
            // 
            // Q3AR2Q1
            // 
            this.Q3AR2Q1.AutoSize = true;
            this.Q3AR2Q1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR2Q1.Location = new System.Drawing.Point(23, 44);
            this.Q3AR2Q1.Name = "Q3AR2Q1";
            this.Q3AR2Q1.Size = new System.Drawing.Size(14, 13);
            this.Q3AR2Q1.TabIndex = 1;
            this.Q3AR2Q1.TabStop = true;
            this.Q3AR2Q1.UseVisualStyleBackColor = true;
            // 
            // Q3AR3Q1
            // 
            this.Q3AR3Q1.AutoSize = true;
            this.Q3AR3Q1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR3Q1.Location = new System.Drawing.Point(23, 72);
            this.Q3AR3Q1.Name = "Q3AR3Q1";
            this.Q3AR3Q1.Size = new System.Drawing.Size(14, 13);
            this.Q3AR3Q1.TabIndex = 2;
            this.Q3AR3Q1.TabStop = true;
            this.Q3AR3Q1.UseVisualStyleBackColor = true;
            // 
            // Q3AR4Q1
            // 
            this.Q3AR4Q1.AutoSize = true;
            this.Q3AR4Q1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR4Q1.Location = new System.Drawing.Point(23, 100);
            this.Q3AR4Q1.Name = "Q3AR4Q1";
            this.Q3AR4Q1.Size = new System.Drawing.Size(14, 13);
            this.Q3AR4Q1.TabIndex = 3;
            this.Q3AR4Q1.TabStop = true;
            this.Q3AR4Q1.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(78, 1945);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(545, 35);
            this.panel1.TabIndex = 4;
            // 
            // btn_mcqa1_view
            // 
            this.btn_mcqa1_view.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_mcqa1_view.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.btn_mcqa1_view.Location = new System.Drawing.Point(301, 1);
            this.btn_mcqa1_view.Name = "btn_mcqa1_view";
            this.btn_mcqa1_view.Size = new System.Drawing.Size(118, 35);
            this.btn_mcqa1_view.TabIndex = 56;
            this.btn_mcqa1_view.Text = "View Answer";
            this.btn_mcqa1_view.UseVisualStyleBackColor = false;
            this.btn_mcqa1_view.Visible = false;
            // 
            // btn_Q3A_submit
            // 
            this.btn_Q3A_submit.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Q3A_submit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.btn_Q3A_submit.Location = new System.Drawing.Point(149, 1);
            this.btn_Q3A_submit.Name = "btn_Q3A_submit";
            this.btn_Q3A_submit.Size = new System.Drawing.Size(81, 35);
            this.btn_Q3A_submit.TabIndex = 57;
            this.btn_Q3A_submit.Text = "Submit";
            this.btn_Q3A_submit.UseVisualStyleBackColor = false;
            // 
            // que23
            // 
            this.que23.BackColor = System.Drawing.Color.Gainsboro;
            this.que23.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que23.Location = new System.Drawing.Point(78, 393);
            this.que23.Multiline = true;
            this.que23.Name = "que23";
            this.que23.ReadOnly = true;
            this.que23.Size = new System.Drawing.Size(570, 54);
            this.que23.TabIndex = 35;
            // 
            // que21
            // 
            this.que21.BackColor = System.Drawing.Color.Gainsboro;
            this.que21.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que21.Location = new System.Drawing.Point(78, 5);
            this.que21.Multiline = true;
            this.que21.Name = "que21";
            this.que21.ReadOnly = true;
            this.que21.Size = new System.Drawing.Size(570, 50);
            this.que21.TabIndex = 31;
            // 
            // q23
            // 
            this.q23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q23.AutoSize = true;
            this.q23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q23.Location = new System.Drawing.Point(26, 413);
            this.q23.Name = "q23";
            this.q23.Size = new System.Drawing.Size(23, 13);
            this.q23.TabIndex = 48;
            // 
            // q22
            // 
            this.q22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q22.AutoSize = true;
            this.q22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q22.Location = new System.Drawing.Point(26, 219);
            this.q22.Name = "q22";
            this.q22.Size = new System.Drawing.Size(23, 13);
            this.q22.TabIndex = 47;
            // 
            // que27
            // 
            this.que27.BackColor = System.Drawing.Color.Gainsboro;
            this.que27.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que27.Location = new System.Drawing.Point(78, 1169);
            this.que27.Multiline = true;
            this.que27.Name = "que27";
            this.que27.ReadOnly = true;
            this.que27.Size = new System.Drawing.Size(570, 54);
            this.que27.TabIndex = 42;
            // 
            // que26
            // 
            this.que26.BackColor = System.Drawing.Color.Gainsboro;
            this.que26.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que26.Location = new System.Drawing.Point(78, 975);
            this.que26.Multiline = true;
            this.que26.Name = "que26";
            this.que26.ReadOnly = true;
            this.que26.Size = new System.Drawing.Size(570, 54);
            this.que26.TabIndex = 41;
            // 
            // que25
            // 
            this.que25.BackColor = System.Drawing.Color.Gainsboro;
            this.que25.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que25.Location = new System.Drawing.Point(78, 781);
            this.que25.Multiline = true;
            this.que25.Name = "que25";
            this.que25.ReadOnly = true;
            this.que25.Size = new System.Drawing.Size(570, 54);
            this.que25.TabIndex = 43;
            // 
            // que24
            // 
            this.que24.BackColor = System.Drawing.Color.Gainsboro;
            this.que24.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que24.Location = new System.Drawing.Point(78, 587);
            this.que24.Multiline = true;
            this.que24.Name = "que24";
            this.que24.ReadOnly = true;
            this.que24.Size = new System.Drawing.Size(570, 54);
            this.que24.TabIndex = 38;
            // 
            // que22
            // 
            this.que22.BackColor = System.Drawing.Color.Gainsboro;
            this.que22.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que22.Location = new System.Drawing.Point(78, 199);
            this.que22.Multiline = true;
            this.que22.Name = "que22";
            this.que22.ReadOnly = true;
            this.que22.Size = new System.Drawing.Size(570, 51);
            this.que22.TabIndex = 34;
            // 
            // q21
            // 
            this.q21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q21.AutoSize = true;
            this.q21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q21.Location = new System.Drawing.Point(26, 25);
            this.q21.Name = "q21";
            this.q21.Size = new System.Drawing.Size(23, 13);
            this.q21.TabIndex = 33;
            // 
            // q24
            // 
            this.q24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q24.AutoSize = true;
            this.q24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q24.Location = new System.Drawing.Point(26, 607);
            this.q24.Name = "q24";
            this.q24.Size = new System.Drawing.Size(23, 13);
            this.q24.TabIndex = 34;
            // 
            // label36
            // 
            this.label36.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(26, 801);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(23, 13);
            this.label36.TabIndex = 34;
            // 
            // label35
            // 
            this.label35.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(26, 995);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(23, 13);
            this.label35.TabIndex = 34;
            // 
            // label34
            // 
            this.label34.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(26, 1189);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(23, 13);
            this.label34.TabIndex = 49;
            // 
            // que28
            // 
            this.que28.BackColor = System.Drawing.Color.Gainsboro;
            this.que28.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que28.Location = new System.Drawing.Point(78, 1363);
            this.que28.Multiline = true;
            this.que28.Name = "que28";
            this.que28.ReadOnly = true;
            this.que28.Size = new System.Drawing.Size(570, 54);
            this.que28.TabIndex = 50;
            // 
            // que29
            // 
            this.que29.BackColor = System.Drawing.Color.Gainsboro;
            this.que29.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que29.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.que29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que29.Location = new System.Drawing.Point(78, 1557);
            this.que29.Multiline = true;
            this.que29.Name = "que29";
            this.que29.ReadOnly = true;
            this.que29.Size = new System.Drawing.Size(570, 54);
            this.que29.TabIndex = 51;
            // 
            // que30
            // 
            this.que30.BackColor = System.Drawing.Color.Gainsboro;
            this.que30.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que30.Location = new System.Drawing.Point(78, 1751);
            this.que30.Multiline = true;
            this.que30.Name = "que30";
            this.que30.ReadOnly = true;
            this.que30.Size = new System.Drawing.Size(570, 54);
            this.que30.TabIndex = 52;
            // 
            // label33
            // 
            this.label33.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(26, 1383);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(23, 13);
            this.label33.TabIndex = 50;
            // 
            // label32
            // 
            this.label32.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(26, 1577);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(23, 13);
            this.label32.TabIndex = 50;
            // 
            // label31
            // 
            this.label31.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(22, 1771);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(30, 13);
            this.label31.TabIndex = 53;
            // 
            // groupBox23
            // 
            this.groupBox23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox23.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox23.Location = new System.Drawing.Point(78, 261);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(570, 124);
            this.groupBox23.TabIndex = 33;
            this.groupBox23.TabStop = false;
            // 
            // Q3AR1Q2
            // 
            this.Q3AR1Q2.AutoSize = true;
            this.Q3AR1Q2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR1Q2.Location = new System.Drawing.Point(23, 14);
            this.Q3AR1Q2.Name = "Q3AR1Q2";
            this.Q3AR1Q2.Size = new System.Drawing.Size(14, 13);
            this.Q3AR1Q2.TabIndex = 0;
            this.Q3AR1Q2.TabStop = true;
            this.Q3AR1Q2.UseVisualStyleBackColor = true;
            // 
            // Q3AR2Q2
            // 
            this.Q3AR2Q2.AutoSize = true;
            this.Q3AR2Q2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR2Q2.Location = new System.Drawing.Point(23, 44);
            this.Q3AR2Q2.Name = "Q3AR2Q2";
            this.Q3AR2Q2.Size = new System.Drawing.Size(14, 13);
            this.Q3AR2Q2.TabIndex = 1;
            this.Q3AR2Q2.TabStop = true;
            this.Q3AR2Q2.UseVisualStyleBackColor = true;
            // 
            // Q3AR3Q2
            // 
            this.Q3AR3Q2.AutoSize = true;
            this.Q3AR3Q2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR3Q2.Location = new System.Drawing.Point(23, 72);
            this.Q3AR3Q2.Name = "Q3AR3Q2";
            this.Q3AR3Q2.Size = new System.Drawing.Size(14, 13);
            this.Q3AR3Q2.TabIndex = 2;
            this.Q3AR3Q2.TabStop = true;
            this.Q3AR3Q2.UseVisualStyleBackColor = true;
            // 
            // Q3AR4Q2
            // 
            this.Q3AR4Q2.AutoSize = true;
            this.Q3AR4Q2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR4Q2.Location = new System.Drawing.Point(23, 100);
            this.Q3AR4Q2.Name = "Q3AR4Q2";
            this.Q3AR4Q2.Size = new System.Drawing.Size(14, 13);
            this.Q3AR4Q2.TabIndex = 3;
            this.Q3AR4Q2.TabStop = true;
            this.Q3AR4Q2.UseVisualStyleBackColor = true;
            // 
            // groupBox26
            // 
            this.groupBox26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox26.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox26.Location = new System.Drawing.Point(78, 843);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Size = new System.Drawing.Size(570, 124);
            this.groupBox26.TabIndex = 36;
            this.groupBox26.TabStop = false;
            // 
            // Q3AR1Q5
            // 
            this.Q3AR1Q5.AutoSize = true;
            this.Q3AR1Q5.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR1Q5.Location = new System.Drawing.Point(23, 14);
            this.Q3AR1Q5.Name = "Q3AR1Q5";
            this.Q3AR1Q5.Size = new System.Drawing.Size(14, 13);
            this.Q3AR1Q5.TabIndex = 0;
            this.Q3AR1Q5.TabStop = true;
            this.Q3AR1Q5.UseVisualStyleBackColor = true;
            // 
            // Q3AR2Q5
            // 
            this.Q3AR2Q5.AutoSize = true;
            this.Q3AR2Q5.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR2Q5.Location = new System.Drawing.Point(23, 44);
            this.Q3AR2Q5.Name = "Q3AR2Q5";
            this.Q3AR2Q5.Size = new System.Drawing.Size(14, 13);
            this.Q3AR2Q5.TabIndex = 1;
            this.Q3AR2Q5.TabStop = true;
            this.Q3AR2Q5.UseVisualStyleBackColor = true;
            // 
            // Q3AR3Q5
            // 
            this.Q3AR3Q5.AutoSize = true;
            this.Q3AR3Q5.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR3Q5.Location = new System.Drawing.Point(23, 72);
            this.Q3AR3Q5.Name = "Q3AR3Q5";
            this.Q3AR3Q5.Size = new System.Drawing.Size(14, 13);
            this.Q3AR3Q5.TabIndex = 2;
            this.Q3AR3Q5.TabStop = true;
            this.Q3AR3Q5.UseVisualStyleBackColor = true;
            // 
            // Q3AR4Q5
            // 
            this.Q3AR4Q5.AutoSize = true;
            this.Q3AR4Q5.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR4Q5.Location = new System.Drawing.Point(23, 100);
            this.Q3AR4Q5.Name = "Q3AR4Q5";
            this.Q3AR4Q5.Size = new System.Drawing.Size(14, 13);
            this.Q3AR4Q5.TabIndex = 3;
            this.Q3AR4Q5.TabStop = true;
            this.Q3AR4Q5.UseVisualStyleBackColor = true;
            // 
            // groupBox27
            // 
            this.groupBox27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox27.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox27.Location = new System.Drawing.Point(78, 1037);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Size = new System.Drawing.Size(570, 124);
            this.groupBox27.TabIndex = 37;
            this.groupBox27.TabStop = false;
            // 
            // Q3AR1Q6
            // 
            this.Q3AR1Q6.AutoSize = true;
            this.Q3AR1Q6.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR1Q6.Location = new System.Drawing.Point(23, 14);
            this.Q3AR1Q6.Name = "Q3AR1Q6";
            this.Q3AR1Q6.Size = new System.Drawing.Size(14, 13);
            this.Q3AR1Q6.TabIndex = 0;
            this.Q3AR1Q6.TabStop = true;
            this.Q3AR1Q6.UseVisualStyleBackColor = true;
            // 
            // Q3AR2Q6
            // 
            this.Q3AR2Q6.AutoSize = true;
            this.Q3AR2Q6.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR2Q6.Location = new System.Drawing.Point(23, 44);
            this.Q3AR2Q6.Name = "Q3AR2Q6";
            this.Q3AR2Q6.Size = new System.Drawing.Size(14, 13);
            this.Q3AR2Q6.TabIndex = 1;
            this.Q3AR2Q6.TabStop = true;
            this.Q3AR2Q6.UseVisualStyleBackColor = true;
            // 
            // Q3AR3Q6
            // 
            this.Q3AR3Q6.AutoSize = true;
            this.Q3AR3Q6.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR3Q6.Location = new System.Drawing.Point(23, 72);
            this.Q3AR3Q6.Name = "Q3AR3Q6";
            this.Q3AR3Q6.Size = new System.Drawing.Size(14, 13);
            this.Q3AR3Q6.TabIndex = 2;
            this.Q3AR3Q6.TabStop = true;
            this.Q3AR3Q6.UseVisualStyleBackColor = true;
            // 
            // Q3AR4Q6
            // 
            this.Q3AR4Q6.AutoSize = true;
            this.Q3AR4Q6.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR4Q6.Location = new System.Drawing.Point(23, 100);
            this.Q3AR4Q6.Name = "Q3AR4Q6";
            this.Q3AR4Q6.Size = new System.Drawing.Size(14, 13);
            this.Q3AR4Q6.TabIndex = 3;
            this.Q3AR4Q6.TabStop = true;
            this.Q3AR4Q6.UseVisualStyleBackColor = true;
            // 
            // groupBox28
            // 
            this.groupBox28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox28.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox28.Location = new System.Drawing.Point(78, 1231);
            this.groupBox28.Name = "groupBox28";
            this.groupBox28.Size = new System.Drawing.Size(570, 124);
            this.groupBox28.TabIndex = 38;
            this.groupBox28.TabStop = false;
            // 
            // Q3AR1Q7
            // 
            this.Q3AR1Q7.AutoSize = true;
            this.Q3AR1Q7.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR1Q7.Location = new System.Drawing.Point(23, 14);
            this.Q3AR1Q7.Name = "Q3AR1Q7";
            this.Q3AR1Q7.Size = new System.Drawing.Size(14, 13);
            this.Q3AR1Q7.TabIndex = 0;
            this.Q3AR1Q7.TabStop = true;
            this.Q3AR1Q7.UseVisualStyleBackColor = true;
            // 
            // Q3AR2Q7
            // 
            this.Q3AR2Q7.AutoSize = true;
            this.Q3AR2Q7.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR2Q7.Location = new System.Drawing.Point(23, 44);
            this.Q3AR2Q7.Name = "Q3AR2Q7";
            this.Q3AR2Q7.Size = new System.Drawing.Size(14, 13);
            this.Q3AR2Q7.TabIndex = 1;
            this.Q3AR2Q7.TabStop = true;
            this.Q3AR2Q7.UseVisualStyleBackColor = true;
            // 
            // Q3AR3Q7
            // 
            this.Q3AR3Q7.AutoSize = true;
            this.Q3AR3Q7.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR3Q7.Location = new System.Drawing.Point(23, 72);
            this.Q3AR3Q7.Name = "Q3AR3Q7";
            this.Q3AR3Q7.Size = new System.Drawing.Size(14, 13);
            this.Q3AR3Q7.TabIndex = 2;
            this.Q3AR3Q7.TabStop = true;
            this.Q3AR3Q7.UseVisualStyleBackColor = true;
            // 
            // Q3AR4Q7
            // 
            this.Q3AR4Q7.AutoSize = true;
            this.Q3AR4Q7.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR4Q7.Location = new System.Drawing.Point(23, 100);
            this.Q3AR4Q7.Name = "Q3AR4Q7";
            this.Q3AR4Q7.Size = new System.Drawing.Size(14, 13);
            this.Q3AR4Q7.TabIndex = 3;
            this.Q3AR4Q7.TabStop = true;
            this.Q3AR4Q7.UseVisualStyleBackColor = true;
            // 
            // groupBox29
            // 
            this.groupBox29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox29.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox29.Location = new System.Drawing.Point(78, 1425);
            this.groupBox29.Name = "groupBox29";
            this.groupBox29.Size = new System.Drawing.Size(570, 124);
            this.groupBox29.TabIndex = 39;
            this.groupBox29.TabStop = false;
            // 
            // Q3AR1Q8
            // 
            this.Q3AR1Q8.AutoSize = true;
            this.Q3AR1Q8.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR1Q8.Location = new System.Drawing.Point(23, 14);
            this.Q3AR1Q8.Name = "Q3AR1Q8";
            this.Q3AR1Q8.Size = new System.Drawing.Size(14, 13);
            this.Q3AR1Q8.TabIndex = 0;
            this.Q3AR1Q8.TabStop = true;
            this.Q3AR1Q8.UseVisualStyleBackColor = true;
            // 
            // Q3AR2Q8
            // 
            this.Q3AR2Q8.AutoSize = true;
            this.Q3AR2Q8.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR2Q8.Location = new System.Drawing.Point(23, 44);
            this.Q3AR2Q8.Name = "Q3AR2Q8";
            this.Q3AR2Q8.Size = new System.Drawing.Size(14, 13);
            this.Q3AR2Q8.TabIndex = 1;
            this.Q3AR2Q8.TabStop = true;
            this.Q3AR2Q8.UseVisualStyleBackColor = true;
            // 
            // Q3AR3Q8
            // 
            this.Q3AR3Q8.AutoSize = true;
            this.Q3AR3Q8.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR3Q8.Location = new System.Drawing.Point(23, 72);
            this.Q3AR3Q8.Name = "Q3AR3Q8";
            this.Q3AR3Q8.Size = new System.Drawing.Size(14, 13);
            this.Q3AR3Q8.TabIndex = 2;
            this.Q3AR3Q8.TabStop = true;
            this.Q3AR3Q8.UseVisualStyleBackColor = true;
            // 
            // Q3AR4Q8
            // 
            this.Q3AR4Q8.AutoSize = true;
            this.Q3AR4Q8.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR4Q8.Location = new System.Drawing.Point(23, 100);
            this.Q3AR4Q8.Name = "Q3AR4Q8";
            this.Q3AR4Q8.Size = new System.Drawing.Size(14, 13);
            this.Q3AR4Q8.TabIndex = 3;
            this.Q3AR4Q8.TabStop = true;
            this.Q3AR4Q8.UseVisualStyleBackColor = true;
            // 
            // groupBox30
            // 
            this.groupBox30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox30.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox30.Location = new System.Drawing.Point(78, 1619);
            this.groupBox30.Name = "groupBox30";
            this.groupBox30.Size = new System.Drawing.Size(570, 124);
            this.groupBox30.TabIndex = 40;
            this.groupBox30.TabStop = false;
            // 
            // Q3AR1Q9
            // 
            this.Q3AR1Q9.AutoSize = true;
            this.Q3AR1Q9.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR1Q9.Location = new System.Drawing.Point(23, 14);
            this.Q3AR1Q9.Name = "Q3AR1Q9";
            this.Q3AR1Q9.Size = new System.Drawing.Size(14, 13);
            this.Q3AR1Q9.TabIndex = 0;
            this.Q3AR1Q9.TabStop = true;
            this.Q3AR1Q9.UseVisualStyleBackColor = true;
            // 
            // Q3AR2Q9
            // 
            this.Q3AR2Q9.AutoSize = true;
            this.Q3AR2Q9.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR2Q9.Location = new System.Drawing.Point(23, 44);
            this.Q3AR2Q9.Name = "Q3AR2Q9";
            this.Q3AR2Q9.Size = new System.Drawing.Size(14, 13);
            this.Q3AR2Q9.TabIndex = 1;
            this.Q3AR2Q9.TabStop = true;
            this.Q3AR2Q9.UseVisualStyleBackColor = true;
            // 
            // Q3AR3Q9
            // 
            this.Q3AR3Q9.AutoSize = true;
            this.Q3AR3Q9.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR3Q9.Location = new System.Drawing.Point(23, 72);
            this.Q3AR3Q9.Name = "Q3AR3Q9";
            this.Q3AR3Q9.Size = new System.Drawing.Size(14, 13);
            this.Q3AR3Q9.TabIndex = 2;
            this.Q3AR3Q9.TabStop = true;
            this.Q3AR3Q9.UseVisualStyleBackColor = true;
            // 
            // Q3AR4Q9
            // 
            this.Q3AR4Q9.AutoSize = true;
            this.Q3AR4Q9.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR4Q9.Location = new System.Drawing.Point(23, 100);
            this.Q3AR4Q9.Name = "Q3AR4Q9";
            this.Q3AR4Q9.Size = new System.Drawing.Size(14, 13);
            this.Q3AR4Q9.TabIndex = 3;
            this.Q3AR4Q9.TabStop = true;
            this.Q3AR4Q9.UseVisualStyleBackColor = true;
            // 
            // groupBox32
            // 
            this.groupBox32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox32.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox32.Location = new System.Drawing.Point(78, 1813);
            this.groupBox32.Name = "groupBox32";
            this.groupBox32.Size = new System.Drawing.Size(570, 124);
            this.groupBox32.TabIndex = 41;
            this.groupBox32.TabStop = false;
            // 
            // Q3AR1Q10
            // 
            this.Q3AR1Q10.AutoSize = true;
            this.Q3AR1Q10.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR1Q10.Location = new System.Drawing.Point(23, 14);
            this.Q3AR1Q10.Name = "Q3AR1Q10";
            this.Q3AR1Q10.Size = new System.Drawing.Size(14, 13);
            this.Q3AR1Q10.TabIndex = 0;
            this.Q3AR1Q10.TabStop = true;
            this.Q3AR1Q10.UseVisualStyleBackColor = true;
            // 
            // Q3AR2Q10
            // 
            this.Q3AR2Q10.AutoSize = true;
            this.Q3AR2Q10.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR2Q10.Location = new System.Drawing.Point(23, 44);
            this.Q3AR2Q10.Name = "Q3AR2Q10";
            this.Q3AR2Q10.Size = new System.Drawing.Size(14, 13);
            this.Q3AR2Q10.TabIndex = 1;
            this.Q3AR2Q10.TabStop = true;
            this.Q3AR2Q10.UseVisualStyleBackColor = true;
            // 
            // Q3AR3Q10
            // 
            this.Q3AR3Q10.AutoSize = true;
            this.Q3AR3Q10.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR3Q10.Location = new System.Drawing.Point(23, 72);
            this.Q3AR3Q10.Name = "Q3AR3Q10";
            this.Q3AR3Q10.Size = new System.Drawing.Size(14, 13);
            this.Q3AR3Q10.TabIndex = 2;
            this.Q3AR3Q10.TabStop = true;
            this.Q3AR3Q10.UseVisualStyleBackColor = true;
            // 
            // Q3AR4Q10
            // 
            this.Q3AR4Q10.AutoSize = true;
            this.Q3AR4Q10.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Q3AR4Q10.Location = new System.Drawing.Point(23, 100);
            this.Q3AR4Q10.Name = "Q3AR4Q10";
            this.Q3AR4Q10.Size = new System.Drawing.Size(14, 13);
            this.Q3AR4Q10.TabIndex = 3;
            this.Q3AR4Q10.TabStop = true;
            this.Q3AR4Q10.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel_fib
            // 
            this.tableLayoutPanel_fib.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel_fib.ColumnCount = 3;
            this.tableLayoutPanel_fib.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel_fib.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel_fib.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel_fib.Location = new System.Drawing.Point(3, 6);
            this.tableLayoutPanel_fib.Name = "tableLayoutPanel_fib";
            this.tableLayoutPanel_fib.RowCount = 21;
            this.tableLayoutPanel_fib.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel_fib.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel_fib.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel_fib.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel_fib.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel_fib.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel_fib.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel_fib.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel_fib.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel_fib.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel_fib.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel_fib.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel_fib.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel_fib.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel_fib.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel_fib.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel_fib.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel_fib.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel_fib.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel_fib.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel_fib.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 48F));
            this.tableLayoutPanel_fib.Size = new System.Drawing.Size(729, 1127);
            this.tableLayoutPanel_fib.TabIndex = 29;
            // 
            // panel18
            // 
            this.panel18.Location = new System.Drawing.Point(79, 988);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(305, 44);
            this.panel18.TabIndex = 69;
            // 
            // btn_view
            // 
            this.btn_view.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_view.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_view.Location = new System.Drawing.Point(194, 2);
            this.btn_view.Name = "btn_view";
            this.btn_view.Size = new System.Drawing.Size(118, 39);
            this.btn_view.TabIndex = 68;
            this.btn_view.Text = "View Answer";
            this.btn_view.UseVisualStyleBackColor = false;
            this.btn_view.Visible = false;
            // 
            // btn_Q1_submit
            // 
            this.btn_Q1_submit.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Q1_submit.CausesValidation = false;
            this.btn_Q1_submit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Q1_submit.Location = new System.Drawing.Point(47, 2);
            this.btn_Q1_submit.Name = "btn_Q1_submit";
            this.btn_Q1_submit.Size = new System.Drawing.Size(118, 39);
            this.btn_Q1_submit.TabIndex = 69;
            this.btn_Q1_submit.Text = "Submit";
            this.btn_Q1_submit.UseVisualStyleBackColor = false;
            // 
            // txtans10
            // 
            this.txtans10.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtans10.Location = new System.Drawing.Point(513, 896);
            this.txtans10.Name = "txtans10";
            this.txtans10.Size = new System.Drawing.Size(201, 20);
            this.txtans10.TabIndex = 55;
            // 
            // txtans9
            // 
            this.txtans9.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtans9.Location = new System.Drawing.Point(513, 797);
            this.txtans9.Name = "txtans9";
            this.txtans9.Size = new System.Drawing.Size(201, 20);
            this.txtans9.TabIndex = 54;
            // 
            // txtans8
            // 
            this.txtans8.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtans8.Location = new System.Drawing.Point(513, 698);
            this.txtans8.Name = "txtans8";
            this.txtans8.Size = new System.Drawing.Size(201, 20);
            this.txtans8.TabIndex = 53;
            // 
            // txtans7
            // 
            this.txtans7.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtans7.Location = new System.Drawing.Point(513, 599);
            this.txtans7.Name = "txtans7";
            this.txtans7.Size = new System.Drawing.Size(201, 20);
            this.txtans7.TabIndex = 51;
            // 
            // txtans6
            // 
            this.txtans6.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtans6.Location = new System.Drawing.Point(513, 500);
            this.txtans6.Name = "txtans6";
            this.txtans6.Size = new System.Drawing.Size(201, 20);
            this.txtans6.TabIndex = 52;
            // 
            // txtans5
            // 
            this.txtans5.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtans5.Location = new System.Drawing.Point(513, 401);
            this.txtans5.Name = "txtans5";
            this.txtans5.Size = new System.Drawing.Size(201, 20);
            this.txtans5.TabIndex = 50;
            // 
            // txtans4
            // 
            this.txtans4.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtans4.Location = new System.Drawing.Point(513, 302);
            this.txtans4.Name = "txtans4";
            this.txtans4.Size = new System.Drawing.Size(201, 20);
            this.txtans4.TabIndex = 49;
            // 
            // txtans3
            // 
            this.txtans3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtans3.Location = new System.Drawing.Point(513, 203);
            this.txtans3.Name = "txtans3";
            this.txtans3.Size = new System.Drawing.Size(201, 20);
            this.txtans3.TabIndex = 48;
            // 
            // txtans2
            // 
            this.txtans2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtans2.Location = new System.Drawing.Point(513, 104);
            this.txtans2.Name = "txtans2";
            this.txtans2.Size = new System.Drawing.Size(201, 20);
            this.txtans2.TabIndex = 47;
            // 
            // que10
            // 
            this.que10.BackColor = System.Drawing.Color.Gainsboro;
            this.que10.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que10.Location = new System.Drawing.Point(79, 896);
            this.que10.Multiline = true;
            this.que10.Name = "que10";
            this.que10.ReadOnly = true;
            this.que10.Size = new System.Drawing.Size(410, 80);
            this.que10.TabIndex = 41;
            // 
            // q9
            // 
            this.q9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q9.AutoSize = true;
            this.q9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q9.Location = new System.Drawing.Point(26, 832);
            this.q9.Name = "q9";
            this.q9.Size = new System.Drawing.Size(23, 13);
            this.q9.TabIndex = 45;
            // 
            // q8
            // 
            this.q8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q8.AutoSize = true;
            this.q8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q8.Location = new System.Drawing.Point(26, 733);
            this.q8.Name = "q8";
            this.q8.Size = new System.Drawing.Size(23, 13);
            this.q8.TabIndex = 44;
            // 
            // q7
            // 
            this.q7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q7.AutoSize = true;
            this.q7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q7.Location = new System.Drawing.Point(26, 634);
            this.q7.Name = "q7";
            this.q7.Size = new System.Drawing.Size(23, 13);
            this.q7.TabIndex = 43;
            // 
            // q6
            // 
            this.q6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q6.AutoSize = true;
            this.q6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q6.Location = new System.Drawing.Point(26, 535);
            this.q6.Name = "q6";
            this.q6.Size = new System.Drawing.Size(23, 13);
            this.q6.TabIndex = 42;
            // 
            // que3
            // 
            this.que3.BackColor = System.Drawing.Color.Gainsboro;
            this.que3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que3.Location = new System.Drawing.Point(79, 203);
            this.que3.Multiline = true;
            this.que3.Name = "que3";
            this.que3.ReadOnly = true;
            this.que3.Size = new System.Drawing.Size(410, 80);
            this.que3.TabIndex = 34;
            // 
            // que9
            // 
            this.que9.BackColor = System.Drawing.Color.Gainsboro;
            this.que9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que9.Location = new System.Drawing.Point(79, 797);
            this.que9.Multiline = true;
            this.que9.Name = "que9";
            this.que9.ReadOnly = true;
            this.que9.Size = new System.Drawing.Size(410, 80);
            this.que9.TabIndex = 40;
            // 
            // que8
            // 
            this.que8.BackColor = System.Drawing.Color.Gainsboro;
            this.que8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que8.Location = new System.Drawing.Point(79, 698);
            this.que8.Multiline = true;
            this.que8.Name = "que8";
            this.que8.ReadOnly = true;
            this.que8.Size = new System.Drawing.Size(410, 80);
            this.que8.TabIndex = 39;
            // 
            // que7
            // 
            this.que7.BackColor = System.Drawing.Color.Gainsboro;
            this.que7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que7.Location = new System.Drawing.Point(79, 599);
            this.que7.Multiline = true;
            this.que7.Name = "que7";
            this.que7.ReadOnly = true;
            this.que7.Size = new System.Drawing.Size(410, 80);
            this.que7.TabIndex = 38;
            // 
            // que5
            // 
            this.que5.BackColor = System.Drawing.Color.Gainsboro;
            this.que5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que5.Location = new System.Drawing.Point(79, 401);
            this.que5.Multiline = true;
            this.que5.Name = "que5";
            this.que5.ReadOnly = true;
            this.que5.Size = new System.Drawing.Size(410, 80);
            this.que5.TabIndex = 36;
            // 
            // que4
            // 
            this.que4.BackColor = System.Drawing.Color.Gainsboro;
            this.que4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que4.Location = new System.Drawing.Point(79, 302);
            this.que4.Multiline = true;
            this.que4.Name = "que4";
            this.que4.ReadOnly = true;
            this.que4.Size = new System.Drawing.Size(410, 80);
            this.que4.TabIndex = 35;
            // 
            // que2
            // 
            this.que2.BackColor = System.Drawing.Color.Gainsboro;
            this.que2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que2.Location = new System.Drawing.Point(79, 104);
            this.que2.Multiline = true;
            this.que2.Name = "que2";
            this.que2.ReadOnly = true;
            this.que2.Size = new System.Drawing.Size(410, 80);
            this.que2.TabIndex = 33;
            // 
            // txtans1
            // 
            this.txtans1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtans1.Location = new System.Drawing.Point(513, 5);
            this.txtans1.Name = "txtans1";
            this.txtans1.Size = new System.Drawing.Size(201, 20);
            this.txtans1.TabIndex = 20;
            // 
            // q5
            // 
            this.q5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q5.AutoSize = true;
            this.q5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q5.Location = new System.Drawing.Point(26, 436);
            this.q5.Name = "q5";
            this.q5.Size = new System.Drawing.Size(23, 13);
            this.q5.TabIndex = 13;
            // 
            // q4
            // 
            this.q4.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.q4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q4.AutoSize = true;
            this.q4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q4.Location = new System.Drawing.Point(26, 337);
            this.q4.Name = "q4";
            this.q4.Size = new System.Drawing.Size(23, 13);
            this.q4.TabIndex = 11;
            this.q4.UseWaitCursor = true;
            // 
            // q3
            // 
            this.q3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q3.AutoSize = true;
            this.q3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q3.Location = new System.Drawing.Point(26, 238);
            this.q3.Name = "q3";
            this.q3.Size = new System.Drawing.Size(23, 13);
            this.q3.TabIndex = 9;
            // 
            // q2
            // 
            this.q2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q2.AutoSize = true;
            this.q2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q2.Location = new System.Drawing.Point(26, 139);
            this.q2.Name = "q2";
            this.q2.Size = new System.Drawing.Size(23, 13);
            this.q2.TabIndex = 7;
            // 
            // q1
            // 
            this.q1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q1.AutoSize = true;
            this.q1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q1.Location = new System.Drawing.Point(26, 40);
            this.q1.Name = "q1";
            this.q1.Size = new System.Drawing.Size(23, 13);
            this.q1.TabIndex = 5;
            // 
            // que6
            // 
            this.que6.BackColor = System.Drawing.Color.Gainsboro;
            this.que6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que6.Location = new System.Drawing.Point(79, 500);
            this.que6.Multiline = true;
            this.que6.Name = "que6";
            this.que6.ReadOnly = true;
            this.que6.Size = new System.Drawing.Size(410, 80);
            this.que6.TabIndex = 37;
            // 
            // que1
            // 
            this.que1.BackColor = System.Drawing.Color.Gainsboro;
            this.que1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que1.Location = new System.Drawing.Point(79, 5);
            this.que1.Multiline = true;
            this.que1.Name = "que1";
            this.que1.ReadOnly = true;
            this.que1.Size = new System.Drawing.Size(410, 80);
            this.que1.TabIndex = 32;
            // 
            // q10
            // 
            this.q10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q10.AutoSize = true;
            this.q10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q10.Location = new System.Drawing.Point(23, 931);
            this.q10.Name = "q10";
            this.q10.Size = new System.Drawing.Size(30, 13);
            this.q10.TabIndex = 46;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(5, 985);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(21, 13);
            this.label3.TabIndex = 61;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 20;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(724, 1085);
            this.tableLayoutPanel1.TabIndex = 9;
            // 
            // que15
            // 
            this.que15.BackColor = System.Drawing.Color.Gainsboro;
            this.que15.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que15.Location = new System.Drawing.Point(78, 401);
            this.que15.Multiline = true;
            this.que15.Name = "que15";
            this.que15.ReadOnly = true;
            this.que15.Size = new System.Drawing.Size(480, 80);
            this.que15.TabIndex = 47;
            // 
            // q17
            // 
            this.q17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q17.AutoSize = true;
            this.q17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q17.Location = new System.Drawing.Point(26, 634);
            this.q17.Name = "q17";
            this.q17.Size = new System.Drawing.Size(23, 13);
            this.q17.TabIndex = 63;
            // 
            // q16
            // 
            this.q16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q16.AutoSize = true;
            this.q16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q16.Location = new System.Drawing.Point(26, 535);
            this.q16.Name = "q16";
            this.q16.Size = new System.Drawing.Size(23, 13);
            this.q16.TabIndex = 62;
            // 
            // q15
            // 
            this.q15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q15.AutoSize = true;
            this.q15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q15.Location = new System.Drawing.Point(26, 436);
            this.q15.Name = "q15";
            this.q15.Size = new System.Drawing.Size(23, 13);
            this.q15.TabIndex = 60;
            // 
            // q14
            // 
            this.q14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q14.AutoSize = true;
            this.q14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q14.Location = new System.Drawing.Point(26, 337);
            this.q14.Name = "q14";
            this.q14.Size = new System.Drawing.Size(23, 13);
            this.q14.TabIndex = 59;
            // 
            // groupBox22
            // 
            this.groupBox22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox22.Location = new System.Drawing.Point(581, 896);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(127, 67);
            this.groupBox22.TabIndex = 58;
            this.groupBox22.TabStop = false;
            // 
            // rb_tf19
            // 
            this.rb_tf19.AutoSize = true;
            this.rb_tf19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_tf19.Location = new System.Drawing.Point(6, 9);
            this.rb_tf19.Name = "rb_tf19";
            this.rb_tf19.Size = new System.Drawing.Size(56, 22);
            this.rb_tf19.TabIndex = 0;
            this.rb_tf19.TabStop = true;
            this.rb_tf19.Text = "True";
            this.rb_tf19.UseVisualStyleBackColor = true;
            // 
            // rb_tf20
            // 
            this.rb_tf20.AutoSize = true;
            this.rb_tf20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_tf20.Location = new System.Drawing.Point(6, 40);
            this.rb_tf20.Name = "rb_tf20";
            this.rb_tf20.Size = new System.Drawing.Size(62, 22);
            this.rb_tf20.TabIndex = 1;
            this.rb_tf20.TabStop = true;
            this.rb_tf20.Text = "False";
            this.rb_tf20.UseVisualStyleBackColor = true;
            // 
            // que20
            // 
            this.que20.BackColor = System.Drawing.Color.Gainsboro;
            this.que20.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que20.Location = new System.Drawing.Point(78, 896);
            this.que20.Multiline = true;
            this.que20.Name = "que20";
            this.que20.ReadOnly = true;
            this.que20.Size = new System.Drawing.Size(480, 80);
            this.que20.TabIndex = 57;
            // 
            // groupBox21
            // 
            this.groupBox21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox21.Location = new System.Drawing.Point(581, 797);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(127, 66);
            this.groupBox21.TabIndex = 56;
            this.groupBox21.TabStop = false;
            // 
            // rb_tf17
            // 
            this.rb_tf17.AutoSize = true;
            this.rb_tf17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_tf17.Location = new System.Drawing.Point(6, 9);
            this.rb_tf17.Name = "rb_tf17";
            this.rb_tf17.Size = new System.Drawing.Size(56, 22);
            this.rb_tf17.TabIndex = 0;
            this.rb_tf17.TabStop = true;
            this.rb_tf17.Text = "True";
            this.rb_tf17.UseVisualStyleBackColor = true;
            // 
            // rb_tf18
            // 
            this.rb_tf18.AutoSize = true;
            this.rb_tf18.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_tf18.Location = new System.Drawing.Point(6, 40);
            this.rb_tf18.Name = "rb_tf18";
            this.rb_tf18.Size = new System.Drawing.Size(62, 22);
            this.rb_tf18.TabIndex = 1;
            this.rb_tf18.TabStop = true;
            this.rb_tf18.Text = "False";
            this.rb_tf18.UseVisualStyleBackColor = true;
            // 
            // que19
            // 
            this.que19.BackColor = System.Drawing.Color.Gainsboro;
            this.que19.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que19.Location = new System.Drawing.Point(78, 797);
            this.que19.Multiline = true;
            this.que19.Name = "que19";
            this.que19.ReadOnly = true;
            this.que19.Size = new System.Drawing.Size(480, 80);
            this.que19.TabIndex = 55;
            // 
            // que18
            // 
            this.que18.BackColor = System.Drawing.Color.Gainsboro;
            this.que18.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que18.Location = new System.Drawing.Point(78, 698);
            this.que18.Multiline = true;
            this.que18.Name = "que18";
            this.que18.ReadOnly = true;
            this.que18.Size = new System.Drawing.Size(480, 80);
            this.que18.TabIndex = 54;
            // 
            // que17
            // 
            this.que17.BackColor = System.Drawing.Color.Gainsboro;
            this.que17.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que17.Location = new System.Drawing.Point(78, 599);
            this.que17.Multiline = true;
            this.que17.Name = "que17";
            this.que17.ReadOnly = true;
            this.que17.Size = new System.Drawing.Size(480, 80);
            this.que17.TabIndex = 53;
            // 
            // groupBox20
            // 
            this.groupBox20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox20.Location = new System.Drawing.Point(581, 599);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(127, 69);
            this.groupBox20.TabIndex = 52;
            this.groupBox20.TabStop = false;
            // 
            // rb_tf13
            // 
            this.rb_tf13.AutoSize = true;
            this.rb_tf13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_tf13.Location = new System.Drawing.Point(6, 9);
            this.rb_tf13.Name = "rb_tf13";
            this.rb_tf13.Size = new System.Drawing.Size(56, 22);
            this.rb_tf13.TabIndex = 0;
            this.rb_tf13.TabStop = true;
            this.rb_tf13.Text = "True";
            this.rb_tf13.UseVisualStyleBackColor = true;
            // 
            // rb_tf14
            // 
            this.rb_tf14.AutoSize = true;
            this.rb_tf14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_tf14.Location = new System.Drawing.Point(6, 40);
            this.rb_tf14.Name = "rb_tf14";
            this.rb_tf14.Size = new System.Drawing.Size(62, 22);
            this.rb_tf14.TabIndex = 1;
            this.rb_tf14.TabStop = true;
            this.rb_tf14.Text = "False";
            this.rb_tf14.UseVisualStyleBackColor = true;
            // 
            // groupBox19
            // 
            this.groupBox19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox19.Location = new System.Drawing.Point(581, 500);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(127, 70);
            this.groupBox19.TabIndex = 51;
            this.groupBox19.TabStop = false;
            // 
            // rb_tf11
            // 
            this.rb_tf11.AutoSize = true;
            this.rb_tf11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_tf11.Location = new System.Drawing.Point(6, 9);
            this.rb_tf11.Name = "rb_tf11";
            this.rb_tf11.Size = new System.Drawing.Size(56, 22);
            this.rb_tf11.TabIndex = 0;
            this.rb_tf11.TabStop = true;
            this.rb_tf11.Text = "True";
            this.rb_tf11.UseVisualStyleBackColor = true;
            // 
            // rb_tf12
            // 
            this.rb_tf12.AutoSize = true;
            this.rb_tf12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_tf12.Location = new System.Drawing.Point(6, 40);
            this.rb_tf12.Name = "rb_tf12";
            this.rb_tf12.Size = new System.Drawing.Size(62, 22);
            this.rb_tf12.TabIndex = 1;
            this.rb_tf12.TabStop = true;
            this.rb_tf12.Text = "False";
            this.rb_tf12.UseVisualStyleBackColor = true;
            // 
            // gb_middle
            // 
            this.gb_middle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_middle.Location = new System.Drawing.Point(581, 401);
            this.gb_middle.Name = "gb_middle";
            this.gb_middle.Size = new System.Drawing.Size(127, 70);
            this.gb_middle.TabIndex = 50;
            this.gb_middle.TabStop = false;
            // 
            // rb_tf9
            // 
            this.rb_tf9.AutoSize = true;
            this.rb_tf9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_tf9.Location = new System.Drawing.Point(6, 9);
            this.rb_tf9.Name = "rb_tf9";
            this.rb_tf9.Size = new System.Drawing.Size(56, 22);
            this.rb_tf9.TabIndex = 0;
            this.rb_tf9.TabStop = true;
            this.rb_tf9.Text = "True";
            this.rb_tf9.UseVisualStyleBackColor = true;
            // 
            // rb_tf10
            // 
            this.rb_tf10.AutoSize = true;
            this.rb_tf10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_tf10.Location = new System.Drawing.Point(6, 40);
            this.rb_tf10.Name = "rb_tf10";
            this.rb_tf10.Size = new System.Drawing.Size(62, 22);
            this.rb_tf10.TabIndex = 1;
            this.rb_tf10.TabStop = true;
            this.rb_tf10.Text = "False";
            this.rb_tf10.UseVisualStyleBackColor = true;
            // 
            // groupBox17
            // 
            this.groupBox17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox17.Location = new System.Drawing.Point(581, 302);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(127, 71);
            this.groupBox17.TabIndex = 49;
            this.groupBox17.TabStop = false;
            // 
            // rb_tf7
            // 
            this.rb_tf7.AutoSize = true;
            this.rb_tf7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_tf7.Location = new System.Drawing.Point(6, 9);
            this.rb_tf7.Name = "rb_tf7";
            this.rb_tf7.Size = new System.Drawing.Size(56, 22);
            this.rb_tf7.TabIndex = 0;
            this.rb_tf7.TabStop = true;
            this.rb_tf7.Text = "True";
            this.rb_tf7.UseVisualStyleBackColor = true;
            // 
            // rb_tf8
            // 
            this.rb_tf8.AutoSize = true;
            this.rb_tf8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_tf8.Location = new System.Drawing.Point(6, 43);
            this.rb_tf8.Name = "rb_tf8";
            this.rb_tf8.Size = new System.Drawing.Size(62, 22);
            this.rb_tf8.TabIndex = 1;
            this.rb_tf8.TabStop = true;
            this.rb_tf8.Text = "False";
            this.rb_tf8.UseVisualStyleBackColor = true;
            // 
            // que16
            // 
            this.que16.BackColor = System.Drawing.Color.Gainsboro;
            this.que16.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que16.Location = new System.Drawing.Point(78, 500);
            this.que16.Multiline = true;
            this.que16.Name = "que16";
            this.que16.ReadOnly = true;
            this.que16.Size = new System.Drawing.Size(480, 80);
            this.que16.TabIndex = 48;
            // 
            // que14
            // 
            this.que14.BackColor = System.Drawing.Color.Gainsboro;
            this.que14.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que14.Location = new System.Drawing.Point(78, 302);
            this.que14.Multiline = true;
            this.que14.Name = "que14";
            this.que14.ReadOnly = true;
            this.que14.Size = new System.Drawing.Size(480, 80);
            this.que14.TabIndex = 46;
            // 
            // groupBox16
            // 
            this.groupBox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox16.Location = new System.Drawing.Point(581, 203);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(127, 72);
            this.groupBox16.TabIndex = 45;
            this.groupBox16.TabStop = false;
            // 
            // rb_tf5
            // 
            this.rb_tf5.AutoSize = true;
            this.rb_tf5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_tf5.Location = new System.Drawing.Point(6, 9);
            this.rb_tf5.Name = "rb_tf5";
            this.rb_tf5.Size = new System.Drawing.Size(56, 22);
            this.rb_tf5.TabIndex = 0;
            this.rb_tf5.TabStop = true;
            this.rb_tf5.Text = "True";
            this.rb_tf5.UseVisualStyleBackColor = true;
            // 
            // rb_tf6
            // 
            this.rb_tf6.AutoSize = true;
            this.rb_tf6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_tf6.Location = new System.Drawing.Point(6, 40);
            this.rb_tf6.Name = "rb_tf6";
            this.rb_tf6.Size = new System.Drawing.Size(62, 22);
            this.rb_tf6.TabIndex = 1;
            this.rb_tf6.TabStop = true;
            this.rb_tf6.Text = "False";
            this.rb_tf6.UseVisualStyleBackColor = true;
            // 
            // que13
            // 
            this.que13.BackColor = System.Drawing.Color.Gainsboro;
            this.que13.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que13.Location = new System.Drawing.Point(78, 203);
            this.que13.Multiline = true;
            this.que13.Name = "que13";
            this.que13.ReadOnly = true;
            this.que13.Size = new System.Drawing.Size(480, 80);
            this.que13.TabIndex = 44;
            // 
            // q12
            // 
            this.q12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q12.AutoSize = true;
            this.q12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q12.Location = new System.Drawing.Point(26, 139);
            this.q12.Name = "q12";
            this.q12.Size = new System.Drawing.Size(23, 13);
            this.q12.TabIndex = 42;
            // 
            // q18
            // 
            this.q18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q18.AutoSize = true;
            this.q18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q18.Location = new System.Drawing.Point(26, 733);
            this.q18.Name = "q18";
            this.q18.Size = new System.Drawing.Size(23, 13);
            this.q18.TabIndex = 61;
            // 
            // groupBox14
            // 
            this.groupBox14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox14.Location = new System.Drawing.Point(581, 104);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(127, 67);
            this.groupBox14.TabIndex = 41;
            this.groupBox14.TabStop = false;
            // 
            // rb_tf3
            // 
            this.rb_tf3.AutoSize = true;
            this.rb_tf3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_tf3.Location = new System.Drawing.Point(6, 9);
            this.rb_tf3.Name = "rb_tf3";
            this.rb_tf3.Size = new System.Drawing.Size(56, 22);
            this.rb_tf3.TabIndex = 0;
            this.rb_tf3.TabStop = true;
            this.rb_tf3.Text = "True";
            this.rb_tf3.UseVisualStyleBackColor = true;
            // 
            // rb_tf4
            // 
            this.rb_tf4.AutoSize = true;
            this.rb_tf4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_tf4.Location = new System.Drawing.Point(6, 40);
            this.rb_tf4.Name = "rb_tf4";
            this.rb_tf4.Size = new System.Drawing.Size(62, 22);
            this.rb_tf4.TabIndex = 1;
            this.rb_tf4.TabStop = true;
            this.rb_tf4.Text = "False";
            this.rb_tf4.UseVisualStyleBackColor = true;
            // 
            // que12
            // 
            this.que12.BackColor = System.Drawing.Color.Gainsboro;
            this.que12.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que12.Location = new System.Drawing.Point(78, 104);
            this.que12.Multiline = true;
            this.que12.Name = "que12";
            this.que12.ReadOnly = true;
            this.que12.Size = new System.Drawing.Size(480, 80);
            this.que12.TabIndex = 40;
            // 
            // groupBox13
            // 
            this.groupBox13.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox13.Location = new System.Drawing.Point(581, 5);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(127, 71);
            this.groupBox13.TabIndex = 38;
            this.groupBox13.TabStop = false;
            // 
            // rb_tf1
            // 
            this.rb_tf1.AutoSize = true;
            this.rb_tf1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_tf1.Location = new System.Drawing.Point(6, 8);
            this.rb_tf1.Name = "rb_tf1";
            this.rb_tf1.Size = new System.Drawing.Size(56, 22);
            this.rb_tf1.TabIndex = 0;
            this.rb_tf1.TabStop = true;
            this.rb_tf1.Text = "True";
            this.rb_tf1.UseVisualStyleBackColor = true;
            // 
            // rb_tf2
            // 
            this.rb_tf2.AutoSize = true;
            this.rb_tf2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_tf2.Location = new System.Drawing.Point(6, 42);
            this.rb_tf2.Name = "rb_tf2";
            this.rb_tf2.Size = new System.Drawing.Size(62, 22);
            this.rb_tf2.TabIndex = 1;
            this.rb_tf2.TabStop = true;
            this.rb_tf2.Text = "False";
            this.rb_tf2.UseVisualStyleBackColor = true;
            // 
            // que11
            // 
            this.que11.BackColor = System.Drawing.Color.Gainsboro;
            this.que11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.que11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.que11.Location = new System.Drawing.Point(78, 5);
            this.que11.Multiline = true;
            this.que11.Name = "que11";
            this.que11.ReadOnly = true;
            this.que11.Size = new System.Drawing.Size(480, 80);
            this.que11.TabIndex = 37;
            // 
            // q11
            // 
            this.q11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q11.AutoSize = true;
            this.q11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q11.Location = new System.Drawing.Point(26, 40);
            this.q11.Name = "q11";
            this.q11.Size = new System.Drawing.Size(23, 13);
            this.q11.TabIndex = 39;
            // 
            // q13
            // 
            this.q13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q13.AutoSize = true;
            this.q13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q13.Location = new System.Drawing.Point(26, 238);
            this.q13.Name = "q13";
            this.q13.Size = new System.Drawing.Size(23, 13);
            this.q13.TabIndex = 43;
            // 
            // groupBox15
            // 
            this.groupBox15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox15.Location = new System.Drawing.Point(581, 698);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(127, 68);
            this.groupBox15.TabIndex = 53;
            this.groupBox15.TabStop = false;
            // 
            // rb_tf15
            // 
            this.rb_tf15.AutoSize = true;
            this.rb_tf15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_tf15.Location = new System.Drawing.Point(6, 9);
            this.rb_tf15.Name = "rb_tf15";
            this.rb_tf15.Size = new System.Drawing.Size(56, 22);
            this.rb_tf15.TabIndex = 0;
            this.rb_tf15.TabStop = true;
            this.rb_tf15.Text = "True";
            this.rb_tf15.UseVisualStyleBackColor = true;
            // 
            // rb_tf16
            // 
            this.rb_tf16.AutoSize = true;
            this.rb_tf16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_tf16.Location = new System.Drawing.Point(6, 40);
            this.rb_tf16.Name = "rb_tf16";
            this.rb_tf16.Size = new System.Drawing.Size(62, 22);
            this.rb_tf16.TabIndex = 1;
            this.rb_tf16.TabStop = true;
            this.rb_tf16.Text = "False";
            this.rb_tf16.UseVisualStyleBackColor = true;
            // 
            // q19
            // 
            this.q19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q19.AutoSize = true;
            this.q19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q19.Location = new System.Drawing.Point(26, 832);
            this.q19.Name = "q19";
            this.q19.Size = new System.Drawing.Size(23, 13);
            this.q19.TabIndex = 44;
            // 
            // q20
            // 
            this.q20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.q20.AutoSize = true;
            this.q20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q20.Location = new System.Drawing.Point(22, 931);
            this.q20.Name = "q20";
            this.q20.Size = new System.Drawing.Size(30, 13);
            this.q20.TabIndex = 44;
            // 
            // panel19
            // 
            this.panel19.Location = new System.Drawing.Point(78, 988);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(360, 47);
            this.panel19.TabIndex = 22;
            // 
            // btn_tf_view
            // 
            this.btn_tf_view.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_tf_view.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.btn_tf_view.Location = new System.Drawing.Point(211, -1);
            this.btn_tf_view.Name = "btn_tf_view";
            this.btn_tf_view.Size = new System.Drawing.Size(107, 33);
            this.btn_tf_view.TabIndex = 67;
            this.btn_tf_view.Text = "View Answer";
            this.btn_tf_view.UseVisualStyleBackColor = false;
            this.btn_tf_view.Visible = false;
            // 
            // btn_Q2_submit
            // 
            this.btn_Q2_submit.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Q2_submit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Q2_submit.Location = new System.Drawing.Point(46, -1);
            this.btn_Q2_submit.Name = "btn_Q2_submit";
            this.btn_Q2_submit.Size = new System.Drawing.Size(85, 33);
            this.btn_Q2_submit.TabIndex = 65;
            this.btn_Q2_submit.Text = "Submit";
            this.btn_Q2_submit.UseVisualStyleBackColor = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tab_Q1);
            this.tabControl1.Controls.Add(this.tab_short_ans);
            this.tabControl1.Controls.Add(this.tab_programme);
            this.tabControl1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(14, 209);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(907, 1200);
            this.tabControl1.TabIndex = 96;
            // 
            // tab_Q1
            // 
            this.tab_Q1.Controls.Add(this.panel4);
            this.tab_Q1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tab_Q1.Location = new System.Drawing.Point(4, 24);
            this.tab_Q1.Name = "tab_Q1";
            this.tab_Q1.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Q1.Size = new System.Drawing.Size(899, 1172);
            this.tab_Q1.TabIndex = 0;
            this.tab_Q1.Text = "Q1";
            this.tab_Q1.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.AutoScroll = true;
            this.panel4.Controls.Add(this.tableLayoutPanel2);
            this.panel4.Cursor = System.Windows.Forms.Cursors.AppStarting;
            this.panel4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel4.Location = new System.Drawing.Point(3, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(885, 471);
            this.panel4.TabIndex = 30;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.033335F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.82445F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 180F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.14221F));
            this.tableLayoutPanel2.Controls.Add(this.label46, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label45, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.groupBox55, 2, 19);
            this.tableLayoutPanel2.Controls.Add(this.groupBox53, 2, 15);
            this.tableLayoutPanel2.Controls.Add(this.groupBox52, 2, 13);
            this.tableLayoutPanel2.Controls.Add(this.groupBox51, 2, 11);
            this.tableLayoutPanel2.Controls.Add(this.groupBox50, 2, 9);
            this.tableLayoutPanel2.Controls.Add(this.groupBox48, 2, 7);
            this.tableLayoutPanel2.Controls.Add(this.groupBox47, 2, 5);
            this.tableLayoutPanel2.Controls.Add(this.groupBox10, 3, 19);
            this.tableLayoutPanel2.Controls.Add(this.groupBox9, 3, 17);
            this.tableLayoutPanel2.Controls.Add(this.groupBox8, 3, 15);
            this.tableLayoutPanel2.Controls.Add(this.groupBox7, 3, 13);
            this.tableLayoutPanel2.Controls.Add(this.groupBox6, 3, 11);
            this.tableLayoutPanel2.Controls.Add(this.groupBox5, 3, 9);
            this.tableLayoutPanel2.Controls.Add(this.groupBox4, 3, 7);
            this.tableLayoutPanel2.Controls.Add(this.groupBox3, 3, 5);
            this.tableLayoutPanel2.Controls.Add(this.groupBox2, 3, 3);
            this.tableLayoutPanel2.Controls.Add(this.label2, 0, 19);
            this.tableLayoutPanel2.Controls.Add(this.txtQ6, 1, 11);
            this.tableLayoutPanel2.Controls.Add(this.label7, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label8, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label16, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.label17, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.label18, 0, 9);
            this.tableLayoutPanel2.Controls.Add(this.txtQ2, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.txtQ4, 1, 7);
            this.tableLayoutPanel2.Controls.Add(this.txtQ5, 1, 9);
            this.tableLayoutPanel2.Controls.Add(this.txtQ7, 1, 13);
            this.tableLayoutPanel2.Controls.Add(this.txtQ8, 1, 15);
            this.tableLayoutPanel2.Controls.Add(this.txtQ9, 1, 17);
            this.tableLayoutPanel2.Controls.Add(this.txtQ3, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.label19, 0, 11);
            this.tableLayoutPanel2.Controls.Add(this.label20, 0, 13);
            this.tableLayoutPanel2.Controls.Add(this.label21, 0, 15);
            this.tableLayoutPanel2.Controls.Add(this.label22, 0, 17);
            this.tableLayoutPanel2.Controls.Add(this.txtQ10, 1, 19);
            this.tableLayoutPanel2.Controls.Add(this.txtQ1, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.groupBox1, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.groupBox11, 3, 20);
            this.tableLayoutPanel2.Controls.Add(this.groupBox45, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.groupBox46, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.groupBox54, 2, 17);
            this.tableLayoutPanel2.Controls.Add(this.allwrong, 2, 20);
            this.tableLayoutPanel2.Controls.Add(this.label44, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label47, 3, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 70);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 22;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(850, 1115);
            this.tableLayoutPanel2.TabIndex = 29;
            this.tableLayoutPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel2_Paint);
            // 
            // label46
            // 
            this.label46.Location = new System.Drawing.Point(469, 2);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(126, 20);
            this.label46.TabIndex = 118;
            this.label46.Text = "Model Answer";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label45
            // 
            this.label45.Location = new System.Drawing.Point(66, 2);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(97, 20);
            this.label45.TabIndex = 117;
            this.label45.Text = "Question";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox55
            // 
            this.groupBox55.Controls.Add(this.textBox38);
            this.groupBox55.Location = new System.Drawing.Point(469, 928);
            this.groupBox55.Name = "groupBox55";
            this.groupBox55.Size = new System.Drawing.Size(174, 84);
            this.groupBox55.TabIndex = 116;
            this.groupBox55.TabStop = false;
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(0, 12);
            this.textBox38.Name = "textBox38";
            this.textBox38.ReadOnly = true;
            this.textBox38.Size = new System.Drawing.Size(174, 26);
            this.textBox38.TabIndex = 0;
            // 
            // groupBox53
            // 
            this.groupBox53.Controls.Add(this.textBox36);
            this.groupBox53.Location = new System.Drawing.Point(469, 730);
            this.groupBox53.Name = "groupBox53";
            this.groupBox53.Size = new System.Drawing.Size(174, 84);
            this.groupBox53.TabIndex = 114;
            this.groupBox53.TabStop = false;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(0, 12);
            this.textBox36.Name = "textBox36";
            this.textBox36.ReadOnly = true;
            this.textBox36.Size = new System.Drawing.Size(174, 26);
            this.textBox36.TabIndex = 0;
            // 
            // groupBox52
            // 
            this.groupBox52.Controls.Add(this.textBox35);
            this.groupBox52.Location = new System.Drawing.Point(469, 631);
            this.groupBox52.Name = "groupBox52";
            this.groupBox52.Size = new System.Drawing.Size(174, 84);
            this.groupBox52.TabIndex = 115;
            this.groupBox52.TabStop = false;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(0, 12);
            this.textBox35.Name = "textBox35";
            this.textBox35.ReadOnly = true;
            this.textBox35.Size = new System.Drawing.Size(174, 26);
            this.textBox35.TabIndex = 0;
            // 
            // groupBox51
            // 
            this.groupBox51.Controls.Add(this.textBox34);
            this.groupBox51.Location = new System.Drawing.Point(469, 532);
            this.groupBox51.Name = "groupBox51";
            this.groupBox51.Size = new System.Drawing.Size(174, 84);
            this.groupBox51.TabIndex = 115;
            this.groupBox51.TabStop = false;
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(0, 12);
            this.textBox34.Name = "textBox34";
            this.textBox34.ReadOnly = true;
            this.textBox34.Size = new System.Drawing.Size(174, 26);
            this.textBox34.TabIndex = 0;
            // 
            // groupBox50
            // 
            this.groupBox50.Controls.Add(this.textBox33);
            this.groupBox50.Location = new System.Drawing.Point(469, 433);
            this.groupBox50.Name = "groupBox50";
            this.groupBox50.Size = new System.Drawing.Size(174, 84);
            this.groupBox50.TabIndex = 115;
            this.groupBox50.TabStop = false;
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(0, 12);
            this.textBox33.Name = "textBox33";
            this.textBox33.ReadOnly = true;
            this.textBox33.Size = new System.Drawing.Size(174, 26);
            this.textBox33.TabIndex = 0;
            // 
            // groupBox48
            // 
            this.groupBox48.Controls.Add(this.textBox32);
            this.groupBox48.Location = new System.Drawing.Point(469, 334);
            this.groupBox48.Name = "groupBox48";
            this.groupBox48.Size = new System.Drawing.Size(174, 84);
            this.groupBox48.TabIndex = 115;
            this.groupBox48.TabStop = false;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(0, 12);
            this.textBox32.Name = "textBox32";
            this.textBox32.ReadOnly = true;
            this.textBox32.Size = new System.Drawing.Size(174, 26);
            this.textBox32.TabIndex = 0;
            // 
            // groupBox47
            // 
            this.groupBox47.Controls.Add(this.textBox31);
            this.groupBox47.Location = new System.Drawing.Point(469, 235);
            this.groupBox47.Name = "groupBox47";
            this.groupBox47.Size = new System.Drawing.Size(174, 84);
            this.groupBox47.TabIndex = 114;
            this.groupBox47.TabStop = false;
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(0, 0);
            this.textBox31.Name = "textBox31";
            this.textBox31.ReadOnly = true;
            this.textBox31.Size = new System.Drawing.Size(174, 26);
            this.textBox31.TabIndex = 0;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.txtQ1Ans10);
            this.groupBox10.Controls.Add(this.R10);
            this.groupBox10.Location = new System.Drawing.Point(651, 928);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(193, 84);
            this.groupBox10.TabIndex = 111;
            this.groupBox10.TabStop = false;
            // 
            // txtQ1Ans10
            // 
            this.txtQ1Ans10.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtQ1Ans10.Location = new System.Drawing.Point(7, 13);
            this.txtQ1Ans10.Name = "txtQ1Ans10";
            this.txtQ1Ans10.ReadOnly = true;
            this.txtQ1Ans10.Size = new System.Drawing.Size(219, 26);
            this.txtQ1Ans10.TabIndex = 48;
            // 
            // R10
            // 
            this.R10.AutoSize = true;
            this.R10.ForeColor = System.Drawing.Color.Green;
            this.R10.Location = new System.Drawing.Point(68, 55);
            this.R10.Name = "R10";
            this.R10.Size = new System.Drawing.Size(65, 23);
            this.R10.TabIndex = 21;
            this.R10.Text = "Right";
            this.R10.UseVisualStyleBackColor = true;
            this.R10.CheckedChanged += new System.EventHandler(this.checkBox21_CheckedChanged);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.txtQ1Ans9);
            this.groupBox9.Controls.Add(this.R9);
            this.groupBox9.Location = new System.Drawing.Point(651, 829);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(193, 84);
            this.groupBox9.TabIndex = 111;
            this.groupBox9.TabStop = false;
            // 
            // txtQ1Ans9
            // 
            this.txtQ1Ans9.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtQ1Ans9.Location = new System.Drawing.Point(7, 13);
            this.txtQ1Ans9.Name = "txtQ1Ans9";
            this.txtQ1Ans9.ReadOnly = true;
            this.txtQ1Ans9.Size = new System.Drawing.Size(219, 26);
            this.txtQ1Ans9.TabIndex = 48;
            // 
            // R9
            // 
            this.R9.AutoSize = true;
            this.R9.ForeColor = System.Drawing.Color.Green;
            this.R9.Location = new System.Drawing.Point(68, 57);
            this.R9.Name = "R9";
            this.R9.Size = new System.Drawing.Size(65, 23);
            this.R9.TabIndex = 21;
            this.R9.Text = "Right";
            this.R9.UseVisualStyleBackColor = true;
            this.R9.CheckedChanged += new System.EventHandler(this.checkBox19_CheckedChanged);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.txtQ1Ans8);
            this.groupBox8.Controls.Add(this.R8);
            this.groupBox8.Location = new System.Drawing.Point(651, 730);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(193, 84);
            this.groupBox8.TabIndex = 111;
            this.groupBox8.TabStop = false;
            // 
            // txtQ1Ans8
            // 
            this.txtQ1Ans8.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtQ1Ans8.Location = new System.Drawing.Point(7, 13);
            this.txtQ1Ans8.Name = "txtQ1Ans8";
            this.txtQ1Ans8.ReadOnly = true;
            this.txtQ1Ans8.Size = new System.Drawing.Size(219, 26);
            this.txtQ1Ans8.TabIndex = 48;
            // 
            // R8
            // 
            this.R8.AutoSize = true;
            this.R8.ForeColor = System.Drawing.Color.Green;
            this.R8.Location = new System.Drawing.Point(68, 55);
            this.R8.Name = "R8";
            this.R8.Size = new System.Drawing.Size(65, 23);
            this.R8.TabIndex = 21;
            this.R8.Text = "Right";
            this.R8.UseVisualStyleBackColor = true;
            this.R8.CheckedChanged += new System.EventHandler(this.checkBox17_CheckedChanged);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txtQ1Ans7);
            this.groupBox7.Controls.Add(this.R7);
            this.groupBox7.Location = new System.Drawing.Point(651, 631);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(193, 84);
            this.groupBox7.TabIndex = 111;
            this.groupBox7.TabStop = false;
            // 
            // txtQ1Ans7
            // 
            this.txtQ1Ans7.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtQ1Ans7.Location = new System.Drawing.Point(7, 13);
            this.txtQ1Ans7.Name = "txtQ1Ans7";
            this.txtQ1Ans7.ReadOnly = true;
            this.txtQ1Ans7.Size = new System.Drawing.Size(219, 26);
            this.txtQ1Ans7.TabIndex = 48;
            // 
            // R7
            // 
            this.R7.AutoSize = true;
            this.R7.ForeColor = System.Drawing.Color.Green;
            this.R7.Location = new System.Drawing.Point(68, 55);
            this.R7.Name = "R7";
            this.R7.Size = new System.Drawing.Size(65, 23);
            this.R7.TabIndex = 21;
            this.R7.Text = "Right";
            this.R7.UseVisualStyleBackColor = true;
            this.R7.CheckedChanged += new System.EventHandler(this.checkBox15_CheckedChanged);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.txtQ1Ans6);
            this.groupBox6.Controls.Add(this.R6);
            this.groupBox6.Location = new System.Drawing.Point(651, 532);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(193, 84);
            this.groupBox6.TabIndex = 111;
            this.groupBox6.TabStop = false;
            // 
            // txtQ1Ans6
            // 
            this.txtQ1Ans6.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtQ1Ans6.Location = new System.Drawing.Point(7, 13);
            this.txtQ1Ans6.Name = "txtQ1Ans6";
            this.txtQ1Ans6.ReadOnly = true;
            this.txtQ1Ans6.Size = new System.Drawing.Size(219, 26);
            this.txtQ1Ans6.TabIndex = 48;
            // 
            // R6
            // 
            this.R6.AutoSize = true;
            this.R6.ForeColor = System.Drawing.Color.Green;
            this.R6.Location = new System.Drawing.Point(68, 55);
            this.R6.Name = "R6";
            this.R6.Size = new System.Drawing.Size(65, 23);
            this.R6.TabIndex = 21;
            this.R6.Text = "Right";
            this.R6.UseVisualStyleBackColor = true;
            this.R6.CheckedChanged += new System.EventHandler(this.checkBox13_CheckedChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtQ1Ans5);
            this.groupBox5.Controls.Add(this.R5);
            this.groupBox5.Location = new System.Drawing.Point(651, 433);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(193, 84);
            this.groupBox5.TabIndex = 111;
            this.groupBox5.TabStop = false;
            // 
            // txtQ1Ans5
            // 
            this.txtQ1Ans5.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtQ1Ans5.Location = new System.Drawing.Point(7, 13);
            this.txtQ1Ans5.Name = "txtQ1Ans5";
            this.txtQ1Ans5.ReadOnly = true;
            this.txtQ1Ans5.Size = new System.Drawing.Size(219, 26);
            this.txtQ1Ans5.TabIndex = 48;
            // 
            // R5
            // 
            this.R5.AutoSize = true;
            this.R5.ForeColor = System.Drawing.Color.Green;
            this.R5.Location = new System.Drawing.Point(68, 55);
            this.R5.Name = "R5";
            this.R5.Size = new System.Drawing.Size(65, 23);
            this.R5.TabIndex = 21;
            this.R5.Text = "Right";
            this.R5.UseVisualStyleBackColor = true;
            this.R5.CheckedChanged += new System.EventHandler(this.checkBox11_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtQ1Ans4);
            this.groupBox4.Controls.Add(this.R4);
            this.groupBox4.Location = new System.Drawing.Point(651, 334);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(193, 84);
            this.groupBox4.TabIndex = 111;
            this.groupBox4.TabStop = false;
            // 
            // txtQ1Ans4
            // 
            this.txtQ1Ans4.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtQ1Ans4.Location = new System.Drawing.Point(7, 13);
            this.txtQ1Ans4.Name = "txtQ1Ans4";
            this.txtQ1Ans4.ReadOnly = true;
            this.txtQ1Ans4.Size = new System.Drawing.Size(219, 26);
            this.txtQ1Ans4.TabIndex = 48;
            // 
            // R4
            // 
            this.R4.AutoSize = true;
            this.R4.ForeColor = System.Drawing.Color.Green;
            this.R4.Location = new System.Drawing.Point(68, 55);
            this.R4.Name = "R4";
            this.R4.Size = new System.Drawing.Size(65, 23);
            this.R4.TabIndex = 21;
            this.R4.Text = "Right";
            this.R4.UseVisualStyleBackColor = true;
            this.R4.CheckedChanged += new System.EventHandler(this.checkBox9_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtQ1Ans3);
            this.groupBox3.Controls.Add(this.R3);
            this.groupBox3.Location = new System.Drawing.Point(651, 235);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(193, 84);
            this.groupBox3.TabIndex = 110;
            this.groupBox3.TabStop = false;
            // 
            // txtQ1Ans3
            // 
            this.txtQ1Ans3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtQ1Ans3.Location = new System.Drawing.Point(7, 13);
            this.txtQ1Ans3.Name = "txtQ1Ans3";
            this.txtQ1Ans3.ReadOnly = true;
            this.txtQ1Ans3.Size = new System.Drawing.Size(219, 26);
            this.txtQ1Ans3.TabIndex = 48;
            // 
            // R3
            // 
            this.R3.AutoSize = true;
            this.R3.ForeColor = System.Drawing.Color.Green;
            this.R3.Location = new System.Drawing.Point(68, 55);
            this.R3.Name = "R3";
            this.R3.Size = new System.Drawing.Size(65, 23);
            this.R3.TabIndex = 21;
            this.R3.Text = "Right";
            this.R3.UseVisualStyleBackColor = true;
            this.R3.CheckedChanged += new System.EventHandler(this.checkBox7_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.R2);
            this.groupBox2.Controls.Add(this.txtQ1Ans2);
            this.groupBox2.Location = new System.Drawing.Point(651, 136);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(193, 84);
            this.groupBox2.TabIndex = 109;
            this.groupBox2.TabStop = false;
            // 
            // R2
            // 
            this.R2.AutoSize = true;
            this.R2.ForeColor = System.Drawing.Color.Green;
            this.R2.Location = new System.Drawing.Point(68, 55);
            this.R2.Name = "R2";
            this.R2.Size = new System.Drawing.Size(65, 23);
            this.R2.TabIndex = 21;
            this.R2.Text = "Right";
            this.R2.UseVisualStyleBackColor = true;
            this.R2.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // txtQ1Ans2
            // 
            this.txtQ1Ans2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtQ1Ans2.Location = new System.Drawing.Point(7, 12);
            this.txtQ1Ans2.Name = "txtQ1Ans2";
            this.txtQ1Ans2.ReadOnly = true;
            this.txtQ1Ans2.Size = new System.Drawing.Size(219, 26);
            this.txtQ1Ans2.TabIndex = 20;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(16, 963);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 46;
            this.label2.Text = "Q10";
            // 
            // txtQ6
            // 
            this.txtQ6.BackColor = System.Drawing.Color.Gainsboro;
            this.txtQ6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtQ6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQ6.Location = new System.Drawing.Point(66, 532);
            this.txtQ6.Multiline = true;
            this.txtQ6.Name = "txtQ6";
            this.txtQ6.ReadOnly = true;
            this.txtQ6.Size = new System.Drawing.Size(395, 80);
            this.txtQ6.TabIndex = 37;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(20, 72);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "Q1";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(20, 171);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(23, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Q2";
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(20, 270);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(23, 13);
            this.label16.TabIndex = 9;
            this.label16.Text = "Q3";
            // 
            // label17
            // 
            this.label17.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(20, 369);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(23, 13);
            this.label17.TabIndex = 11;
            this.label17.Text = "Q4";
            this.label17.UseWaitCursor = true;
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(20, 468);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(23, 13);
            this.label18.TabIndex = 13;
            this.label18.Text = "Q5";
            // 
            // txtQ2
            // 
            this.txtQ2.BackColor = System.Drawing.Color.Gainsboro;
            this.txtQ2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtQ2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQ2.Location = new System.Drawing.Point(66, 136);
            this.txtQ2.Multiline = true;
            this.txtQ2.Name = "txtQ2";
            this.txtQ2.ReadOnly = true;
            this.txtQ2.Size = new System.Drawing.Size(395, 80);
            this.txtQ2.TabIndex = 33;
            // 
            // txtQ4
            // 
            this.txtQ4.BackColor = System.Drawing.Color.Gainsboro;
            this.txtQ4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtQ4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQ4.Location = new System.Drawing.Point(66, 334);
            this.txtQ4.Multiline = true;
            this.txtQ4.Name = "txtQ4";
            this.txtQ4.ReadOnly = true;
            this.txtQ4.Size = new System.Drawing.Size(395, 80);
            this.txtQ4.TabIndex = 35;
            // 
            // txtQ5
            // 
            this.txtQ5.BackColor = System.Drawing.Color.Gainsboro;
            this.txtQ5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtQ5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQ5.Location = new System.Drawing.Point(66, 433);
            this.txtQ5.Multiline = true;
            this.txtQ5.Name = "txtQ5";
            this.txtQ5.ReadOnly = true;
            this.txtQ5.Size = new System.Drawing.Size(395, 80);
            this.txtQ5.TabIndex = 36;
            // 
            // txtQ7
            // 
            this.txtQ7.BackColor = System.Drawing.Color.Gainsboro;
            this.txtQ7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtQ7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQ7.Location = new System.Drawing.Point(66, 631);
            this.txtQ7.Multiline = true;
            this.txtQ7.Name = "txtQ7";
            this.txtQ7.ReadOnly = true;
            this.txtQ7.Size = new System.Drawing.Size(395, 80);
            this.txtQ7.TabIndex = 38;
            // 
            // txtQ8
            // 
            this.txtQ8.BackColor = System.Drawing.Color.Gainsboro;
            this.txtQ8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtQ8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQ8.Location = new System.Drawing.Point(66, 730);
            this.txtQ8.Multiline = true;
            this.txtQ8.Name = "txtQ8";
            this.txtQ8.ReadOnly = true;
            this.txtQ8.Size = new System.Drawing.Size(395, 80);
            this.txtQ8.TabIndex = 39;
            // 
            // txtQ9
            // 
            this.txtQ9.BackColor = System.Drawing.Color.Gainsboro;
            this.txtQ9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtQ9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQ9.Location = new System.Drawing.Point(66, 829);
            this.txtQ9.Multiline = true;
            this.txtQ9.Name = "txtQ9";
            this.txtQ9.ReadOnly = true;
            this.txtQ9.Size = new System.Drawing.Size(395, 80);
            this.txtQ9.TabIndex = 40;
            // 
            // txtQ3
            // 
            this.txtQ3.BackColor = System.Drawing.Color.Gainsboro;
            this.txtQ3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtQ3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQ3.Location = new System.Drawing.Point(66, 235);
            this.txtQ3.Multiline = true;
            this.txtQ3.Name = "txtQ3";
            this.txtQ3.ReadOnly = true;
            this.txtQ3.Size = new System.Drawing.Size(395, 80);
            this.txtQ3.TabIndex = 34;
            // 
            // label19
            // 
            this.label19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(20, 567);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(23, 13);
            this.label19.TabIndex = 42;
            this.label19.Text = "Q6";
            // 
            // label20
            // 
            this.label20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(20, 666);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(23, 13);
            this.label20.TabIndex = 43;
            this.label20.Text = "Q7";
            // 
            // label21
            // 
            this.label21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(20, 765);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(23, 13);
            this.label21.TabIndex = 44;
            this.label21.Text = "Q8";
            // 
            // label22
            // 
            this.label22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(20, 864);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(23, 13);
            this.label22.TabIndex = 45;
            this.label22.Text = "Q9";
            // 
            // txtQ10
            // 
            this.txtQ10.BackColor = System.Drawing.Color.Gainsboro;
            this.txtQ10.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtQ10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQ10.Location = new System.Drawing.Point(66, 928);
            this.txtQ10.Multiline = true;
            this.txtQ10.Name = "txtQ10";
            this.txtQ10.ReadOnly = true;
            this.txtQ10.Size = new System.Drawing.Size(395, 80);
            this.txtQ10.TabIndex = 41;
            // 
            // txtQ1
            // 
            this.txtQ1.BackColor = System.Drawing.Color.Gainsboro;
            this.txtQ1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtQ1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQ1.Location = new System.Drawing.Point(66, 37);
            this.txtQ1.Multiline = true;
            this.txtQ1.Name = "txtQ1";
            this.txtQ1.ReadOnly = true;
            this.txtQ1.Size = new System.Drawing.Size(395, 80);
            this.txtQ1.TabIndex = 32;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.R1);
            this.groupBox1.Controls.Add(this.txtQ1Ans1);
            this.groupBox1.Location = new System.Drawing.Point(651, 37);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(193, 84);
            this.groupBox1.TabIndex = 108;
            this.groupBox1.TabStop = false;
            // 
            // R1
            // 
            this.R1.AutoSize = true;
            this.R1.ForeColor = System.Drawing.Color.Green;
            this.R1.Location = new System.Drawing.Point(68, 55);
            this.R1.Name = "R1";
            this.R1.Size = new System.Drawing.Size(65, 23);
            this.R1.TabIndex = 21;
            this.R1.Text = "Right";
            this.R1.UseVisualStyleBackColor = true;
            this.R1.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // txtQ1Ans1
            // 
            this.txtQ1Ans1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtQ1Ans1.Location = new System.Drawing.Point(7, 12);
            this.txtQ1Ans1.Name = "txtQ1Ans1";
            this.txtQ1Ans1.ReadOnly = true;
            this.txtQ1Ans1.Size = new System.Drawing.Size(219, 26);
            this.txtQ1Ans1.TabIndex = 20;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.txtOutofTen);
            this.groupBox11.Controls.Add(this.label1);
            this.groupBox11.Location = new System.Drawing.Point(651, 1020);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(193, 56);
            this.groupBox11.TabIndex = 112;
            this.groupBox11.TabStop = false;
            // 
            // txtOutofTen
            // 
            this.txtOutofTen.Enabled = false;
            this.txtOutofTen.Location = new System.Drawing.Point(41, 30);
            this.txtOutofTen.Name = "txtOutofTen";
            this.txtOutofTen.Size = new System.Drawing.Size(114, 26);
            this.txtOutofTen.TabIndex = 1;
            this.txtOutofTen.Text = "00";
            this.txtOutofTen.TextChanged += new System.EventHandler(this.txtOutofTen_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Marks Out of 10";
            // 
            // groupBox45
            // 
            this.groupBox45.Controls.Add(this.txtQ1MAns);
            this.groupBox45.Location = new System.Drawing.Point(469, 37);
            this.groupBox45.Name = "groupBox45";
            this.groupBox45.Size = new System.Drawing.Size(174, 84);
            this.groupBox45.TabIndex = 113;
            this.groupBox45.TabStop = false;
            // 
            // txtQ1MAns
            // 
            this.txtQ1MAns.Location = new System.Drawing.Point(0, 12);
            this.txtQ1MAns.Name = "txtQ1MAns";
            this.txtQ1MAns.ReadOnly = true;
            this.txtQ1MAns.Size = new System.Drawing.Size(174, 26);
            this.txtQ1MAns.TabIndex = 0;
            // 
            // groupBox46
            // 
            this.groupBox46.Controls.Add(this.textBox24);
            this.groupBox46.Location = new System.Drawing.Point(469, 136);
            this.groupBox46.Name = "groupBox46";
            this.groupBox46.Size = new System.Drawing.Size(174, 84);
            this.groupBox46.TabIndex = 114;
            this.groupBox46.TabStop = false;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(0, 12);
            this.textBox24.Name = "textBox24";
            this.textBox24.ReadOnly = true;
            this.textBox24.Size = new System.Drawing.Size(174, 26);
            this.textBox24.TabIndex = 0;
            // 
            // groupBox54
            // 
            this.groupBox54.Controls.Add(this.textBox37);
            this.groupBox54.Location = new System.Drawing.Point(469, 829);
            this.groupBox54.Name = "groupBox54";
            this.groupBox54.Size = new System.Drawing.Size(174, 84);
            this.groupBox54.TabIndex = 115;
            this.groupBox54.TabStop = false;
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(0, 12);
            this.textBox37.Name = "textBox37";
            this.textBox37.ReadOnly = true;
            this.textBox37.Size = new System.Drawing.Size(174, 26);
            this.textBox37.TabIndex = 0;
            // 
            // allwrong
            // 
            this.allwrong.AutoSize = true;
            this.allwrong.ForeColor = System.Drawing.Color.Red;
            this.allwrong.Location = new System.Drawing.Point(469, 1020);
            this.allwrong.Name = "allwrong";
            this.allwrong.Size = new System.Drawing.Size(96, 23);
            this.allwrong.TabIndex = 49;
            this.allwrong.Text = "All Wrong";
            this.allwrong.UseVisualStyleBackColor = true;
            // 
            // label44
            // 
            this.label44.Location = new System.Drawing.Point(5, 2);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(53, 20);
            this.label44.TabIndex = 0;
            this.label44.Text = "Sr No";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(651, 2);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(113, 19);
            this.label47.TabIndex = 119;
            this.label47.Text = "Student Answer";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tab_short_ans
            // 
            this.tab_short_ans.AutoScroll = true;
            this.tab_short_ans.Controls.Add(this.panel3);
            this.tab_short_ans.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tab_short_ans.Location = new System.Drawing.Point(4, 24);
            this.tab_short_ans.Name = "tab_short_ans";
            this.tab_short_ans.Padding = new System.Windows.Forms.Padding(3);
            this.tab_short_ans.Size = new System.Drawing.Size(899, 1172);
            this.tab_short_ans.TabIndex = 7;
            this.tab_short_ans.Text = "Q7";
            this.tab_short_ans.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.AutoScroll = true;
            this.panel3.Controls.Add(this.tableLayoutPanel5);
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(893, 452);
            this.panel3.TabIndex = 1;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel5.ColumnCount = 3;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.746356F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 91.25365F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 191F));
            this.tableLayoutPanel5.Controls.Add(this.label78, 2, 0);
            this.tableLayoutPanel5.Controls.Add(this.label77, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.label76, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.groupBox61, 2, 31);
            this.tableLayoutPanel5.Controls.Add(this.groupBox60, 2, 27);
            this.tableLayoutPanel5.Controls.Add(this.groupBox59, 2, 23);
            this.tableLayoutPanel5.Controls.Add(this.groupBox58, 2, 19);
            this.tableLayoutPanel5.Controls.Add(this.groupBox57, 2, 15);
            this.tableLayoutPanel5.Controls.Add(this.label63, 0, 31);
            this.tableLayoutPanel5.Controls.Add(this.label61, 0, 27);
            this.tableLayoutPanel5.Controls.Add(this.label59, 0, 23);
            this.tableLayoutPanel5.Controls.Add(this.label57, 0, 19);
            this.tableLayoutPanel5.Controls.Add(this.label37, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.label25, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.textQ7q1, 1, 1);
            this.tableLayoutPanel5.Controls.Add(this.textBox4, 1, 2);
            this.tableLayoutPanel5.Controls.Add(this.groupBox40, 2, 2);
            this.tableLayoutPanel5.Controls.Add(this.textQ7Ans1, 1, 3);
            this.tableLayoutPanel5.Controls.Add(this.label49, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.textQ7q2, 1, 5);
            this.tableLayoutPanel5.Controls.Add(this.label50, 0, 5);
            this.tableLayoutPanel5.Controls.Add(this.textQ7Ans2, 1, 7);
            this.tableLayoutPanel5.Controls.Add(this.label51, 0, 7);
            this.tableLayoutPanel5.Controls.Add(this.textQ7q3, 1, 9);
            this.tableLayoutPanel5.Controls.Add(this.label52, 0, 9);
            this.tableLayoutPanel5.Controls.Add(this.textQ7Ans3, 1, 11);
            this.tableLayoutPanel5.Controls.Add(this.label53, 0, 11);
            this.tableLayoutPanel5.Controls.Add(this.textQ7q4, 1, 13);
            this.tableLayoutPanel5.Controls.Add(this.label54, 0, 13);
            this.tableLayoutPanel5.Controls.Add(this.textQ7Ans4, 1, 15);
            this.tableLayoutPanel5.Controls.Add(this.label55, 0, 15);
            this.tableLayoutPanel5.Controls.Add(this.textQ7q5, 1, 17);
            this.tableLayoutPanel5.Controls.Add(this.label56, 0, 17);
            this.tableLayoutPanel5.Controls.Add(this.textQ7Ans5, 1, 19);
            this.tableLayoutPanel5.Controls.Add(this.textQ7q6, 1, 21);
            this.tableLayoutPanel5.Controls.Add(this.textQ7Ans6, 1, 23);
            this.tableLayoutPanel5.Controls.Add(this.label58, 0, 21);
            this.tableLayoutPanel5.Controls.Add(this.textQ7q7, 1, 25);
            this.tableLayoutPanel5.Controls.Add(this.label60, 0, 25);
            this.tableLayoutPanel5.Controls.Add(this.textQ7Ans7, 1, 27);
            this.tableLayoutPanel5.Controls.Add(this.textQ7q8, 1, 29);
            this.tableLayoutPanel5.Controls.Add(this.label62, 0, 29);
            this.tableLayoutPanel5.Controls.Add(this.textQ7Ans8, 1, 31);
            this.tableLayoutPanel5.Controls.Add(this.groupBox41, 2, 3);
            this.tableLayoutPanel5.Controls.Add(this.groupBox42, 2, 7);
            this.tableLayoutPanel5.Controls.Add(this.groupBox56, 2, 11);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 74);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 33;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 4F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 4F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 4F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 4F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 4F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 4F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 4F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 79F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 4F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(856, 1787);
            this.tableLayoutPanel5.TabIndex = 1;
            // 
            // label78
            // 
            this.label78.Location = new System.Drawing.Point(666, 1);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(162, 20);
            this.label78.TabIndex = 122;
            this.label78.Text = "Marks";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label77
            // 
            this.label77.Location = new System.Drawing.Point(62, 1);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(165, 20);
            this.label77.TabIndex = 121;
            this.label77.Text = "Question /Answer";
            this.label77.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label76
            // 
            this.label76.Location = new System.Drawing.Point(4, 1);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(51, 20);
            this.label76.TabIndex = 120;
            this.label76.Text = "Sr No";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox61
            // 
            this.groupBox61.Controls.Add(this.CmbAns7_8);
            this.groupBox61.Controls.Add(this.label73);
            this.groupBox61.Location = new System.Drawing.Point(666, 1646);
            this.groupBox61.Name = "groupBox61";
            this.groupBox61.Size = new System.Drawing.Size(95, 82);
            this.groupBox61.TabIndex = 119;
            this.groupBox61.TabStop = false;
            // 
            // CmbAns7_8
            // 
            this.CmbAns7_8.FormattingEnabled = true;
            this.CmbAns7_8.Items.AddRange(new object[] {
            "Select",
            "0",
            "0.5",
            "1",
            "1.5",
            "2"});
            this.CmbAns7_8.Location = new System.Drawing.Point(7, 43);
            this.CmbAns7_8.Name = "CmbAns7_8";
            this.CmbAns7_8.Size = new System.Drawing.Size(70, 27);
            this.CmbAns7_8.TabIndex = 98;
            this.CmbAns7_8.Text = "Select";
            this.CmbAns7_8.SelectedIndexChanged += new System.EventHandler(this.CmbAns7_8_SelectedIndexChanged);
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(17, 21);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(48, 19);
            this.label73.TabIndex = 21;
            this.label73.Text = "Mark";
            // 
            // groupBox60
            // 
            this.groupBox60.Controls.Add(this.CmbAns7_7);
            this.groupBox60.Controls.Add(this.label72);
            this.groupBox60.Location = new System.Drawing.Point(666, 1429);
            this.groupBox60.Name = "groupBox60";
            this.groupBox60.Size = new System.Drawing.Size(95, 82);
            this.groupBox60.TabIndex = 118;
            this.groupBox60.TabStop = false;
            // 
            // CmbAns7_7
            // 
            this.CmbAns7_7.FormattingEnabled = true;
            this.CmbAns7_7.Items.AddRange(new object[] {
            "Select",
            "0",
            "0.5",
            "1",
            "1.5",
            "2"});
            this.CmbAns7_7.Location = new System.Drawing.Point(7, 43);
            this.CmbAns7_7.Name = "CmbAns7_7";
            this.CmbAns7_7.Size = new System.Drawing.Size(70, 27);
            this.CmbAns7_7.TabIndex = 98;
            this.CmbAns7_7.Text = "Select";
            this.CmbAns7_7.SelectedIndexChanged += new System.EventHandler(this.CmbAns7_7_SelectedIndexChanged);
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(17, 21);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(48, 19);
            this.label72.TabIndex = 21;
            this.label72.Text = "Mark";
            // 
            // groupBox59
            // 
            this.groupBox59.Controls.Add(this.CmbAns7_6);
            this.groupBox59.Controls.Add(this.label71);
            this.groupBox59.Location = new System.Drawing.Point(666, 1211);
            this.groupBox59.Name = "groupBox59";
            this.groupBox59.Size = new System.Drawing.Size(95, 82);
            this.groupBox59.TabIndex = 117;
            this.groupBox59.TabStop = false;
            // 
            // CmbAns7_6
            // 
            this.CmbAns7_6.FormattingEnabled = true;
            this.CmbAns7_6.Items.AddRange(new object[] {
            "Select",
            "0",
            "0.5",
            "1",
            "1.5",
            "2"});
            this.CmbAns7_6.Location = new System.Drawing.Point(7, 43);
            this.CmbAns7_6.Name = "CmbAns7_6";
            this.CmbAns7_6.Size = new System.Drawing.Size(70, 27);
            this.CmbAns7_6.TabIndex = 98;
            this.CmbAns7_6.Text = "Select";
            this.CmbAns7_6.SelectedIndexChanged += new System.EventHandler(this.CmbAns7_6_SelectedIndexChanged);
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(17, 21);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(48, 19);
            this.label71.TabIndex = 21;
            this.label71.Text = "Mark";
            // 
            // groupBox58
            // 
            this.groupBox58.Controls.Add(this.CmbAns7_5);
            this.groupBox58.Controls.Add(this.label70);
            this.groupBox58.Location = new System.Drawing.Point(666, 993);
            this.groupBox58.Name = "groupBox58";
            this.groupBox58.Size = new System.Drawing.Size(95, 82);
            this.groupBox58.TabIndex = 116;
            this.groupBox58.TabStop = false;
            // 
            // CmbAns7_5
            // 
            this.CmbAns7_5.FormattingEnabled = true;
            this.CmbAns7_5.Items.AddRange(new object[] {
            "Select",
            "0",
            "0.5",
            "1",
            "1.5",
            "2"});
            this.CmbAns7_5.Location = new System.Drawing.Point(7, 43);
            this.CmbAns7_5.Name = "CmbAns7_5";
            this.CmbAns7_5.Size = new System.Drawing.Size(70, 27);
            this.CmbAns7_5.TabIndex = 98;
            this.CmbAns7_5.Text = "Select";
            this.CmbAns7_5.SelectedIndexChanged += new System.EventHandler(this.CmbAns7_5_SelectedIndexChanged);
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(17, 21);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(48, 19);
            this.label70.TabIndex = 21;
            this.label70.Text = "Mark";
            // 
            // groupBox57
            // 
            this.groupBox57.Controls.Add(this.CmbAns7_4);
            this.groupBox57.Controls.Add(this.label69);
            this.groupBox57.Location = new System.Drawing.Point(666, 775);
            this.groupBox57.Name = "groupBox57";
            this.groupBox57.Size = new System.Drawing.Size(95, 82);
            this.groupBox57.TabIndex = 115;
            this.groupBox57.TabStop = false;
            // 
            // CmbAns7_4
            // 
            this.CmbAns7_4.FormattingEnabled = true;
            this.CmbAns7_4.Items.AddRange(new object[] {
            "Select",
            "0",
            "0.5",
            "1",
            "1.5",
            "2"});
            this.CmbAns7_4.Location = new System.Drawing.Point(7, 43);
            this.CmbAns7_4.Name = "CmbAns7_4";
            this.CmbAns7_4.Size = new System.Drawing.Size(70, 27);
            this.CmbAns7_4.TabIndex = 98;
            this.CmbAns7_4.Text = "Select";
            this.CmbAns7_4.SelectedIndexChanged += new System.EventHandler(this.CmbAns7_4_SelectedIndexChanged);
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(17, 21);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(48, 19);
            this.label69.TabIndex = 21;
            this.label69.Text = "Mark";
            // 
            // label63
            // 
            this.label63.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label63.Location = new System.Drawing.Point(15, 1696);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(28, 13);
            this.label63.TabIndex = 48;
            this.label63.Text = "Ans";
            // 
            // label61
            // 
            this.label61.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label61.Location = new System.Drawing.Point(15, 1479);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(28, 13);
            this.label61.TabIndex = 44;
            this.label61.Text = "Ans";
            // 
            // label59
            // 
            this.label59.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label59.Location = new System.Drawing.Point(15, 1261);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(28, 13);
            this.label59.TabIndex = 40;
            this.label59.Text = "Ans";
            // 
            // label57
            // 
            this.label57.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label57.Location = new System.Drawing.Point(15, 1043);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(28, 13);
            this.label57.TabIndex = 36;
            this.label57.Text = "Ans";
            // 
            // label37
            // 
            this.label37.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label37.Location = new System.Drawing.Point(15, 113);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(28, 4);
            this.label37.TabIndex = 14;
            this.label37.Text = "Ans";
            // 
            // label25
            // 
            this.label25.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label25.Location = new System.Drawing.Point(18, 65);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(23, 13);
            this.label25.TabIndex = 11;
            this.label25.Text = "Q1";
            // 
            // textQ7q1
            // 
            this.textQ7q1.BackColor = System.Drawing.Color.Gainsboro;
            this.textQ7q1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textQ7q1.Location = new System.Drawing.Point(62, 35);
            this.textQ7q1.Multiline = true;
            this.textQ7q1.Name = "textQ7q1";
            this.textQ7q1.ReadOnly = true;
            this.textQ7q1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ7q1.Size = new System.Drawing.Size(597, 74);
            this.textQ7q1.TabIndex = 12;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(62, 116);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox4.Size = new System.Drawing.Size(597, 1);
            this.textBox4.TabIndex = 13;
            // 
            // groupBox40
            // 
            this.groupBox40.Controls.Add(this.label48);
            this.groupBox40.Location = new System.Drawing.Point(666, 116);
            this.groupBox40.Name = "groupBox40";
            this.groupBox40.Size = new System.Drawing.Size(144, 1);
            this.groupBox40.TabIndex = 15;
            this.groupBox40.TabStop = false;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(12, 12);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(121, 19);
            this.label48.TabIndex = 1;
            this.label48.Text = "Marks Out of 10";
            // 
            // textQ7Ans1
            // 
            this.textQ7Ans1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textQ7Ans1.Location = new System.Drawing.Point(62, 121);
            this.textQ7Ans1.Multiline = true;
            this.textQ7Ans1.Name = "textQ7Ans1";
            this.textQ7Ans1.ReadOnly = true;
            this.textQ7Ans1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ7Ans1.Size = new System.Drawing.Size(597, 114);
            this.textQ7Ans1.TabIndex = 16;
            // 
            // label49
            // 
            this.label49.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label49.Location = new System.Drawing.Point(15, 171);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(28, 13);
            this.label49.TabIndex = 17;
            this.label49.Text = "Ans";
            // 
            // textQ7q2
            // 
            this.textQ7q2.BackColor = System.Drawing.Color.Gainsboro;
            this.textQ7q2.Location = new System.Drawing.Point(62, 253);
            this.textQ7q2.Multiline = true;
            this.textQ7q2.Name = "textQ7q2";
            this.textQ7q2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ7q2.Size = new System.Drawing.Size(597, 74);
            this.textQ7q2.TabIndex = 20;
            // 
            // label50
            // 
            this.label50.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label50.Location = new System.Drawing.Point(18, 283);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(23, 13);
            this.label50.TabIndex = 21;
            this.label50.Text = "Q2";
            // 
            // textQ7Ans2
            // 
            this.textQ7Ans2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textQ7Ans2.Location = new System.Drawing.Point(62, 339);
            this.textQ7Ans2.Multiline = true;
            this.textQ7Ans2.Name = "textQ7Ans2";
            this.textQ7Ans2.ReadOnly = true;
            this.textQ7Ans2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ7Ans2.Size = new System.Drawing.Size(597, 114);
            this.textQ7Ans2.TabIndex = 22;
            // 
            // label51
            // 
            this.label51.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label51.Location = new System.Drawing.Point(15, 389);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(28, 13);
            this.label51.TabIndex = 23;
            this.label51.Text = "Ans";
            // 
            // textQ7q3
            // 
            this.textQ7q3.BackColor = System.Drawing.Color.Gainsboro;
            this.textQ7q3.Location = new System.Drawing.Point(62, 471);
            this.textQ7q3.Multiline = true;
            this.textQ7q3.Name = "textQ7q3";
            this.textQ7q3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ7q3.Size = new System.Drawing.Size(597, 74);
            this.textQ7q3.TabIndex = 24;
            // 
            // label52
            // 
            this.label52.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label52.Location = new System.Drawing.Point(18, 501);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(23, 13);
            this.label52.TabIndex = 25;
            this.label52.Text = "Q3";
            // 
            // textQ7Ans3
            // 
            this.textQ7Ans3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textQ7Ans3.Location = new System.Drawing.Point(62, 557);
            this.textQ7Ans3.Multiline = true;
            this.textQ7Ans3.Name = "textQ7Ans3";
            this.textQ7Ans3.ReadOnly = true;
            this.textQ7Ans3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ7Ans3.Size = new System.Drawing.Size(597, 114);
            this.textQ7Ans3.TabIndex = 26;
            // 
            // label53
            // 
            this.label53.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label53.Location = new System.Drawing.Point(15, 607);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(28, 13);
            this.label53.TabIndex = 27;
            this.label53.Text = "Ans";
            // 
            // textQ7q4
            // 
            this.textQ7q4.BackColor = System.Drawing.Color.Gainsboro;
            this.textQ7q4.Location = new System.Drawing.Point(62, 689);
            this.textQ7q4.Multiline = true;
            this.textQ7q4.Name = "textQ7q4";
            this.textQ7q4.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ7q4.Size = new System.Drawing.Size(597, 74);
            this.textQ7q4.TabIndex = 29;
            // 
            // label54
            // 
            this.label54.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label54.Location = new System.Drawing.Point(18, 719);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(23, 13);
            this.label54.TabIndex = 30;
            this.label54.Text = "Q4";
            // 
            // textQ7Ans4
            // 
            this.textQ7Ans4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textQ7Ans4.Location = new System.Drawing.Point(62, 775);
            this.textQ7Ans4.Multiline = true;
            this.textQ7Ans4.Name = "textQ7Ans4";
            this.textQ7Ans4.ReadOnly = true;
            this.textQ7Ans4.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ7Ans4.Size = new System.Drawing.Size(597, 114);
            this.textQ7Ans4.TabIndex = 31;
            // 
            // label55
            // 
            this.label55.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label55.Location = new System.Drawing.Point(15, 825);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(28, 13);
            this.label55.TabIndex = 32;
            this.label55.Text = "Ans";
            // 
            // textQ7q5
            // 
            this.textQ7q5.BackColor = System.Drawing.Color.Gainsboro;
            this.textQ7q5.Location = new System.Drawing.Point(62, 907);
            this.textQ7q5.Multiline = true;
            this.textQ7q5.Name = "textQ7q5";
            this.textQ7q5.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ7q5.Size = new System.Drawing.Size(597, 74);
            this.textQ7q5.TabIndex = 33;
            // 
            // label56
            // 
            this.label56.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label56.Location = new System.Drawing.Point(18, 937);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(23, 13);
            this.label56.TabIndex = 34;
            this.label56.Text = "Q5";
            // 
            // textQ7Ans5
            // 
            this.textQ7Ans5.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textQ7Ans5.Location = new System.Drawing.Point(62, 993);
            this.textQ7Ans5.Multiline = true;
            this.textQ7Ans5.Name = "textQ7Ans5";
            this.textQ7Ans5.ReadOnly = true;
            this.textQ7Ans5.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ7Ans5.Size = new System.Drawing.Size(597, 114);
            this.textQ7Ans5.TabIndex = 35;
            // 
            // textQ7q6
            // 
            this.textQ7q6.BackColor = System.Drawing.Color.Gainsboro;
            this.textQ7q6.Location = new System.Drawing.Point(62, 1125);
            this.textQ7q6.Multiline = true;
            this.textQ7q6.Name = "textQ7q6";
            this.textQ7q6.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ7q6.Size = new System.Drawing.Size(597, 74);
            this.textQ7q6.TabIndex = 37;
            // 
            // textQ7Ans6
            // 
            this.textQ7Ans6.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textQ7Ans6.Location = new System.Drawing.Point(62, 1211);
            this.textQ7Ans6.Multiline = true;
            this.textQ7Ans6.Name = "textQ7Ans6";
            this.textQ7Ans6.ReadOnly = true;
            this.textQ7Ans6.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ7Ans6.Size = new System.Drawing.Size(597, 104);
            this.textQ7Ans6.TabIndex = 38;
            // 
            // label58
            // 
            this.label58.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label58.Location = new System.Drawing.Point(18, 1155);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(23, 13);
            this.label58.TabIndex = 39;
            this.label58.Text = "Q6";
            // 
            // textQ7q7
            // 
            this.textQ7q7.BackColor = System.Drawing.Color.Gainsboro;
            this.textQ7q7.Location = new System.Drawing.Point(62, 1343);
            this.textQ7q7.Multiline = true;
            this.textQ7q7.Name = "textQ7q7";
            this.textQ7q7.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ7q7.Size = new System.Drawing.Size(597, 74);
            this.textQ7q7.TabIndex = 41;
            // 
            // label60
            // 
            this.label60.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label60.Location = new System.Drawing.Point(18, 1373);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(23, 13);
            this.label60.TabIndex = 42;
            this.label60.Text = "Q7";
            // 
            // textQ7Ans7
            // 
            this.textQ7Ans7.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textQ7Ans7.Location = new System.Drawing.Point(62, 1429);
            this.textQ7Ans7.Multiline = true;
            this.textQ7Ans7.Name = "textQ7Ans7";
            this.textQ7Ans7.ReadOnly = true;
            this.textQ7Ans7.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ7Ans7.Size = new System.Drawing.Size(597, 114);
            this.textQ7Ans7.TabIndex = 43;
            // 
            // textQ7q8
            // 
            this.textQ7q8.BackColor = System.Drawing.Color.Gainsboro;
            this.textQ7q8.Location = new System.Drawing.Point(62, 1561);
            this.textQ7q8.Multiline = true;
            this.textQ7q8.Name = "textQ7q8";
            this.textQ7q8.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ7q8.Size = new System.Drawing.Size(597, 73);
            this.textQ7q8.TabIndex = 45;
            // 
            // label62
            // 
            this.label62.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label62.Location = new System.Drawing.Point(18, 1591);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(23, 13);
            this.label62.TabIndex = 46;
            this.label62.Text = "Q8";
            // 
            // textQ7Ans8
            // 
            this.textQ7Ans8.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textQ7Ans8.Location = new System.Drawing.Point(62, 1646);
            this.textQ7Ans8.Multiline = true;
            this.textQ7Ans8.Name = "textQ7Ans8";
            this.textQ7Ans8.ReadOnly = true;
            this.textQ7Ans8.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ7Ans8.Size = new System.Drawing.Size(597, 114);
            this.textQ7Ans8.TabIndex = 47;
            // 
            // groupBox41
            // 
            this.groupBox41.Controls.Add(this.CmbAns7_1);
            this.groupBox41.Controls.Add(this.label66);
            this.groupBox41.Location = new System.Drawing.Point(666, 121);
            this.groupBox41.Name = "groupBox41";
            this.groupBox41.Size = new System.Drawing.Size(91, 84);
            this.groupBox41.TabIndex = 112;
            this.groupBox41.TabStop = false;
            // 
            // CmbAns7_1
            // 
            this.CmbAns7_1.FormattingEnabled = true;
            this.CmbAns7_1.Items.AddRange(new object[] {
            "Select",
            "0",
            "0.5",
            "1",
            "1.5",
            "2"});
            this.CmbAns7_1.Location = new System.Drawing.Point(7, 43);
            this.CmbAns7_1.Name = "CmbAns7_1";
            this.CmbAns7_1.Size = new System.Drawing.Size(70, 27);
            this.CmbAns7_1.TabIndex = 98;
            this.CmbAns7_1.Text = "Select";
            this.CmbAns7_1.SelectedIndexChanged += new System.EventHandler(this.CmbAns7_1_SelectedIndexChanged);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(17, 21);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(48, 19);
            this.label66.TabIndex = 21;
            this.label66.Text = "Mark";
            // 
            // groupBox42
            // 
            this.groupBox42.Controls.Add(this.CmbAns7_2);
            this.groupBox42.Controls.Add(this.label67);
            this.groupBox42.Location = new System.Drawing.Point(666, 339);
            this.groupBox42.Name = "groupBox42";
            this.groupBox42.Size = new System.Drawing.Size(95, 82);
            this.groupBox42.TabIndex = 113;
            this.groupBox42.TabStop = false;
            // 
            // CmbAns7_2
            // 
            this.CmbAns7_2.FormattingEnabled = true;
            this.CmbAns7_2.Items.AddRange(new object[] {
            "Select",
            "0",
            "0.5",
            "1",
            "1.5",
            "2"});
            this.CmbAns7_2.Location = new System.Drawing.Point(7, 43);
            this.CmbAns7_2.Name = "CmbAns7_2";
            this.CmbAns7_2.Size = new System.Drawing.Size(70, 27);
            this.CmbAns7_2.TabIndex = 98;
            this.CmbAns7_2.Text = "Select";
            this.CmbAns7_2.SelectedIndexChanged += new System.EventHandler(this.CmbAns7_2_SelectedIndexChanged);
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(17, 21);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(48, 19);
            this.label67.TabIndex = 21;
            this.label67.Text = "Mark";
            // 
            // groupBox56
            // 
            this.groupBox56.Controls.Add(this.CmbAns7_3);
            this.groupBox56.Controls.Add(this.label68);
            this.groupBox56.Location = new System.Drawing.Point(666, 557);
            this.groupBox56.Name = "groupBox56";
            this.groupBox56.Size = new System.Drawing.Size(95, 82);
            this.groupBox56.TabIndex = 114;
            this.groupBox56.TabStop = false;
            // 
            // CmbAns7_3
            // 
            this.CmbAns7_3.FormattingEnabled = true;
            this.CmbAns7_3.Items.AddRange(new object[] {
            "Select",
            "0",
            "0.5",
            "1",
            "1.5",
            "2"});
            this.CmbAns7_3.Location = new System.Drawing.Point(7, 43);
            this.CmbAns7_3.Name = "CmbAns7_3";
            this.CmbAns7_3.Size = new System.Drawing.Size(70, 27);
            this.CmbAns7_3.TabIndex = 98;
            this.CmbAns7_3.Text = "Select";
            this.CmbAns7_3.SelectedIndexChanged += new System.EventHandler(this.CmbAns7_3_SelectedIndexChanged);
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(17, 21);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(48, 19);
            this.label68.TabIndex = 21;
            this.label68.Text = "Mark";
            // 
            // tab_programme
            // 
            this.tab_programme.Controls.Add(this.panel17);
            this.tab_programme.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tab_programme.Location = new System.Drawing.Point(4, 24);
            this.tab_programme.Name = "tab_programme";
            this.tab_programme.Padding = new System.Windows.Forms.Padding(3);
            this.tab_programme.Size = new System.Drawing.Size(899, 1172);
            this.tab_programme.TabIndex = 8;
            this.tab_programme.Text = "Q8";
            this.tab_programme.UseVisualStyleBackColor = true;
            // 
            // panel17
            // 
            this.panel17.AutoScroll = true;
            this.panel17.Controls.Add(this.tableLayoutPanel17);
            this.panel17.Location = new System.Drawing.Point(3, 3);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(896, 468);
            this.panel17.TabIndex = 0;
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel17.ColumnCount = 3;
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.024745F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 90.97526F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 191F));
            this.tableLayoutPanel17.Controls.Add(this.label81, 2, 0);
            this.tableLayoutPanel17.Controls.Add(this.label80, 1, 0);
            this.tableLayoutPanel17.Controls.Add(this.label79, 0, 0);
            this.tableLayoutPanel17.Controls.Add(this.groupBox63, 2, 15);
            this.tableLayoutPanel17.Controls.Add(this.textBox39, 0, 2);
            this.tableLayoutPanel17.Controls.Add(this.label24, 0, 11);
            this.tableLayoutPanel17.Controls.Add(this.label88, 0, 1);
            this.tableLayoutPanel17.Controls.Add(this.label89, 0, 3);
            this.tableLayoutPanel17.Controls.Add(this.label90, 0, 5);
            this.tableLayoutPanel17.Controls.Add(this.label91, 0, 7);
            this.tableLayoutPanel17.Controls.Add(this.textQ8q2, 1, 5);
            this.tableLayoutPanel17.Controls.Add(this.textQ8Ans2, 1, 7);
            this.tableLayoutPanel17.Controls.Add(this.textQ8q1, 1, 1);
            this.tableLayoutPanel17.Controls.Add(this.groupBox44, 2, 7);
            this.tableLayoutPanel17.Controls.Add(this.textQ8Ans1, 1, 3);
            this.tableLayoutPanel17.Controls.Add(this.textQ8q3, 1, 9);
            this.tableLayoutPanel17.Controls.Add(this.textQ8Ans3, 1, 11);
            this.tableLayoutPanel17.Controls.Add(this.label23, 0, 9);
            this.tableLayoutPanel17.Controls.Add(this.groupBox43, 2, 3);
            this.tableLayoutPanel17.Controls.Add(this.textQ8q4, 1, 13);
            this.tableLayoutPanel17.Controls.Add(this.textQ8Ans4, 1, 15);
            this.tableLayoutPanel17.Controls.Add(this.label64, 0, 13);
            this.tableLayoutPanel17.Controls.Add(this.label65, 0, 15);
            this.tableLayoutPanel17.Controls.Add(this.groupBox62, 2, 11);
            this.tableLayoutPanel17.Location = new System.Drawing.Point(3, 75);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 17;
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 4F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 4F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 4F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 4F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(857, 1110);
            this.tableLayoutPanel17.TabIndex = 5;
            // 
            // label81
            // 
            this.label81.Location = new System.Drawing.Point(667, 1);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(162, 20);
            this.label81.TabIndex = 128;
            this.label81.Text = "Marks";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label80
            // 
            this.label80.Location = new System.Drawing.Point(64, 1);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(165, 20);
            this.label80.TabIndex = 127;
            this.label80.Text = "Question /Answer";
            this.label80.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label79
            // 
            this.label79.Location = new System.Drawing.Point(4, 1);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(53, 20);
            this.label79.TabIndex = 126;
            this.label79.Text = "Sr No";
            this.label79.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox63
            // 
            this.groupBox63.Controls.Add(this.Cmb8b2Ans);
            this.groupBox63.Controls.Add(this.label75);
            this.groupBox63.Location = new System.Drawing.Point(667, 945);
            this.groupBox63.Name = "groupBox63";
            this.groupBox63.Size = new System.Drawing.Size(91, 84);
            this.groupBox63.TabIndex = 125;
            this.groupBox63.TabStop = false;
            // 
            // Cmb8b2Ans
            // 
            this.Cmb8b2Ans.FormattingEnabled = true;
            this.Cmb8b2Ans.Items.AddRange(new object[] {
            "Select",
            "0",
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5",
            "3",
            "3.5",
            "4",
            "4.5",
            "5"});
            this.Cmb8b2Ans.Location = new System.Drawing.Point(13, 42);
            this.Cmb8b2Ans.Name = "Cmb8b2Ans";
            this.Cmb8b2Ans.Size = new System.Drawing.Size(70, 27);
            this.Cmb8b2Ans.TabIndex = 99;
            this.Cmb8b2Ans.Text = "Select";
            this.Cmb8b2Ans.SelectedIndexChanged += new System.EventHandler(this.Cmb8b2Ans_SelectedIndexChanged);
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(17, 21);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(48, 19);
            this.label75.TabIndex = 21;
            this.label75.Text = "Mark";
            // 
            // textBox39
            // 
            this.textBox39.BackColor = System.Drawing.Color.Gainsboro;
            this.textBox39.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox39.Location = new System.Drawing.Point(4, 136);
            this.textBox39.Multiline = true;
            this.textBox39.Name = "textBox39";
            this.textBox39.ReadOnly = true;
            this.textBox39.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox39.Size = new System.Drawing.Size(41, 1);
            this.textBox39.TabIndex = 120;
            // 
            // label24
            // 
            this.label24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label24.Location = new System.Drawing.Point(12, 742);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(36, 13);
            this.label24.TabIndex = 116;
            this.label24.Text = "ANS:";
            // 
            // label88
            // 
            this.label88.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label88.Location = new System.Drawing.Point(19, 75);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(23, 13);
            this.label88.TabIndex = 7;
            this.label88.Text = "Q1";
            // 
            // label89
            // 
            this.label89.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label89.Location = new System.Drawing.Point(12, 206);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(36, 13);
            this.label89.TabIndex = 8;
            this.label89.Text = "ANS:";
            // 
            // label90
            // 
            this.label90.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label90.Location = new System.Drawing.Point(19, 343);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(23, 13);
            this.label90.TabIndex = 10;
            this.label90.Text = "Q2";
            // 
            // label91
            // 
            this.label91.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label91.Location = new System.Drawing.Point(12, 474);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(36, 13);
            this.label91.TabIndex = 9;
            this.label91.Text = "ANS:";
            // 
            // textQ8q2
            // 
            this.textQ8q2.BackColor = System.Drawing.Color.Gainsboro;
            this.textQ8q2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textQ8q2.Location = new System.Drawing.Point(64, 303);
            this.textQ8q2.Multiline = true;
            this.textQ8q2.Name = "textQ8q2";
            this.textQ8q2.ReadOnly = true;
            this.textQ8q2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ8q2.Size = new System.Drawing.Size(596, 94);
            this.textQ8q2.TabIndex = 11;
            // 
            // textQ8Ans2
            // 
            this.textQ8Ans2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textQ8Ans2.Location = new System.Drawing.Point(64, 409);
            this.textQ8Ans2.Multiline = true;
            this.textQ8Ans2.Name = "textQ8Ans2";
            this.textQ8Ans2.ReadOnly = true;
            this.textQ8Ans2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ8Ans2.Size = new System.Drawing.Size(596, 144);
            this.textQ8Ans2.TabIndex = 1;
            // 
            // textQ8q1
            // 
            this.textQ8q1.BackColor = System.Drawing.Color.Gainsboro;
            this.textQ8q1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textQ8q1.Location = new System.Drawing.Point(64, 35);
            this.textQ8q1.Multiline = true;
            this.textQ8q1.Name = "textQ8q1";
            this.textQ8q1.ReadOnly = true;
            this.textQ8q1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ8q1.Size = new System.Drawing.Size(596, 94);
            this.textQ8q1.TabIndex = 13;
            // 
            // groupBox44
            // 
            this.groupBox44.Controls.Add(this.Cmb8a2Ans);
            this.groupBox44.Controls.Add(this.label27);
            this.groupBox44.Location = new System.Drawing.Point(667, 409);
            this.groupBox44.Name = "groupBox44";
            this.groupBox44.Size = new System.Drawing.Size(91, 84);
            this.groupBox44.TabIndex = 112;
            this.groupBox44.TabStop = false;
            // 
            // Cmb8a2Ans
            // 
            this.Cmb8a2Ans.FormattingEnabled = true;
            this.Cmb8a2Ans.Items.AddRange(new object[] {
            "Select",
            "0",
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5",
            "3",
            "3.5",
            "4",
            "4.5",
            "5"});
            this.Cmb8a2Ans.Location = new System.Drawing.Point(13, 42);
            this.Cmb8a2Ans.Name = "Cmb8a2Ans";
            this.Cmb8a2Ans.Size = new System.Drawing.Size(70, 27);
            this.Cmb8a2Ans.TabIndex = 99;
            this.Cmb8a2Ans.Text = "Select";
            this.Cmb8a2Ans.SelectedIndexChanged += new System.EventHandler(this.Cmb8a2Ans_SelectedIndexChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(17, 21);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(48, 19);
            this.label27.TabIndex = 21;
            this.label27.Text = "Mark";
            // 
            // textQ8Ans1
            // 
            this.textQ8Ans1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textQ8Ans1.Location = new System.Drawing.Point(64, 141);
            this.textQ8Ans1.Multiline = true;
            this.textQ8Ans1.Name = "textQ8Ans1";
            this.textQ8Ans1.ReadOnly = true;
            this.textQ8Ans1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ8Ans1.Size = new System.Drawing.Size(596, 144);
            this.textQ8Ans1.TabIndex = 16;
            // 
            // textQ8q3
            // 
            this.textQ8q3.BackColor = System.Drawing.Color.Gainsboro;
            this.textQ8q3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textQ8q3.Location = new System.Drawing.Point(64, 571);
            this.textQ8q3.Multiline = true;
            this.textQ8q3.Name = "textQ8q3";
            this.textQ8q3.ReadOnly = true;
            this.textQ8q3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ8q3.Size = new System.Drawing.Size(596, 94);
            this.textQ8q3.TabIndex = 113;
            // 
            // textQ8Ans3
            // 
            this.textQ8Ans3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textQ8Ans3.Location = new System.Drawing.Point(64, 677);
            this.textQ8Ans3.Multiline = true;
            this.textQ8Ans3.Name = "textQ8Ans3";
            this.textQ8Ans3.ReadOnly = true;
            this.textQ8Ans3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ8Ans3.Size = new System.Drawing.Size(596, 144);
            this.textQ8Ans3.TabIndex = 114;
            // 
            // label23
            // 
            this.label23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label23.Location = new System.Drawing.Point(19, 611);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(23, 13);
            this.label23.TabIndex = 115;
            this.label23.Text = "Q3";
            // 
            // groupBox43
            // 
            this.groupBox43.Controls.Add(this.Cmb8a1Ans);
            this.groupBox43.Controls.Add(this.label26);
            this.groupBox43.Location = new System.Drawing.Point(667, 141);
            this.groupBox43.Name = "groupBox43";
            this.groupBox43.Size = new System.Drawing.Size(91, 84);
            this.groupBox43.TabIndex = 111;
            this.groupBox43.TabStop = false;
            // 
            // Cmb8a1Ans
            // 
            this.Cmb8a1Ans.FormattingEnabled = true;
            this.Cmb8a1Ans.Items.AddRange(new object[] {
            "Select",
            "0",
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5",
            "3",
            "3.5",
            "4",
            "4.5",
            "5"});
            this.Cmb8a1Ans.Location = new System.Drawing.Point(7, 43);
            this.Cmb8a1Ans.Name = "Cmb8a1Ans";
            this.Cmb8a1Ans.Size = new System.Drawing.Size(70, 27);
            this.Cmb8a1Ans.TabIndex = 98;
            this.Cmb8a1Ans.Text = "Select";
            this.Cmb8a1Ans.SelectedIndexChanged += new System.EventHandler(this.Cmb8a1Ans_SelectedIndexChanged);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(17, 21);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(48, 19);
            this.label26.TabIndex = 21;
            this.label26.Text = "Mark";
            // 
            // textQ8q4
            // 
            this.textQ8q4.BackColor = System.Drawing.Color.Gainsboro;
            this.textQ8q4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textQ8q4.Location = new System.Drawing.Point(64, 839);
            this.textQ8q4.Multiline = true;
            this.textQ8q4.Name = "textQ8q4";
            this.textQ8q4.ReadOnly = true;
            this.textQ8q4.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ8q4.Size = new System.Drawing.Size(596, 94);
            this.textQ8q4.TabIndex = 119;
            // 
            // textQ8Ans4
            // 
            this.textQ8Ans4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textQ8Ans4.Location = new System.Drawing.Point(64, 945);
            this.textQ8Ans4.Multiline = true;
            this.textQ8Ans4.Name = "textQ8Ans4";
            this.textQ8Ans4.ReadOnly = true;
            this.textQ8Ans4.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textQ8Ans4.Size = new System.Drawing.Size(596, 144);
            this.textQ8Ans4.TabIndex = 121;
            // 
            // label64
            // 
            this.label64.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label64.Location = new System.Drawing.Point(19, 879);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(23, 13);
            this.label64.TabIndex = 122;
            this.label64.Text = "Q4";
            // 
            // label65
            // 
            this.label65.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label65.Location = new System.Drawing.Point(12, 1010);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(36, 13);
            this.label65.TabIndex = 123;
            this.label65.Text = "ANS:";
            // 
            // groupBox62
            // 
            this.groupBox62.Controls.Add(this.Cmb8b1Ans);
            this.groupBox62.Controls.Add(this.label74);
            this.groupBox62.Location = new System.Drawing.Point(667, 677);
            this.groupBox62.Name = "groupBox62";
            this.groupBox62.Size = new System.Drawing.Size(91, 84);
            this.groupBox62.TabIndex = 124;
            this.groupBox62.TabStop = false;
            // 
            // Cmb8b1Ans
            // 
            this.Cmb8b1Ans.FormattingEnabled = true;
            this.Cmb8b1Ans.Items.AddRange(new object[] {
            "Select",
            "0",
            "0.5",
            "1",
            "1.5",
            "2",
            "2.5",
            "3",
            "3.5",
            "4",
            "4.5",
            "5"});
            this.Cmb8b1Ans.Location = new System.Drawing.Point(13, 42);
            this.Cmb8b1Ans.Name = "Cmb8b1Ans";
            this.Cmb8b1Ans.Size = new System.Drawing.Size(70, 27);
            this.Cmb8b1Ans.TabIndex = 99;
            this.Cmb8b1Ans.Text = "Select";
            this.Cmb8b1Ans.SelectedIndexChanged += new System.EventHandler(this.Cmb8b1Ans_SelectedIndexChanged);
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(17, 21);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(48, 19);
            this.label74.TabIndex = 21;
            this.label74.Text = "Mark";
            // 
            // txtPid
            // 
            this.txtPid.AutoSize = true;
            this.txtPid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPid.ForeColor = System.Drawing.Color.Blue;
            this.txtPid.Location = new System.Drawing.Point(250, 173);
            this.txtPid.Name = "txtPid";
            this.txtPid.Size = new System.Drawing.Size(0, 17);
            this.txtPid.TabIndex = 43;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(104, 173);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(69, 17);
            this.label38.TabIndex = 42;
            this.label38.Text = "Paper Id";
            this.label38.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // btnGiveUp
            // 
            this.btnGiveUp.BackColor = System.Drawing.Color.Violet;
            this.btnGiveUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGiveUp.Location = new System.Drawing.Point(18, 106);
            this.btnGiveUp.Name = "btnGiveUp";
            this.btnGiveUp.Size = new System.Drawing.Size(79, 45);
            this.btnGiveUp.TabIndex = 101;
            this.btnGiveUp.Text = "Back";
            this.btnGiveUp.UseVisualStyleBackColor = false;
            this.btnGiveUp.Click += new System.EventHandler(this.btnGiveUp_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.BackColor = System.Drawing.Color.Green;
            this.btnSubmit.Enabled = false;
            this.btnSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.Location = new System.Drawing.Point(123, 106);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(80, 45);
            this.btnSubmit.TabIndex = 99;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // grid1
            // 
            this.grid1.AllowUserToAddRows = false;
            this.grid1.AllowUserToDeleteRows = false;
            this.grid1.AllowUserToResizeColumns = false;
            this.grid1.AllowUserToResizeRows = false;
            this.grid1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.grid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.q7a,
            this.q8b,
            this.TotalMarks});
            this.grid1.GridColor = System.Drawing.Color.Maroon;
            this.grid1.Location = new System.Drawing.Point(478, 23);
            this.grid1.Name = "grid1";
            this.grid1.Size = new System.Drawing.Size(443, 63);
            this.grid1.TabIndex = 97;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Q1";
            this.Column1.Name = "Column1";
            // 
            // q7a
            // 
            this.q7a.HeaderText = "Q7";
            this.q7a.Name = "q7a";
            this.q7a.ReadOnly = true;
            // 
            // q8b
            // 
            this.q8b.HeaderText = "Q8";
            this.q8b.Name = "q8b";
            this.q8b.ReadOnly = true;
            // 
            // TotalMarks
            // 
            this.TotalMarks.HeaderText = "TotalMarks";
            this.TotalMarks.Name = "TotalMarks";
            this.TotalMarks.ReadOnly = true;
            // 
            // lblStream
            // 
            this.lblStream.AutoSize = true;
            this.lblStream.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStream.Location = new System.Drawing.Point(351, 173);
            this.lblStream.Name = "lblStream";
            this.lblStream.Size = new System.Drawing.Size(59, 17);
            this.lblStream.TabIndex = 106;
            this.lblStream.Text = "Stream";
            this.lblStream.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblStremName
            // 
            this.lblStremName.AutoSize = true;
            this.lblStremName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStremName.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblStremName.Location = new System.Drawing.Point(439, 173);
            this.lblStremName.Name = "lblStremName";
            this.lblStremName.Size = new System.Drawing.Size(59, 17);
            this.lblStremName.TabIndex = 107;
            this.lblStremName.Text = "Stream";
            this.lblStremName.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblMIndex
            // 
            this.lblMIndex.AutoSize = true;
            this.lblMIndex.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMIndex.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblMIndex.Location = new System.Drawing.Point(200, 45);
            this.lblMIndex.Name = "lblMIndex";
            this.lblMIndex.Size = new System.Drawing.Size(0, 17);
            this.lblMIndex.TabIndex = 109;
            this.lblMIndex.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(30, 45);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(150, 17);
            this.label29.TabIndex = 108;
            this.label29.Text = "Moderator Index No";
            this.label29.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // Teacher_Id
            // 
            this.Teacher_Id.AutoSize = true;
            this.Teacher_Id.Location = new System.Drawing.Point(577, 173);
            this.Teacher_Id.Name = "Teacher_Id";
            this.Teacher_Id.Size = new System.Drawing.Size(72, 13);
            this.Teacher_Id.TabIndex = 110;
            this.Teacher_Id.Text = "Teacher_Id";
            // 
            // QueAnswer178
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1015, 749);
            this.ControlBox = false;
            this.Controls.Add(this.Teacher_Id);
            this.Controls.Add(this.lblMIndex);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.lblStremName);
            this.Controls.Add(this.lblStream);
            this.Controls.Add(this.txtPid);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.btnGiveUp);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.grid1);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "QueAnswer178";
            this.Text = "QueAnswer178";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.QueAnswer178_Load);
            this.tabControl1.ResumeLayout(false);
            this.tab_Q1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.groupBox55.ResumeLayout(false);
            this.groupBox55.PerformLayout();
            this.groupBox53.ResumeLayout(false);
            this.groupBox53.PerformLayout();
            this.groupBox52.ResumeLayout(false);
            this.groupBox52.PerformLayout();
            this.groupBox51.ResumeLayout(false);
            this.groupBox51.PerformLayout();
            this.groupBox50.ResumeLayout(false);
            this.groupBox50.PerformLayout();
            this.groupBox48.ResumeLayout(false);
            this.groupBox48.PerformLayout();
            this.groupBox47.ResumeLayout(false);
            this.groupBox47.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox45.ResumeLayout(false);
            this.groupBox45.PerformLayout();
            this.groupBox46.ResumeLayout(false);
            this.groupBox46.PerformLayout();
            this.groupBox54.ResumeLayout(false);
            this.groupBox54.PerformLayout();
            this.tab_short_ans.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.groupBox61.ResumeLayout(false);
            this.groupBox61.PerformLayout();
            this.groupBox60.ResumeLayout(false);
            this.groupBox60.PerformLayout();
            this.groupBox59.ResumeLayout(false);
            this.groupBox59.PerformLayout();
            this.groupBox58.ResumeLayout(false);
            this.groupBox58.PerformLayout();
            this.groupBox57.ResumeLayout(false);
            this.groupBox57.PerformLayout();
            this.groupBox40.ResumeLayout(false);
            this.groupBox40.PerformLayout();
            this.groupBox41.ResumeLayout(false);
            this.groupBox41.PerformLayout();
            this.groupBox42.ResumeLayout(false);
            this.groupBox42.PerformLayout();
            this.groupBox56.ResumeLayout(false);
            this.groupBox56.PerformLayout();
            this.tab_programme.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.tableLayoutPanel17.ResumeLayout(false);
            this.tableLayoutPanel17.PerformLayout();
            this.groupBox63.ResumeLayout(false);
            this.groupBox63.PerformLayout();
            this.groupBox44.ResumeLayout(false);
            this.groupBox44.PerformLayout();
            this.groupBox43.ResumeLayout(false);
            this.groupBox43.PerformLayout();
            this.groupBox62.ResumeLayout(false);
            this.groupBox62.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.RadioButton Q3BR1Q18;
        private System.Windows.Forms.RadioButton Q3BR2Q18;
        private System.Windows.Forms.RadioButton Q3BR3Q18;
        private System.Windows.Forms.RadioButton Q3BR4Q18;
        private System.Windows.Forms.GroupBox groupBox33;
        private System.Windows.Forms.RadioButton Q3BR1Q12;
        private System.Windows.Forms.RadioButton Q3BR2Q12;
        private System.Windows.Forms.RadioButton Q3BR3Q12;
        private System.Windows.Forms.RadioButton Q3BR4Q12;
        private System.Windows.Forms.TextBox que32;
        private System.Windows.Forms.TextBox que38;
        private System.Windows.Forms.TextBox que33;
        private System.Windows.Forms.GroupBox groupBox49;
        private System.Windows.Forms.RadioButton Q3BR1Q11;
        private System.Windows.Forms.RadioButton Q3BR2Q11;
        private System.Windows.Forms.RadioButton Q3BR3Q11;
        private System.Windows.Forms.RadioButton Q3BR4Q11;
        private System.Windows.Forms.TextBox que31;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox que37;
        private System.Windows.Forms.TextBox que36;
        private System.Windows.Forms.TextBox que35;
        private System.Windows.Forms.TextBox que34;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox que39;
        private System.Windows.Forms.TextBox que40;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Button btn_Q3B_submit;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox34;
        private System.Windows.Forms.RadioButton Q3BR1Q13;
        private System.Windows.Forms.RadioButton Q3BR2Q13;
        private System.Windows.Forms.RadioButton Q3BR3Q13;
        private System.Windows.Forms.RadioButton Q3BR4Q13;
        private System.Windows.Forms.GroupBox groupBox35;
        private System.Windows.Forms.RadioButton Q3BR1Q14;
        private System.Windows.Forms.RadioButton Q3BR2Q14;
        private System.Windows.Forms.RadioButton Q3BR3Q14;
        private System.Windows.Forms.RadioButton Q3BR4Q14;
        private System.Windows.Forms.GroupBox groupBox36;
        private System.Windows.Forms.RadioButton Q3BR1Q15;
        private System.Windows.Forms.RadioButton Q3BR2Q15;
        private System.Windows.Forms.RadioButton Q3BR3Q15;
        private System.Windows.Forms.RadioButton Q3BR4Q15;
        private System.Windows.Forms.GroupBox groupBox37;
        private System.Windows.Forms.RadioButton Q3BR1Q16;
        private System.Windows.Forms.RadioButton Q3BR2Q16;
        private System.Windows.Forms.RadioButton Q3BR3Q16;
        private System.Windows.Forms.RadioButton Q3BR4Q16;
        private System.Windows.Forms.GroupBox groupBox38;
        private System.Windows.Forms.RadioButton Q3BR1Q17;
        private System.Windows.Forms.RadioButton Q3BR2Q17;
        private System.Windows.Forms.RadioButton Q3BR3Q17;
        private System.Windows.Forms.RadioButton Q3BR4Q17;
        private System.Windows.Forms.GroupBox groupBox39;
        private System.Windows.Forms.RadioButton Q3BR1Q19;
        private System.Windows.Forms.RadioButton Q3BR2Q19;
        private System.Windows.Forms.RadioButton Q3BR3Q19;
        private System.Windows.Forms.RadioButton Q3BR4Q19;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.RadioButton Q3BR1Q20;
        private System.Windows.Forms.RadioButton Q3BR2Q20;
        private System.Windows.Forms.RadioButton Q3BR3Q20;
        private System.Windows.Forms.RadioButton Q3BR4Q20;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.RadioButton Q3AR1Q4;
        private System.Windows.Forms.RadioButton Q3AR2Q4;
        private System.Windows.Forms.RadioButton Q3AR3Q4;
        private System.Windows.Forms.RadioButton Q3AR4Q4;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.RadioButton Q3AR1Q3;
        private System.Windows.Forms.RadioButton Q3AR2Q3;
        private System.Windows.Forms.RadioButton Q3AR3Q3;
        private System.Windows.Forms.RadioButton Q3AR4Q3;
        private System.Windows.Forms.GroupBox groupBox31;
        private System.Windows.Forms.RadioButton Q3AR1Q1;
        private System.Windows.Forms.RadioButton Q3AR2Q1;
        private System.Windows.Forms.RadioButton Q3AR3Q1;
        private System.Windows.Forms.RadioButton Q3AR4Q1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_mcqa1_view;
        private System.Windows.Forms.Button btn_Q3A_submit;
        private System.Windows.Forms.TextBox que23;
        private System.Windows.Forms.TextBox que21;
        private System.Windows.Forms.Label q23;
        private System.Windows.Forms.Label q22;
        private System.Windows.Forms.TextBox que27;
        private System.Windows.Forms.TextBox que26;
        private System.Windows.Forms.TextBox que25;
        private System.Windows.Forms.TextBox que24;
        private System.Windows.Forms.TextBox que22;
        private System.Windows.Forms.Label q21;
        private System.Windows.Forms.Label q24;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox que28;
        private System.Windows.Forms.TextBox que29;
        private System.Windows.Forms.TextBox que30;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.RadioButton Q3AR1Q2;
        private System.Windows.Forms.RadioButton Q3AR2Q2;
        private System.Windows.Forms.RadioButton Q3AR3Q2;
        private System.Windows.Forms.RadioButton Q3AR4Q2;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.RadioButton Q3AR1Q5;
        private System.Windows.Forms.RadioButton Q3AR2Q5;
        private System.Windows.Forms.RadioButton Q3AR3Q5;
        private System.Windows.Forms.RadioButton Q3AR4Q5;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.RadioButton Q3AR1Q6;
        private System.Windows.Forms.RadioButton Q3AR2Q6;
        private System.Windows.Forms.RadioButton Q3AR3Q6;
        private System.Windows.Forms.RadioButton Q3AR4Q6;
        private System.Windows.Forms.GroupBox groupBox28;
        private System.Windows.Forms.RadioButton Q3AR1Q7;
        private System.Windows.Forms.RadioButton Q3AR2Q7;
        private System.Windows.Forms.RadioButton Q3AR3Q7;
        private System.Windows.Forms.RadioButton Q3AR4Q7;
        private System.Windows.Forms.GroupBox groupBox29;
        private System.Windows.Forms.RadioButton Q3AR1Q8;
        private System.Windows.Forms.RadioButton Q3AR2Q8;
        private System.Windows.Forms.RadioButton Q3AR3Q8;
        private System.Windows.Forms.RadioButton Q3AR4Q8;
        private System.Windows.Forms.GroupBox groupBox30;
        private System.Windows.Forms.RadioButton Q3AR1Q9;
        private System.Windows.Forms.RadioButton Q3AR2Q9;
        private System.Windows.Forms.RadioButton Q3AR3Q9;
        private System.Windows.Forms.RadioButton Q3AR4Q9;
        private System.Windows.Forms.GroupBox groupBox32;
        private System.Windows.Forms.RadioButton Q3AR1Q10;
        private System.Windows.Forms.RadioButton Q3AR2Q10;
        private System.Windows.Forms.RadioButton Q3AR3Q10;
        private System.Windows.Forms.RadioButton Q3AR4Q10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_fib;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Button btn_view;
        private System.Windows.Forms.Button btn_Q1_submit;
        private System.Windows.Forms.TextBox txtans10;
        private System.Windows.Forms.TextBox txtans9;
        private System.Windows.Forms.TextBox txtans8;
        private System.Windows.Forms.TextBox txtans7;
        private System.Windows.Forms.TextBox txtans6;
        private System.Windows.Forms.TextBox txtans5;
        private System.Windows.Forms.TextBox txtans4;
        private System.Windows.Forms.TextBox txtans3;
        private System.Windows.Forms.TextBox txtans2;
        private System.Windows.Forms.TextBox que10;
        private System.Windows.Forms.Label q9;
        private System.Windows.Forms.Label q8;
        private System.Windows.Forms.Label q7;
        private System.Windows.Forms.Label q6;
        private System.Windows.Forms.TextBox que3;
        private System.Windows.Forms.TextBox que9;
        private System.Windows.Forms.TextBox que8;
        private System.Windows.Forms.TextBox que7;
        private System.Windows.Forms.TextBox que5;
        private System.Windows.Forms.TextBox que4;
        private System.Windows.Forms.TextBox que2;
        private System.Windows.Forms.TextBox txtans1;
        private System.Windows.Forms.Label q5;
        private System.Windows.Forms.Label q4;
        private System.Windows.Forms.Label q3;
        private System.Windows.Forms.Label q2;
        private System.Windows.Forms.Label q1;
        private System.Windows.Forms.TextBox que6;
        private System.Windows.Forms.TextBox que1;
        private System.Windows.Forms.Label q10;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox que15;
        private System.Windows.Forms.Label q17;
        private System.Windows.Forms.Label q16;
        private System.Windows.Forms.Label q15;
        private System.Windows.Forms.Label q14;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.RadioButton rb_tf19;
        private System.Windows.Forms.RadioButton rb_tf20;
        private System.Windows.Forms.TextBox que20;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.RadioButton rb_tf17;
        private System.Windows.Forms.RadioButton rb_tf18;
        private System.Windows.Forms.TextBox que19;
        private System.Windows.Forms.TextBox que18;
        private System.Windows.Forms.TextBox que17;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.RadioButton rb_tf13;
        private System.Windows.Forms.RadioButton rb_tf14;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.RadioButton rb_tf11;
        private System.Windows.Forms.RadioButton rb_tf12;
        private System.Windows.Forms.GroupBox gb_middle;
        private System.Windows.Forms.RadioButton rb_tf9;
        private System.Windows.Forms.RadioButton rb_tf10;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.RadioButton rb_tf7;
        private System.Windows.Forms.RadioButton rb_tf8;
        private System.Windows.Forms.TextBox que16;
        private System.Windows.Forms.TextBox que14;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.RadioButton rb_tf5;
        private System.Windows.Forms.RadioButton rb_tf6;
        private System.Windows.Forms.TextBox que13;
        private System.Windows.Forms.Label q12;
        private System.Windows.Forms.Label q18;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.RadioButton rb_tf3;
        private System.Windows.Forms.RadioButton rb_tf4;
        private System.Windows.Forms.TextBox que12;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.RadioButton rb_tf1;
        private System.Windows.Forms.RadioButton rb_tf2;
        private System.Windows.Forms.TextBox que11;
        private System.Windows.Forms.Label q11;
        private System.Windows.Forms.Label q13;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.RadioButton rb_tf15;
        private System.Windows.Forms.RadioButton rb_tf16;
        private System.Windows.Forms.Label q19;
        private System.Windows.Forms.Label q20;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Button btn_tf_view;
        private System.Windows.Forms.Button btn_Q2_submit;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tab_short_ans;
        private System.Windows.Forms.TabPage tab_programme;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.TabPage tab_Q1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel17;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.TextBox textQ8q2;
        private System.Windows.Forms.TextBox textQ8Ans2;
        private System.Windows.Forms.TextBox textQ8q1;
        private System.Windows.Forms.TextBox textQ8Ans1;
        private System.Windows.Forms.GroupBox groupBox43;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.GroupBox groupBox44;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label txtPid;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.ComboBox Cmb8a1Ans;
        private System.Windows.Forms.ComboBox Cmb8a2Ans;
        private System.Windows.Forms.Button btnGiveUp;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.DataGridView grid1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textQ8q3;
        private System.Windows.Forms.TextBox textQ8Ans3;
        private System.Windows.Forms.Label label23;
        public System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.GroupBox groupBox55;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.GroupBox groupBox53;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.GroupBox groupBox52;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.GroupBox groupBox51;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.GroupBox groupBox50;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.GroupBox groupBox48;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.GroupBox groupBox47;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox txtQ1Ans10;
        private System.Windows.Forms.CheckBox R10;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox txtQ1Ans9;
        private System.Windows.Forms.CheckBox R9;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox txtQ1Ans8;
        private System.Windows.Forms.CheckBox R8;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txtQ1Ans7;
        private System.Windows.Forms.CheckBox R7;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtQ1Ans6;
        private System.Windows.Forms.CheckBox R6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtQ1Ans5;
        private System.Windows.Forms.CheckBox R5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtQ1Ans4;
        private System.Windows.Forms.CheckBox R4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtQ1Ans3;
        private System.Windows.Forms.CheckBox R3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox R2;
        private System.Windows.Forms.TextBox txtQ1Ans2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtQ6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtQ2;
        private System.Windows.Forms.TextBox txtQ4;
        private System.Windows.Forms.TextBox txtQ5;
        private System.Windows.Forms.TextBox txtQ7;
        private System.Windows.Forms.TextBox txtQ8;
        private System.Windows.Forms.TextBox txtQ9;
        private System.Windows.Forms.TextBox txtQ3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtQ10;
        private System.Windows.Forms.TextBox txtQ1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox R1;
        private System.Windows.Forms.TextBox txtQ1Ans1;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TextBox txtOutofTen;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox45;
        private System.Windows.Forms.TextBox txtQ1MAns;
        private System.Windows.Forms.GroupBox groupBox46;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.GroupBox groupBox54;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.CheckBox allwrong;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textQ7q1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.GroupBox groupBox40;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox textQ7Ans1;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox textQ7q2;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox textQ7Ans2;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox textQ7q3;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox textQ7Ans3;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox textQ7q4;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox textQ7Ans4;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox textQ7q5;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox textQ7Ans5;
        private System.Windows.Forms.TextBox textQ7q6;
        private System.Windows.Forms.TextBox textQ7Ans6;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox textQ7q7;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox textQ7Ans7;
        private System.Windows.Forms.TextBox textQ7q8;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox textQ7Ans8;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textQ8q4;
        private System.Windows.Forms.TextBox textQ8Ans4;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.GroupBox groupBox61;
        private System.Windows.Forms.ComboBox CmbAns7_8;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.GroupBox groupBox60;
        private System.Windows.Forms.ComboBox CmbAns7_7;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.GroupBox groupBox59;
        private System.Windows.Forms.ComboBox CmbAns7_6;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.GroupBox groupBox58;
        private System.Windows.Forms.ComboBox CmbAns7_5;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.GroupBox groupBox57;
        private System.Windows.Forms.ComboBox CmbAns7_4;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.GroupBox groupBox41;
        private System.Windows.Forms.ComboBox CmbAns7_1;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.GroupBox groupBox42;
        private System.Windows.Forms.ComboBox CmbAns7_2;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.GroupBox groupBox56;
        private System.Windows.Forms.ComboBox CmbAns7_3;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.GroupBox groupBox63;
        private System.Windows.Forms.ComboBox Cmb8b2Ans;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.GroupBox groupBox62;
        private System.Windows.Forms.ComboBox Cmb8b1Ans;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn q7a;
        private System.Windows.Forms.DataGridViewTextBoxColumn q8b;
        private System.Windows.Forms.DataGridViewTextBoxColumn TotalMarks;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label lblStream;
        private System.Windows.Forms.Label lblStremName;
        private System.Windows.Forms.Label lblMIndex;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label Teacher_Id;
    }
}