﻿
namespace Assessment_Tool
{
    partial class ModeratorDashBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ModeratorDashBoard));
            this.ModeratorGridView = new System.Windows.Forms.DataGridView();
            this.lblMName = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.lblmidindex = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.lblpaperchecked = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbltotalpaper = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtTID = new System.Windows.Forms.TextBox();
            this.btnSearchByTID = new System.Windows.Forms.Button();
            this.btnSearchBymarks = new System.Windows.Forms.Button();
            this.txtMarks = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnLogout = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ModeratorGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // ModeratorGridView
            // 
            this.ModeratorGridView.AllowUserToAddRows = false;
            this.ModeratorGridView.AllowUserToDeleteRows = false;
            this.ModeratorGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ModeratorGridView.Location = new System.Drawing.Point(181, 130);
            this.ModeratorGridView.MultiSelect = false;
            this.ModeratorGridView.Name = "ModeratorGridView";
            this.ModeratorGridView.ReadOnly = true;
            this.ModeratorGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ModeratorGridView.Size = new System.Drawing.Size(930, 429);
            this.ModeratorGridView.TabIndex = 0;
            this.ModeratorGridView.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ModeratorGridView_CellDoubleClick);
            // 
            // lblMName
            // 
            this.lblMName.AutoSize = true;
            this.lblMName.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMName.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblMName.Location = new System.Drawing.Point(418, 36);
            this.lblMName.Name = "lblMName";
            this.lblMName.Size = new System.Drawing.Size(51, 17);
            this.lblMName.TabIndex = 115;
            this.lblMName.Text = "Stream";
            this.lblMName.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.Location = new System.Drawing.Point(255, 36);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(113, 17);
            this.label82.TabIndex = 114;
            this.label82.Text = "Moderator Name";
            this.label82.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblmidindex
            // 
            this.lblmidindex.AutoSize = true;
            this.lblmidindex.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmidindex.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblmidindex.Location = new System.Drawing.Point(418, 9);
            this.lblmidindex.Name = "lblmidindex";
            this.lblmidindex.Size = new System.Drawing.Size(51, 17);
            this.lblmidindex.TabIndex = 113;
            this.lblmidindex.Text = "Stream";
            this.lblmidindex.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(255, 9);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(133, 17);
            this.label30.TabIndex = 112;
            this.label30.Text = "Moderator Index No";
            this.label30.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblpaperchecked
            // 
            this.lblpaperchecked.AutoSize = true;
            this.lblpaperchecked.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpaperchecked.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblpaperchecked.Location = new System.Drawing.Point(996, 36);
            this.lblpaperchecked.Name = "lblpaperchecked";
            this.lblpaperchecked.Size = new System.Drawing.Size(51, 17);
            this.lblpaperchecked.TabIndex = 119;
            this.lblpaperchecked.Text = "Stream";
            this.lblpaperchecked.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(796, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(184, 17);
            this.label2.TabIndex = 118;
            this.label2.Text = "No. of paper checked by you";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lbltotalpaper
            // 
            this.lbltotalpaper.AutoSize = true;
            this.lbltotalpaper.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalpaper.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lbltotalpaper.Location = new System.Drawing.Point(996, 9);
            this.lbltotalpaper.Name = "lbltotalpaper";
            this.lbltotalpaper.Size = new System.Drawing.Size(51, 17);
            this.lbltotalpaper.TabIndex = 117;
            this.lbltotalpaper.Text = "Stream";
            this.lbltotalpaper.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(796, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(124, 17);
            this.label4.TabIndex = 116;
            this.label4.Text = "No. of total papers";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(178, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 17);
            this.label1.TabIndex = 120;
            this.label1.Text = "Search By TID";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtTID
            // 
            this.txtTID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTID.Location = new System.Drawing.Point(277, 87);
            this.txtTID.Name = "txtTID";
            this.txtTID.Size = new System.Drawing.Size(138, 21);
            this.txtTID.TabIndex = 121;
            // 
            // btnSearchByTID
            // 
            this.btnSearchByTID.Location = new System.Drawing.Point(421, 85);
            this.btnSearchByTID.Name = "btnSearchByTID";
            this.btnSearchByTID.Size = new System.Drawing.Size(75, 23);
            this.btnSearchByTID.TabIndex = 122;
            this.btnSearchByTID.Text = "Search";
            this.btnSearchByTID.UseVisualStyleBackColor = true;
            this.btnSearchByTID.Click += new System.EventHandler(this.btnSearchByTID_Click);
            // 
            // btnSearchBymarks
            // 
            this.btnSearchBymarks.Location = new System.Drawing.Point(1036, 83);
            this.btnSearchBymarks.Name = "btnSearchBymarks";
            this.btnSearchBymarks.Size = new System.Drawing.Size(75, 23);
            this.btnSearchBymarks.TabIndex = 125;
            this.btnSearchBymarks.Text = "Search";
            this.btnSearchBymarks.UseVisualStyleBackColor = true;
            this.btnSearchBymarks.Click += new System.EventHandler(this.btnSearchBymarks_Click);
            // 
            // txtMarks
            // 
            this.txtMarks.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMarks.Location = new System.Drawing.Point(892, 85);
            this.txtMarks.Name = "txtMarks";
            this.txtMarks.Size = new System.Drawing.Size(138, 21);
            this.txtMarks.TabIndex = 124;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(742, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(144, 17);
            this.label3.TabIndex = 123;
            this.label3.Text = "Search By Total Marks";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.DeepPink;
            this.btnLogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.Location = new System.Drawing.Point(36, 12);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(79, 45);
            this.btnLogout.TabIndex = 126;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(601, 87);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 127;
            this.button1.Text = "Reset Data";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ModeratorDashBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1342, 818);
            this.ControlBox = false;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnSearchBymarks);
            this.Controls.Add(this.txtMarks);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnSearchByTID);
            this.Controls.Add(this.txtTID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblpaperchecked);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbltotalpaper);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblMName);
            this.Controls.Add(this.label82);
            this.Controls.Add(this.lblmidindex);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.ModeratorGridView);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ModeratorDashBoard";
            this.Text = "ModeratorDashBoard";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.ModeratorDashBoard_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ModeratorGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView ModeratorGridView;
        private System.Windows.Forms.Label lblMName;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label lblmidindex;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label lblpaperchecked;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbltotalpaper;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTID;
        private System.Windows.Forms.Button btnSearchByTID;
        private System.Windows.Forms.Button btnSearchBymarks;
        private System.Windows.Forms.TextBox txtMarks;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button button1;
    }
}